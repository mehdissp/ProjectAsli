
// // // // // // // // // // // RealEstateDetailPageItem.jsx - نسخه نهایی با سئوی بهبود یافته
// // // // // // // // // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // // // // // // // // import CryptoJS from 'crypto-js';
// // // // // // // // // // import DOMPurify from 'dompurify';
// // // // // // // // // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // // // // // // // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // // // // // // // // import { 
// // // // // // // // // //   FaMapMarkerAlt, 
// // // // // // // // // //   FaPhone, 
// // // // // // // // // //   FaWhatsapp, 
// // // // // // // // // //   FaShare, 
// // // // // // // // // //   FaArrowRight, 
// // // // // // // // // //   FaHeart,
// // // // // // // // // //   FaRegHeart,
// // // // // // // // // //   FaStar,
// // // // // // // // // //   FaParking,
// // // // // // // // // //   FaWarehouse,
// // // // // // // // // //   FaSwimmingPool,
// // // // // // // // // //   FaBath,
// // // // // // // // // //   FaRulerCombined,
// // // // // // // // // //   FaCalendarAlt,
// // // // // // // // // //   FaLayerGroup,
// // // // // // // // // //   FaArrowUp,
// // // // // // // // // //   FaCheckCircle,
// // // // // // // // // //   FaTag,
// // // // // // // // // //   FaHome,
// // // // // // // // // //   FaBuilding,
// // // // // // // // // //   FaRuler,
// // // // // // // // // //   FaShieldAlt,
// // // // // // // // // //   FaClock,
// // // // // // // // // //   FaEye,
// // // // // // // // // //   FaBookmark
// // // // // // // // // // } from 'react-icons/fa';
// // // // // // // // // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // // // // // // // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // // // // // // // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // // // // // // // // import "@neshan-maps-platform/react-openlayers/dist/style.css";

// // // // // // // // // // import 'swiper/css';
// // // // // // // // // // import 'swiper/css/navigation';
// // // // // // // // // // import 'swiper/css/pagination';
// // // // // // // // // // import './RealEstateDetailPageItem.css';

// // // // // // // // // // // ==================== هِلم کمکی برای سئو ====================
// // // // // // // // // // const stripHtml = (html) => {
// // // // // // // // // //   if (!html) return '';
// // // // // // // // // //   const temp = document.createElement('div');
// // // // // // // // // //   temp.innerHTML = html;
// // // // // // // // // //   return temp.textContent || temp.innerText || '';
// // // // // // // // // // };

// // // // // // // // // // const truncateText = (text, maxLength) => {
// // // // // // // // // //   if (!text) return '';
// // // // // // // // // //   if (text.length <= maxLength) return text;
// // // // // // // // // //   return text.substring(0, maxLength - 2) + '…';
// // // // // // // // // // };

// // // // // // // // // // // ==================== هِلمت سئو (اصلاح شده) ====================
// // // // // // // // // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     if (!property) return;

// // // // // // // // // //     // ===== عنوان بهینه (حداکثر ۶۵ کاراکتر) =====
// // // // // // // // // //     let title = property.title 
// // // // // // // // // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // // // // // // // // //       : `ملک ${property.area} متری ${property.regionName}`;
    
// // // // // // // // // //     title = truncateText(title, 65);
// // // // // // // // // //     document.title = title;

// // // // // // // // // //     // ===== متا توضیحات بدون HTML (۱۵۰-۱۶۰ کاراکتر) =====
// // // // // // // // // //     const plainDescription = stripHtml(property.description || '');
// // // // // // // // // //     const priceText = isForSale 
// // // // // // // // // //       ? `قیمت: ${property.price} تومان`
// // // // // // // // // //       : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
    
// // // // // // // // // //     let description = plainDescription 
// // // // // // // // // //       ? truncateText(plainDescription, 120) + `... ${priceText}`
// // // // // // // // // //       : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
    
// // // // // // // // // //     description = truncateText(description, 155);
    
// // // // // // // // // //     // ===== کلمات کلیدی (اختیاری، گوگل استفاده نمی‌کند ولی ضرر ندارد) =====
// // // // // // // // // //     const keywords = [
// // // // // // // // // //       property.title,
// // // // // // // // // //       `${property.regionName} ملک`,
// // // // // // // // // //       isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان',
// // // // // // // // // //       `${property.area} متری`,
// // // // // // // // // //       `${property.rooms} خوابه`,
// // // // // // // // // //       `طبقه ${property.floor}`,
// // // // // // // // // //       property.year !== "نامشخص" ? `ساخت ${property.year}` : '',
// // // // // // // // // //       ...property.features.slice(0, 5)
// // // // // // // // // //     ].filter(Boolean).join(',');
    
// // // // // // // // // //     // ===== تابع کمکی برای ایجاد/به‌روزرسانی متاتگ =====
// // // // // // // // // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // // // // // // // // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // // // // // // // // //       let meta = document.querySelector(selector);
// // // // // // // // // //       if (!meta) {
// // // // // // // // // //         meta = document.createElement('meta');
// // // // // // // // // //         if (isProperty) meta.setAttribute('property', name);
// // // // // // // // // //         else meta.setAttribute('name', name);
// // // // // // // // // //         document.head.appendChild(meta);
// // // // // // // // // //       }
// // // // // // // // // //       meta.setAttribute('content', content);
// // // // // // // // // //     };
    
// // // // // // // // // //     // ===== اعمال متاتگ‌ها =====
// // // // // // // // // //     updateOrCreateMeta('description', description);
// // // // // // // // // //     updateOrCreateMeta('keywords', keywords);
// // // // // // // // // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
    
// // // // // // // // // //     // ===== Canonical URL =====
// // // // // // // // // //     let canonical = document.querySelector('link[rel="canonical"]');
// // // // // // // // // //     if (!canonical) {
// // // // // // // // // //       canonical = document.createElement('link');
// // // // // // // // // //       canonical.rel = 'canonical';
// // // // // // // // // //       document.head.appendChild(canonical);
// // // // // // // // // //     }
// // // // // // // // // //     canonical.href = window.location.href;
    
// // // // // // // // // //     // ===== Open Graph (فیسبوک، لینکدین) =====
// // // // // // // // // //     updateOrCreateMeta('og:title', title, true);
// // // // // // // // // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // // // // // // // // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // // // // // // // // //     updateOrCreateMeta('og:url', window.location.href, true);
// // // // // // // // // //     updateOrCreateMeta('og:type', 'product', true);
// // // // // // // // // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // // // // // // // // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
    
// // // // // // // // // //     // ===== Twitter Card =====
// // // // // // // // // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // // // // // // // // //     updateOrCreateMeta('twitter:title', title);
// // // // // // // // // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // // // // // // // // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
    
// // // // // // // // // //     // ===== زبان و دایرکشن =====
// // // // // // // // // //     document.documentElement.lang = 'fa';
// // // // // // // // // //     document.documentElement.dir = 'rtl';
    
// // // // // // // // // //   }, [property, isForSale, isForRent]);
  
// // // // // // // // // //   return null;
// // // // // // // // // // };

// // // // // // // // // // // ==================== JSON-LD Structured Data ====================
// // // // // // // // // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     if (!property) return;
    
// // // // // // // // // //     const removeOldScript = () => {
// // // // // // // // // //       const oldScript = document.getElementById('json-ld-structured-data');
// // // // // // // // // //       if (oldScript) oldScript.remove();
// // // // // // // // // //     };
    
// // // // // // // // // //     removeOldScript();
    
// // // // // // // // // //     // تابع تبدیل قیمت به عدد
// // // // // // // // // //     const parsePriceToNumber = (priceStr) => {
// // // // // // // // // //       if (!priceStr || priceStr === '۰') return '0';
// // // // // // // // // //       return String(priceStr).replace(/[^0-9]/g, '') || '0';
// // // // // // // // // //     };
    
// // // // // // // // // //     const structuredData = {
// // // // // // // // // //       "@context": "https://schema.org",
// // // // // // // // // //       "@type": isForSale ? "Product" : "RealEstateListing",
// // // // // // // // // //       "name": property.title,
// // // // // // // // // //       "description": stripHtml(property.description || '').substring(0, 500),
// // // // // // // // // //       "image": property.images.slice(0, 10),
// // // // // // // // // //       "url": window.location.href,
// // // // // // // // // //       "datePublished": new Date().toISOString(),
// // // // // // // // // //       "dateModified": new Date().toISOString(),
// // // // // // // // // //       ...(isForSale && {
// // // // // // // // // //         "offers": {
// // // // // // // // // //           "@type": "Offer",
// // // // // // // // // //           "price": parsePriceToNumber(property.price),
// // // // // // // // // //           "priceCurrency": "IRR",
// // // // // // // // // //           "availability": "https://schema.org/InStock",
// // // // // // // // // //           "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
// // // // // // // // // //         }
// // // // // // // // // //       }),
// // // // // // // // // //       ...(isForRent && {
// // // // // // // // // //         "offers": {
// // // // // // // // // //           "@type": "Offer",
// // // // // // // // // //           "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'),
// // // // // // // // // //           "priceCurrency": "IRR",
// // // // // // // // // //           "description": "ملک رهن و اجاره"
// // // // // // // // // //         }
// // // // // // // // // //       }),
// // // // // // // // // //       "address": {
// // // // // // // // // //         "@type": "PostalAddress",
// // // // // // // // // //         "addressLocality": property.regionName,
// // // // // // // // // //         "streetAddress": property.address,
// // // // // // // // // //         "addressCountry": "IR",
// // // // // // // // // //         "addressRegion": "تهران"
// // // // // // // // // //       },
// // // // // // // // // //       "floorSize": {
// // // // // // // // // //         "@type": "QuantitativeValue",
// // // // // // // // // //         "value": property.area || 0,
// // // // // // // // // //         "unitCode": "MTK",
// // // // // // // // // //         "unitText": "متر مربع"
// // // // // // // // // //       },
// // // // // // // // // //       "numberOfRooms": property.rooms || 0,
// // // // // // // // // //       "additionalProperty": [
// // // // // // // // // //         {
// // // // // // // // // //           "@type": "PropertyValue",
// // // // // // // // // //           "name": "طبقه",
// // // // // // // // // //           "value": `${property.floor || 1} از ${property.totalFloors || 1}`
// // // // // // // // // //         },
// // // // // // // // // //         {
// // // // // // // // // //           "@type": "PropertyValue",
// // // // // // // // // //           "name": "سال ساخت",
// // // // // // // // // //           "value": property.year !== "نامشخص" ? property.year : "نامشخص"
// // // // // // // // // //         },
// // // // // // // // // //         ...property.features.slice(0, 15).map(feature => ({
// // // // // // // // // //           "@type": "PropertyValue",
// // // // // // // // // //           "name": "امکانات",
// // // // // // // // // //           "value": feature
// // // // // // // // // //         }))
// // // // // // // // // //       ],
// // // // // // // // // //       "potentialAction": {
// // // // // // // // // //         "@type": "CommunicateAction",
// // // // // // // // // //         "name": "تماس با مشاور",
// // // // // // // // // //         "target": {
// // // // // // // // // //           "@type": "EntryPoint",
// // // // // // // // // //           "urlTemplate": `tel:${property.agent?.phone || ''}`,
// // // // // // // // // //           "inLanguage": "fa-IR",
// // // // // // // // // //           "actionPlatform": [
// // // // // // // // // //             "http://schema.org/DesktopWebPlatform",
// // // // // // // // // //             "http://schema.org/MobileWebPlatform"
// // // // // // // // // //           ]
// // // // // // // // // //         }
// // // // // // // // // //       }
// // // // // // // // // //     };
    
// // // // // // // // // //     const script = document.createElement('script');
// // // // // // // // // //     script.id = 'json-ld-structured-data';
// // // // // // // // // //     script.type = 'application/ld+json';
// // // // // // // // // //     script.textContent = JSON.stringify(structuredData);
// // // // // // // // // //     document.head.appendChild(script);
    
// // // // // // // // // //     return () => removeOldScript();
// // // // // // // // // //   }, [property, isForSale, isForRent]);
  
// // // // // // // // // //   return null;
// // // // // // // // // // };

// // // // // // // // // // // ==================== Breadcrumb Structured Data ====================
// // // // // // // // // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     if (!property) return;
    
// // // // // // // // // //     const removeOldScript = () => {
// // // // // // // // // //       const oldScript = document.getElementById('json-ld-breadcrumb');
// // // // // // // // // //       if (oldScript) oldScript.remove();
// // // // // // // // // //     };
    
// // // // // // // // // //     removeOldScript();
    
// // // // // // // // // //     const baseUrl = window.location.origin;
// // // // // // // // // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
    
// // // // // // // // // //     const breadcrumbData = {
// // // // // // // // // //       "@context": "https://schema.org",
// // // // // // // // // //       "@type": "BreadcrumbList",
// // // // // // // // // //       "itemListElement": [
// // // // // // // // // //         {
// // // // // // // // // //           "@type": "ListItem",
// // // // // // // // // //           "position": 1,
// // // // // // // // // //           "name": "صفحه اصلی",
// // // // // // // // // //           "item": `${baseUrl}/`
// // // // // // // // // //         },
// // // // // // // // // //         {
// // // // // // // // // //           "@type": "ListItem",
// // // // // // // // // //           "position": 2,
// // // // // // // // // //           "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره",
// // // // // // // // // //           "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}`
// // // // // // // // // //         },
// // // // // // // // // //         {
// // // // // // // // // //           "@type": "ListItem",
// // // // // // // // // //           "position": 3,
// // // // // // // // // //           "name": `منطقه ${property.regionName}`,
// // // // // // // // // //           "item": `${baseUrl}/region/${regionSlug}`
// // // // // // // // // //         },
// // // // // // // // // //         {
// // // // // // // // // //           "@type": "ListItem",
// // // // // // // // // //           "position": 4,
// // // // // // // // // //           "name": truncateText(property.title || 'جزئیات ملک', 80),
// // // // // // // // // //           "item": window.location.href
// // // // // // // // // //         }
// // // // // // // // // //       ]
// // // // // // // // // //     };
    
// // // // // // // // // //     const script = document.createElement('script');
// // // // // // // // // //     script.id = 'json-ld-breadcrumb';
// // // // // // // // // //     script.type = 'application/ld+json';
// // // // // // // // // //     script.textContent = JSON.stringify(breadcrumbData);
// // // // // // // // // //     document.head.appendChild(script);
    
// // // // // // // // // //     return () => removeOldScript();
// // // // // // // // // //   }, [property, isForSale]);
  
// // // // // // // // // //   return null;
// // // // // // // // // // };

// // // // // // // // // // // ==================== کامپوننت اسکلتون ====================
// // // // // // // // // // const DetailSkeleton = () => (
// // // // // // // // // //   <div className="detail-skeleton" aria-label="در حال بارگذاری اطلاعات ملک">
// // // // // // // // // //     <div className="skeleton-header">
// // // // // // // // // //       <div className="skeleton-circle"></div>
// // // // // // // // // //       <div className="skeleton-title"></div>
// // // // // // // // // //       <div className="skeleton-circle"></div>
// // // // // // // // // //     </div>
// // // // // // // // // //     <div className="skeleton-gallery">
// // // // // // // // // //       <div className="skeleton-image"></div>
// // // // // // // // // //     </div>
// // // // // // // // // //     <div className="skeleton-content">
// // // // // // // // // //       <div className="skeleton-price"></div>
// // // // // // // // // //       <div className="skeleton-info">
// // // // // // // // // //         {[1,2,3,4].map(i => <div key={i} className="skeleton-chip"></div>)}
// // // // // // // // // //       </div>
// // // // // // // // // //       <div className="skeleton-tabs">
// // // // // // // // // //         {[1,2,3,4].map(i => <div key={i} className="skeleton-tab"></div>)}
// // // // // // // // // //       </div>
// // // // // // // // // //       <div className="skeleton-text">
// // // // // // // // // //         {[1,2,3].map(i => <div key={i} className="skeleton-line"></div>)}
// // // // // // // // // //       </div>
// // // // // // // // // //     </div>
// // // // // // // // // //   </div>
// // // // // // // // // // );

// // // // // // // // // // // ==================== کامپوننت اصلی ====================
// // // // // // // // // // const RealEstateDetailPageItem = memo(() => {
// // // // // // // // // //   const location = useLocation();
// // // // // // // // // //   const navigate = useNavigate();
// // // // // // // // // //   const { id: paramId } = useParams();
  
// // // // // // // // // //   const queryParams = new URLSearchParams(location.search);
// // // // // // // // // //   const id = paramId || queryParams.get('id');
  
// // // // // // // // // //   const [property, setProperty] = useState(null);
// // // // // // // // // //   const [loading, setLoading] = useState(true);
// // // // // // // // // //   const [error, setError] = useState(null);
// // // // // // // // // //   const [copied, setCopied] = useState(false);
// // // // // // // // // //   const [selectedImage, setSelectedImage] = useState(0);
// // // // // // // // // //   const [activeTab, setActiveTab] = useState('details');
// // // // // // // // // //   const [isFavorite, setIsFavorite] = useState(false);
// // // // // // // // // //   const [imagesLoaded, setImagesLoaded] = useState({});

// // // // // // // // // //   const ENCRYPTION_KEY = "xK9mN2pQ5rS7uV8wX1yZ3aB4cD6eF0gH2jK5lL8nP9qR1sT3uV5wX7yZ9=";

// // // // // // // // // //   const decryptResponse = (encryptedData, iv) => {
// // // // // // // // // //     try {
// // // // // // // // // //       const ivWordArray = CryptoJS.enc.Base64.parse(iv);
// // // // // // // // // //       const decrypted = CryptoJS.AES.decrypt(
// // // // // // // // // //         encryptedData,
// // // // // // // // // //         CryptoJS.enc.Base64.parse(ENCRYPTION_KEY),
// // // // // // // // // //         {
// // // // // // // // // //           iv: ivWordArray,
// // // // // // // // // //           mode: CryptoJS.mode.CBC,
// // // // // // // // // //           padding: CryptoJS.pad.Pkcs7
// // // // // // // // // //         }
// // // // // // // // // //       );
// // // // // // // // // //       const decryptedText = decrypted.toString(CryptoJS.enc.Utf8);
// // // // // // // // // //       if (!decryptedText) throw new Error("Decryption failed");
// // // // // // // // // //       return JSON.parse(decryptedText);
// // // // // // // // // //     } catch (error) {
// // // // // // // // // //       console.error("Decryption failed:", error);
// // // // // // // // // //       throw error;
// // // // // // // // // //     }
// // // // // // // // // //   };

// // // // // // // // // //   // ==================== فراخوانی داده ====================
// // // // // // // // // //   useEffect(() => {
// // // // // // // // // //     const fetchPropertyData = async () => {
// // // // // // // // // //       if (!id) {
// // // // // // // // // //         setError('شناسه ملک یافت نشد');
// // // // // // // // // //         setLoading(false);
// // // // // // // // // //         return;
// // // // // // // // // //       }
      
// // // // // // // // // //       setLoading(true);
// // // // // // // // // //       setError(null);
      
// // // // // // // // // //       try {
// // // // // // // // // //         const controller = new AbortController();
// // // // // // // // // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
        
// // // // // // // // // //         const response = await fetch(
// // // // // // // // // //           `https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`,
// // // // // // // // // //           { signal: controller.signal }
// // // // // // // // // //         );
        
// // // // // // // // // //         clearTimeout(timeoutId);
        
// // // // // // // // // //         if (!response.ok) {
// // // // // // // // // //           throw new Error(`HTTP ${response.status}`);
// // // // // // // // // //         }
        
// // // // // // // // // //         const result = await response.json();

// // // // // // // // // //         if (result.status === 200 && result.data) {
// // // // // // // // // //           const data = result.data;
// // // // // // // // // //           setProperty({
// // // // // // // // // //             id: data.id,
// // // // // // // // // //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `,
// // // // // // // // // //             price: data.price?.toLocaleString("fa-IR") || "۰",
// // // // // // // // // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰",
// // // // // // // // // //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // // // // // // // // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null,
// // // // // // // // // //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // // // // // // // // //             type: data.categoryType,
// // // // // // // // // //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0,
// // // // // // // // // //             rooms: data.rooms || 0,
// // // // // // // // // //             floor: data.floor || 1,
// // // // // // // // // //             regionName: data.regionName || "منطقه نامشخص",
// // // // // // // // // //             totalFloors: data.countFloor || 1,
// // // // // // // // // //             year: data.constructionYear || "نامشخص",
// // // // // // // // // //             address: data.address || "آدرس درج نشده",
// // // // // // // // // //             showExactLocation: data.showExactLocation,
// // // // // // // // // //             location: {
// // // // // // // // // //               lat: data.lat || 35.7199363,
// // // // // // // // // //               lng: data.lng || 51.4334842,
// // // // // // // // // //             },
// // // // // // // // // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.",
// // // // // // // // // //             features: data.facilities || [],
// // // // // // // // // //             warnings: data.warnings || [
// // // // // // // // // //               "استعلام خلافی",
// // // // // // // // // //               "بررسی سند مالکیت",
// // // // // // // // // //               "استعلام پایان کار",
// // // // // // // // // //               "بررسی مفاصا حساب"
// // // // // // // // // //             ],
// // // // // // // // // //             images: (data.images || []).map(
// // // // // // // // // //               (img) => `https://localhost:7178/${img}`
// // // // // // // // // //             ),
// // // // // // // // // //             agent: {
// // // // // // // // // //               name: data.agents?.name || "مشاور املاک",
// // // // // // // // // //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰",
// // // // // // // // // //               whatsapp: data.agents?.connectSocialMedia || "",
// // // // // // // // // //               address: data.agents?.address || "آدرس دفتر درج نشده",
// // // // // // // // // //               rating: data.agents?.rating || 4.5,
// // // // // // // // // //               deals: data.agents?.deals || 120,
// // // // // // // // // //               image: data.agents?.image || "https://randomuser.me/api/portraits/men/32.jpg",
// // // // // // // // // //             },
// // // // // // // // // //             views: data.views || 0,
// // // // // // // // // //             saved: data.saved || 0,
// // // // // // // // // //             createdAt: data.createdAtPersianRelative || "امروز",
// // // // // // // // // //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی",
// // // // // // // // // //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // // // // // // // // //             nearby: [
// // // // // // // // // //               { name: "مترو", distance: "۵۰۰ متر" },
// // // // // // // // // //               { name: "مرکز خرید", distance: "۳۰۰ متر" },
// // // // // // // // // //               { name: "پارک", distance: "۲۰۰ متر" },
// // // // // // // // // //               { name: "مدرسه", distance: "۴۰۰ متر" }
// // // // // // // // // //             ]
// // // // // // // // // //           });
// // // // // // // // // //         } else {
// // // // // // // // // //           throw new Error(result.message || 'ملک یافت نشد');
// // // // // // // // // //         }
// // // // // // // // // //       } catch (error) {
// // // // // // // // // //         console.error('خطا در دریافت اطلاعات:', error);
// // // // // // // // // //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور');
// // // // // // // // // //       } finally {
// // // // // // // // // //         setLoading(false);
// // // // // // // // // //       }
// // // // // // // // // //     };

// // // // // // // // // //     fetchPropertyData();
// // // // // // // // // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // // // // // // // // //   }, [id]);

// // // // // // // // // //   // ==================== محاسبات memoized ====================
// // // // // // // // // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // // // // // // // // //   const isForRent = useMemo(() => property?.type === 2, [property]);
  
// // // // // // // // // //   const formattedPricePerMeter = useMemo(() => {
// // // // // // // // // //     if (!property?.priceMeter || property.priceMeter === "۰") return null;
// // // // // // // // // //     return `${property.priceMeter} تومان`;
// // // // // // // // // //   }, [property]);
  
// // // // // // // // // //   const shareUrl = useMemo(() => {
// // // // // // // // // //     if (typeof window === 'undefined') return '';
// // // // // // // // // //     return window.location.href;
// // // // // // // // // //   }, []);

// // // // // // // // // //   // ==================== هندلرها ====================
// // // // // // // // // //   const handleCopyLink = useCallback(() => {
// // // // // // // // // //     navigator.clipboard.writeText(shareUrl);
// // // // // // // // // //     setCopied(true);
// // // // // // // // // //     setTimeout(() => setCopied(false), 2000);
// // // // // // // // // //   }, [shareUrl]);
  
// // // // // // // // // //   const handleShare = useCallback(async () => {
// // // // // // // // // //     if (!property) return;
    
// // // // // // // // // //     const shareData = {
// // // // // // // // // //       title: property.title,
// // // // // // // // // //       text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`,
// // // // // // // // // //       url: shareUrl
// // // // // // // // // //     };
    
// // // // // // // // // //     if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) {
// // // // // // // // // //       try {
// // // // // // // // // //         await navigator.share(shareData);
// // // // // // // // // //       } catch (error) {
// // // // // // // // // //         if (error.name !== 'AbortError') {
// // // // // // // // // //           handleCopyLink();
// // // // // // // // // //         }
// // // // // // // // // //       }
// // // // // // // // // //     } else {
// // // // // // // // // //       handleCopyLink();
// // // // // // // // // //     }
// // // // // // // // // //   }, [property, isForSale, shareUrl, handleCopyLink]);
  
// // // // // // // // // //   const handleCopyPhone = useCallback(() => {
// // // // // // // // // //     if (!property?.agent?.phone) return;
// // // // // // // // // //     navigator.clipboard.writeText(property.agent.phone);
// // // // // // // // // //     setCopied(true);
// // // // // // // // // //     setTimeout(() => setCopied(false), 2000);
// // // // // // // // // //   }, [property]);
  
// // // // // // // // // //   const handleImageLoad = useCallback((index) => {
// // // // // // // // // //     setImagesLoaded(prev => ({ ...prev, [index]: true }));
// // // // // // // // // //   }, []);
  
// // // // // // // // // //   const handleFavoriteToggle = useCallback(() => {
// // // // // // // // // //     setIsFavorite(prev => !prev);
// // // // // // // // // //   }, []);

// // // // // // // // // //   // ==================== رندر خطا ====================
// // // // // // // // // //   if (error) {
// // // // // // // // // //     return (
// // // // // // // // // //       <>
// // // // // // // // // //         <PageMetadata property={null} />
// // // // // // // // // //         <div className="detail-container">
// // // // // // // // // //           <div className="detail-header">
// // // // // // // // // //             <button className="header-btn" onClick={() => navigate(-1)} aria-label="بازگشت">
// // // // // // // // // //               <FaArrowRight />
// // // // // // // // // //             </button>
// // // // // // // // // //             <h1 className="header-title">خطا</h1>
// // // // // // // // // //             <div className="header-btn"></div>
// // // // // // // // // //           </div>
// // // // // // // // // //           <div className="error-message" role="alert">
// // // // // // // // // //             <h2>متاسفانه خطایی رخ داده است</h2>
// // // // // // // // // //             <p>{error}</p>
// // // // // // // // // //             <button onClick={() => window.location.reload()} className="retry-btn">
// // // // // // // // // //               تلاش مجدد
// // // // // // // // // //             </button>
// // // // // // // // // //             <button onClick={() => navigate('/')} className="home-btn">
// // // // // // // // // //               بازگشت به صفحه اصلی
// // // // // // // // // //             </button>
// // // // // // // // // //           </div>
// // // // // // // // // //         </div>
// // // // // // // // // //       </>
// // // // // // // // // //     );
// // // // // // // // // //   }
  
// // // // // // // // // //   if (loading) return <DetailSkeleton />;
// // // // // // // // // //   if (!property) {
// // // // // // // // // //     return (
// // // // // // // // // //       <>
// // // // // // // // // //         <PageMetadata property={null} />
// // // // // // // // // //         <div className="detail-container">
// // // // // // // // // //           <div className="detail-header">
// // // // // // // // // //             <button className="header-btn" onClick={() => navigate(-1)}>
// // // // // // // // // //               <FaArrowRight />
// // // // // // // // // //             </button>
// // // // // // // // // //             <h1 className="header-title">ملک یافت نشد</h1>
// // // // // // // // // //             <div className="header-btn"></div>
// // // // // // // // // //           </div>
// // // // // // // // // //           <div className="error-message">
// // // // // // // // // //             <p>متاسفانه ملک مورد نظر یافت نشد</p>
// // // // // // // // // //             <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // // // // // // //           </div>
// // // // // // // // // //         </div>
// // // // // // // // // //       </>
// // // // // // // // // //     );
// // // // // // // // // //   }

// // // // // // // // // //   // ==================== رندر اصلی ====================
// // // // // // // // // //   return (
// // // // // // // // // //     <>
// // // // // // // // // //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // // // // //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // // // // //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
// // // // // // // // // //       <div className="detail-container" itemScope itemType="https://schema.org/Product">
        
// // // // // // // // // //         {/* ===== Breadcrumb Navigation ===== */}
// // // // // // // // // //         <nav aria-label="مسیر راهنما" className="breadcrumb-nav">
// // // // // // // // // //           <ol className="breadcrumb-list">
// // // // // // // // // //             <li className="breadcrumb-item">
// // // // // // // // // //               <a href="/" className="breadcrumb-link">خانه</a>
// // // // // // // // // //             </li>
// // // // // // // // // //             <li className="breadcrumb-item">
// // // // // // // // // //               <a href={isForSale ? '/sale' : '/rent'} className="breadcrumb-link">
// // // // // // // // // //                 {isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}
// // // // // // // // // //               </a>
// // // // // // // // // //             </li>
// // // // // // // // // //             <li className="breadcrumb-item">
// // // // // // // // // //               <a href={`/region/${encodeURIComponent(property.regionName)}`} className="breadcrumb-link">
// // // // // // // // // //                 منطقه {property.regionName}
// // // // // // // // // //               </a>
// // // // // // // // // //             </li>
// // // // // // // // // //             <li className="breadcrumb-item active" aria-current="page">
// // // // // // // // // //               {truncateText(property.title, 50)}
// // // // // // // // // //             </li>
// // // // // // // // // //           </ol>
// // // // // // // // // //         </nav>
        
// // // // // // // // // //         {/* ===== Header با H1 صحیح ===== */}
// // // // // // // // // //         <div className="detail-header">
// // // // // // // // // //           <button className="header-btn" onClick={() => navigate(-1)} aria-label="بازگشت به صفحه قبل">
// // // // // // // // // //             <FaArrowRight aria-hidden="true" />
// // // // // // // // // //           </button>
// // // // // // // // // //           <h1 className="header-title" itemProp="name">{property.title}</h1>
// // // // // // // // // //           <button className="header-btn" onClick={handleShare} aria-label="اشتراک‌گذاری">
// // // // // // // // // //             <FaShare aria-hidden="true" />
// // // // // // // // // //           </button>
// // // // // // // // // //         </div>

// // // // // // // // // //         {/* ===== Image Gallery ===== */}
// // // // // // // // // //         <div className="detail-gallery">
// // // // // // // // // //           <Swiper
// // // // // // // // // //             modules={[Navigation, Pagination, Autoplay]}
// // // // // // // // // //             navigation
// // // // // // // // // //             pagination={{ clickable: true }}
// // // // // // // // // //             autoplay={{ delay: 4000, disableOnInteraction: false }}
// // // // // // // // // //             spaceBetween={0}
// // // // // // // // // //             slidesPerView={1}
// // // // // // // // // //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)}
// // // // // // // // // //             className="gallery-swiper"
// // // // // // // // // //           >
// // // // // // // // // //             {property.images.length > 0 ? property.images.map((img, index) => (
// // // // // // // // // //               <SwiperSlide key={index}>
// // // // // // // // // //                 <div className="gallery-slide">
// // // // // // // // // //                   {!imagesLoaded[index] && (
// // // // // // // // // //                     <div className="image-placeholder" aria-label="در حال بارگذاری تصویر">
// // // // // // // // // //                       <FaHome className="placeholder-icon" />
// // // // // // // // // //                     </div>
// // // // // // // // // //                   )}
// // // // // // // // // //                   <img 
// // // // // // // // // //                     src={img} 
// // // // // // // // // //                     alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`} - ${property.area} متری ${property.regionName}`}
// // // // // // // // // //                     loading={index === 0 ? 'eager' : 'lazy'}
// // // // // // // // // //                     decoding="async"
// // // // // // // // // //                     fetchPriority={index === 0 ? 'high' : 'auto'}
// // // // // // // // // //                     onLoad={() => handleImageLoad(index)}
// // // // // // // // // //                     style={{ display: imagesLoaded[index] ? 'block' : 'none' }}
// // // // // // // // // //                     itemProp="image"
// // // // // // // // // //                   />
// // // // // // // // // //                 </div>
// // // // // // // // // //               </SwiperSlide>
// // // // // // // // // //             )) : (
// // // // // // // // // //               <SwiperSlide>
// // // // // // // // // //                 <div className="gallery-slide no-image">
// // // // // // // // // //                   <FaHome className="no-image-icon" />
// // // // // // // // // //                   <span>تصویری موجود نیست</span>
// // // // // // // // // //                 </div>
// // // // // // // // // //               </SwiperSlide>
// // // // // // // // // //             )}
// // // // // // // // // //           </Swiper>
          
// // // // // // // // // //           <button 
// // // // // // // // // //             className={`favorite-btn ${isFavorite ? 'active' : ''}`}
// // // // // // // // // //             onClick={handleFavoriteToggle}
// // // // // // // // // //             aria-label={isFavorite ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها'}
// // // // // // // // // //             aria-pressed={isFavorite}
// // // // // // // // // //           >
// // // // // // // // // //             {isFavorite ? <FaHeart aria-hidden="true" /> : <FaRegHeart aria-hidden="true" />}
// // // // // // // // // //           </button>
          
// // // // // // // // // //           <div className="image-counter" aria-label={`تصویر ${selectedImage + 1} از ${property.images.length || 1}`}>
// // // // // // // // // //             {selectedImage + 1} / {property.images.length || 1}
// // // // // // // // // //           </div>
// // // // // // // // // //         </div>

// // // // // // // // // //         {/* ===== Main Content ===== */}
// // // // // // // // // //         <div className="detail-main">
          
// // // // // // // // // //           {/* آمار ملک - بدون H2 تکراری */}
// // // // // // // // // //           <div className="detail-title-section">
// // // // // // // // // //             <div className="title-row">
// // // // // // // // // //               <div className="property-stats">
// // // // // // // // // //                 <span className="stat-badge" title="تعداد بازدید">
// // // // // // // // // //                   <FaEye className="stat-icon" aria-hidden="true" />
// // // // // // // // // //                   {property.views.toLocaleString('fa-IR')} بازدید
// // // // // // // // // //                 </span>
// // // // // // // // // //                 <span className="stat-badge" title="تعداد ذخیره شده">
// // // // // // // // // //                   <FaBookmark className="stat-icon" aria-hidden="true" />
// // // // // // // // // //                   {property.saved.toLocaleString('fa-IR')} ذخیره
// // // // // // // // // //                 </span>
// // // // // // // // // //                 <span className="stat-badge" title="تاریخ درج">
// // // // // // // // // //                   <FaClock className="stat-icon" aria-hidden="true" />
// // // // // // // // // //                   {property.createdAt}
// // // // // // // // // //                 </span>
// // // // // // // // // //               </div>
// // // // // // // // // //             </div>
// // // // // // // // // //           </div>

// // // // // // // // // //           {/* ===== قیمت‌ها ===== */}
// // // // // // // // // //           <div className="price-section" itemProp="offers" itemScope itemType="https://schema.org/Offer">
// // // // // // // // // //             {isForSale && (
// // // // // // // // // //               <div className="price-card sale-price">
// // // // // // // // // //                 <div className="price-card-icon">
// // // // // // // // // //                   <FaTag aria-hidden="true" />
// // // // // // // // // //                 </div>
// // // // // // // // // //                 <div className="price-card-content">
// // // // // // // // // //                   <span className="price-label">قیمت فروش</span>
// // // // // // // // // //                   <div className="price-value-wrapper">
// // // // // // // // // //                     <span className="price-number" itemProp="price">{property.price}</span>
// // // // // // // // // //                     <span className="price-unit" itemProp="priceCurrency" content="IRR">تومان</span>
// // // // // // // // // //                   </div>
// // // // // // // // // //                   {formattedPricePerMeter && (
// // // // // // // // // //                     <div className="price-meta">
// // // // // // // // // //                       <FaRuler aria-hidden="true" />
// // // // // // // // // //                       <span>متری {formattedPricePerMeter}</span>
// // // // // // // // // //                     </div>
// // // // // // // // // //                   )}
// // // // // // // // // //                 </div>
// // // // // // // // // //               </div>
// // // // // // // // // //             )}

// // // // // // // // // //             {isForRent && (
// // // // // // // // // //               <div className="rent-price-group">
// // // // // // // // // //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// // // // // // // // // //                   <div className="price-card mortgage-price">
// // // // // // // // // //                     <div className="price-card-icon">
// // // // // // // // // //                       <FaBuilding aria-hidden="true" />
// // // // // // // // // //                     </div>
// // // // // // // // // //                     <div className="price-card-content">
// // // // // // // // // //                       <span className="price-label">مبلغ رهن (قرض‌الحسنه)</span>
// // // // // // // // // //                       <div className="price-value-wrapper">
// // // // // // // // // //                         <span className="price-number">{property.mortgagePrice}</span>
// // // // // // // // // //                         <span className="price-unit">تومان</span>
// // // // // // // // // //                       </div>
// // // // // // // // // //                     </div>
// // // // // // // // // //                   </div>
// // // // // // // // // //                 )}
                
// // // // // // // // // //                 {property.rentPrice && property.rentPrice !== "۰" && (
// // // // // // // // // //                   <div className="price-card rent-price">
// // // // // // // // // //                     <div className="price-card-icon">
// // // // // // // // // //                       <FaHome aria-hidden="true" />
// // // // // // // // // //                     </div>
// // // // // // // // // //                     <div className="price-card-content">
// // // // // // // // // //                       <span className="price-label">اجاره ماهانه</span>
// // // // // // // // // //                       <div className="price-value-wrapper">
// // // // // // // // // //                         <span className="price-number">{property.rentPrice}</span>
// // // // // // // // // //                         <span className="price-unit">تومان</span>
// // // // // // // // // //                       </div>
// // // // // // // // // //                     </div>
// // // // // // // // // //                   </div>
// // // // // // // // // //                 )}

// // // // // // // // // //                 {(!property.mortgagePrice || property.mortgagePrice === "۰") && 
// // // // // // // // // //                  (!property.rentPrice || property.rentPrice === "۰") && property.depositPrice && (
// // // // // // // // // //                   <div className="price-card deposit-price">
// // // // // // // // // //                     <div className="price-card-icon">
// // // // // // // // // //                       <FaShieldAlt aria-hidden="true" />
// // // // // // // // // //                     </div>
// // // // // // // // // //                     <div className="price-card-content">
// // // // // // // // // //                       <span className="price-label">ودیعه</span>
// // // // // // // // // //                       <div className="price-value-wrapper">
// // // // // // // // // //                         <span className="price-number">{property.depositPrice}</span>
// // // // // // // // // //                         <span className="price-unit">تومان</span>
// // // // // // // // // //                       </div>
// // // // // // // // // //                     </div>
// // // // // // // // // //                   </div>
// // // // // // // // // //                 )}
// // // // // // // // // //               </div>
// // // // // // // // // //             )}
// // // // // // // // // //           </div>

// // // // // // // // // //           {/* ===== مشخصات سریع ===== */}
// // // // // // // // // //           <div className="quick-specs">
// // // // // // // // // //             <div className="spec-item" itemProp="floorSize" itemScope itemType="https://schema.org/QuantitativeValue">
// // // // // // // // // //               <FaRulerCombined className="spec-icon" aria-hidden="true" />
// // // // // // // // // //               <span className="spec-label">متراژ</span>
// // // // // // // // // //               <span className="spec-value" itemProp="value">{property.area} متر²</span>
// // // // // // // // // //             </div>
// // // // // // // // // //             <div className="spec-item">
// // // // // // // // // //               <FaBath className="spec-icon" aria-hidden="true" />
// // // // // // // // // //               <span className="spec-label">اتاق‌خواب</span>
// // // // // // // // // //               <span className="spec-value" itemProp="numberOfRooms">{property.rooms} خواب</span>
// // // // // // // // // //             </div>
// // // // // // // // // //             <div className="spec-item">
// // // // // // // // // //               <FaLayerGroup className="spec-icon" aria-hidden="true" />
// // // // // // // // // //               <span className="spec-label">طبقه</span>
// // // // // // // // // //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// // // // // // // // // //             </div>
// // // // // // // // // //             <div className="spec-item">
// // // // // // // // // //               <FaCalendarAlt className="spec-icon" aria-hidden="true" />
// // // // // // // // // //               <span className="spec-label">سال ساخت</span>
// // // // // // // // // //               <span className="spec-value">{property.year}</span>
// // // // // // // // // //             </div>
// // // // // // // // // //           </div>

// // // // // // // // // //           {/* ===== چیپ‌های اطلاعاتی ===== */}
// // // // // // // // // //           <div className="info-chips">
// // // // // // // // // //             <span className="info-chip">کد ملک: {property.id}</span>
// // // // // // // // // //             <span className="info-chip">
// // // // // // // // // //               <FaShieldAlt aria-hidden="true" /> {property.certificate}
// // // // // // // // // //             </span>
// // // // // // // // // //             <span className="info-chip type-chip">
// // // // // // // // // //               {isForSale ? 'فروش' : 'رهن و اجاره'}
// // // // // // // // // //             </span>
// // // // // // // // // //           </div>

// // // // // // // // // //           {/* ===== تب‌ها ===== */}
// // // // // // // // // //           <div className="detail-tabs" role="tablist">
// // // // // // // // // //             <button 
// // // // // // // // // //               className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} 
// // // // // // // // // //               onClick={() => setActiveTab('details')}
// // // // // // // // // //               role="tab"
// // // // // // // // // //               aria-selected={activeTab === 'details'}
// // // // // // // // // //               id="tab-details"
// // // // // // // // // //             >
// // // // // // // // // //               جزئیات ملک
// // // // // // // // // //             </button>
// // // // // // // // // //             <button 
// // // // // // // // // //               className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} 
// // // // // // // // // //               onClick={() => setActiveTab('features')}
// // // // // // // // // //               role="tab"
// // // // // // // // // //               aria-selected={activeTab === 'features'}
// // // // // // // // // //               id="tab-features"
// // // // // // // // // //             >
// // // // // // // // // //               امکانات ({property.features.length})
// // // // // // // // // //             </button>
// // // // // // // // // //             <button 
// // // // // // // // // //               className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} 
// // // // // // // // // //               onClick={() => setActiveTab('warnings')}
// // // // // // // // // //               role="tab"
// // // // // // // // // //               aria-selected={activeTab === 'warnings'}
// // // // // // // // // //               id="tab-warnings"
// // // // // // // // // //             >
// // // // // // // // // //               هشدارهای معامله
// // // // // // // // // //             </button>
// // // // // // // // // //             <button 
// // // // // // // // // //               className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} 
// // // // // // // // // //               onClick={() => setActiveTab('nearby')}
// // // // // // // // // //               role="tab"
// // // // // // // // // //               aria-selected={activeTab === 'nearby'}
// // // // // // // // // //               id="tab-nearby"
// // // // // // // // // //             >
// // // // // // // // // //               امکانات اطراف
// // // // // // // // // //             </button>
// // // // // // // // // //           </div>

// // // // // // // // // //           {/* ===== محتوای تب‌ها ===== */}
// // // // // // // // // //           <div className="tab-content" role="tabpanel">
// // // // // // // // // //             {activeTab === 'details' && (
// // // // // // // // // //               <div className="details-tab">
// // // // // // // // // //                 {/* آدرس و موقعیت */}
// // // // // // // // // //                 <div className="address-card">
// // // // // // // // // //                   <FaMapMarkerAlt className="address-icon" aria-hidden="true" />
// // // // // // // // // //                   <div className="address-info">
// // // // // // // // // //                     <h3 className="section-heading">آدرس ملک</h3>
// // // // // // // // // //                     <div className="region-subheading">منطقه {property.regionName}</div>
// // // // // // // // // //                     <p itemProp="address">{property.address}</p>
// // // // // // // // // //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// // // // // // // // // //                   </div>
// // // // // // // // // //                 </div>
                
// // // // // // // // // //                 {/* توضیحات کامل */}
// // // // // // // // // //                 <div className="description-card">
// // // // // // // // // //                   <h3 className="section-heading">توضیحات کامل {property.title}</h3>
// // // // // // // // // //                   <div 
// // // // // // // // // //                     className="description-text" 
// // // // // // // // // //                     itemProp="description"
// // // // // // // // // //                     dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, {
// // // // // // // // // //                       ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'h1', 'h2', 'h3', 'h4', 'ul', 'ol', 'li', 'a', 'blockquote'],
// // // // // // // // // //                       ALLOWED_ATTR: ['href', 'target']
// // // // // // // // // //                     }) }}
// // // // // // // // // //                   />
// // // // // // // // // //                 </div>

// // // // // // // // // //                 {/* نقشه (ثابت - بدون تغییر) */}
// // // // // // // // // //                 <div className="map-card">
// // // // // // // // // //                   <h3 className="section-heading">
// // // // // // // // // //                     <FaMapMarkerAlt aria-hidden="true" />
// // // // // // // // // //                     موقعیت مکانی ملک در منطقه {property.regionName}
// // // // // // // // // //                   </h3>
                  
// // // // // // // // // //                   <div className="map-location-badge">
// // // // // // // // // //                     {property.showExactLocation ? (
// // // // // // // // // //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span>
// // // // // // // // // //                     ) : (
// // // // // // // // // //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی برای حفظ حریم خصوصی</span>
// // // // // // // // // //                     )}
// // // // // // // // // //                   </div>
                  
// // // // // // // // // //                   <div className="map-container" style={{ position: 'relative', overflow: 'hidden' }}>
// // // // // // // // // //                     <NeshanMap
// // // // // // // // // //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90"
// // // // // // // // // //                       center={{ 
// // // // // // // // // //                         latitude: property.location.lat, 
// // // // // // // // // //                         longitude: property.location.lng 
// // // // // // // // // //                       }}
// // // // // // // // // //                       zoom={property.showExactLocation ? 17 : 15.9}
// // // // // // // // // //                       defaultType="dreamy"
// // // // // // // // // //                       poi={true}
// // // // // // // // // //                       traffic={false}
// // // // // // // // // //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }}
// // // // // // // // // //                     />
                    
// // // // // // // // // //                     <div className="map-marker-overlay">
// // // // // // // // // //                       {property.showExactLocation && (
// // // // // // // // // //                         <>
// // // // // // // // // //                           <div className="location-dot"></div>
// // // // // // // // // //                           <div className="location-ripple"></div>
// // // // // // // // // //                         </>
// // // // // // // // // //                       )}
// // // // // // // // // //                       {!property.showExactLocation && (
// // // // // // // // // //                         <div className="location-circles">
// // // // // // // // // //                           <div className="circle-1"></div>
// // // // // // // // // //                           <div className="circle-2"></div>
// // // // // // // // // //                           <div className="circle-3"></div>
// // // // // // // // // //                         </div>
// // // // // // // // // //                       )}
// // // // // // // // // //                     </div>
// // // // // // // // // //                   </div>
                  
// // // // // // // // // //                   <div className="map-privacy-note">
// // // // // // // // // //                     <small>
// // // // // // // // // //                       {property.showExactLocation 
// // // // // // // // // //                         ? '📍 موقعیت دقیق ملک - با تایید مالک نمایش داده می‌شود' 
// // // // // // // // // //                         : '📍 محدوده تقریبی ملک برای حفظ حریم خصوصی'}
// // // // // // // // // //                     </small>
// // // // // // // // // //                   </div>
// // // // // // // // // //                 </div>
// // // // // // // // // //               </div>
// // // // // // // // // //             )}

// // // // // // // // // //             {activeTab === 'features' && (
// // // // // // // // // //               <div className="features-tab">
// // // // // // // // // //                 <h3 className="section-heading">امکانات و ویژگی‌های {property.title}</h3>
// // // // // // // // // //                 <div className="features-grid">
// // // // // // // // // //                   {property.features.length > 0 ? property.features.map((feature, index) => {
// // // // // // // // // //                     let IconComponent = FaCheckCircle;
// // // // // // // // // //                     if (feature.includes('پارکینگ')) IconComponent = FaParking;
// // // // // // // // // //                     else if (feature.includes('انباری')) IconComponent = FaWarehouse;
// // // // // // // // // //                     else if (feature.includes('آسانسور')) IconComponent = FaArrowUp;
// // // // // // // // // //                     else if (feature.includes('استخر')) IconComponent = FaSwimmingPool;
                    
// // // // // // // // // //                     return (
// // // // // // // // // //                       <div key={index} className="feature-card">
// // // // // // // // // //                         <IconComponent className="feature-icon" aria-hidden="true" />
// // // // // // // // // //                         <span>{feature}</span>
// // // // // // // // // //                       </div>
// // // // // // // // // //                     );
// // // // // // // // // //                   }) : (
// // // // // // // // // //                     <p className="no-data">امکاناتی برای این ملک ثبت نشده است</p>
// // // // // // // // // //                   )}
// // // // // // // // // //                 </div>
// // // // // // // // // //               </div>
// // // // // // // // // //             )}

// // // // // // // // // //             {activeTab === 'warnings' && (
// // // // // // // // // //               <div className="warnings-tab">
// // // // // // // // // //                 <h3 className="section-heading">⚠️ هشدارهای مهم قبل از معامله ملک</h3>
// // // // // // // // // //                 <ul className="warnings-list">
// // // // // // // // // //                   {property.warnings.map((warning, index) => (
// // // // // // // // // //                     <li key={index} className="warning-item">
// // // // // // // // // //                       <span className="warning-bullet"></span>
// // // // // // // // // //                       <span>{warning}</span>
// // // // // // // // // //                     </li>
// // // // // // // // // //                   ))}
// // // // // // // // // //                 </ul>
// // // // // // // // // //                 <div className="warning-footer">
// // // // // // // // // //                   <p>⚠️ توجه: لطفاً قبل از هرگونه معامله، مدارک ملک را به دقت بررسی کنید و از مشاور حقوقی کمک بگیرید</p>
// // // // // // // // // //                 </div>
// // // // // // // // // //               </div>
// // // // // // // // // //             )}

// // // // // // // // // //             {activeTab === 'nearby' && (
// // // // // // // // // //               <div className="nearby-tab">
// // // // // // // // // //                 <h3 className="section-heading">امکانات اطراف ملک در منطقه {property.regionName}</h3>
// // // // // // // // // //                 <div className="nearby-list">
// // // // // // // // // //                   {property.nearby.map((item, index) => (
// // // // // // // // // //                     <div key={index} className="nearby-item">
// // // // // // // // // //                       <span className="nearby-name">{item.name}</span>
// // // // // // // // // //                       <span className="nearby-distance">{item.distance}</span>
// // // // // // // // // //                     </div>
// // // // // // // // // //                   ))}
// // // // // // // // // //                 </div>
// // // // // // // // // //               </div>
// // // // // // // // // //             )}
// // // // // // // // // //           </div>

// // // // // // // // // //           {/* ===== اطلاعات مشاور املاک ===== */}
// // // // // // // // // //           <div className="agent-card" itemScope itemType="https://schema.org/RealEstateAgent">
// // // // // // // // // //             <div className="agent-header">
// // // // // // // // // //               <img 
// // // // // // // // // //                 src={property.agent.image} 
// // // // // // // // // //                 alt={property.agent.name} 
// // // // // // // // // //                 className="agent-avatar"
// // // // // // // // // //                 loading="lazy"
// // // // // // // // // //                 width="64"
// // // // // // // // // //                 height="64"
// // // // // // // // // //               />
// // // // // // // // // //               <div className="agent-info">
// // // // // // // // // //                 <h3 className="agent-name" itemProp="name">{property.agent.name}</h3>
// // // // // // // // // //                 <p className="agent-address" itemProp="address">{property.agent.address}</p>
// // // // // // // // // //                 <div className="agent-rating" itemProp="aggregateRating" itemScope itemType="https://schema.org/AggregateRating">
// // // // // // // // // //                   <FaStar className="rating-star" aria-hidden="true" />
// // // // // // // // // //                   <span itemProp="ratingValue">{property.agent.rating}</span>
// // // // // // // // // //                   <span className="rating-count" itemProp="reviewCount">({property.agent.deals} معامله موفق)</span>
// // // // // // // // // //                 </div>
// // // // // // // // // //               </div>
// // // // // // // // // //             </div>
            
// // // // // // // // // //             <div className="agent-actions">
// // // // // // // // // //               <button className="agent-action-btn phone" onClick={handleCopyPhone} aria-label="کپی شماره تماس">
// // // // // // // // // //                 <FaPhone aria-hidden="true" />
// // // // // // // // // //                 {copied ? 'کپی شد!' : 'کپی شماره'}
// // // // // // // // // //               </button>
// // // // // // // // // //               <a 
// // // // // // // // // //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// // // // // // // // // //                 target="_blank" 
// // // // // // // // // //                 rel="noopener noreferrer nofollow"
// // // // // // // // // //                 className="agent-action-btn whatsapp"
// // // // // // // // // //                 aria-label="ارسال پیام در واتساپ"
// // // // // // // // // //               >
// // // // // // // // // //                 <FaWhatsapp aria-hidden="true" />
// // // // // // // // // //                 واتساپ
// // // // // // // // // //               </a>
// // // // // // // // // //             </div>
// // // // // // // // // //           </div>
// // // // // // // // // //         </div>
// // // // // // // // // // {property && (
// // // // // // // // // //   <RelatedPropertiesSlider 
// // // // // // // // // //     currentPropertyId={property.id}
// // // // // // // // // //     regionName={property.regionName}
// // // // // // // // // //     propertyType={property.type}
// // // // // // // // // //   />
// // // // // // // // // // )}
// // // // // // // // // //         {/* ===== نوتیفیکیشن ===== */}
// // // // // // // // // //         {copied && (
// // // // // // // // // //           <div className="toast-notification" role="status" aria-live="polite">
// // // // // // // // // //             <FaCheckCircle aria-hidden="true" />
// // // // // // // // // //             لینک با موفقیت کپی شد
// // // // // // // // // //           </div>
// // // // // // // // // //         )}
// // // // // // // // // //       </div>
// // // // // // // // // //     </>
// // // // // // // // // //   );
// // // // // // // // // // });

// // // // // // // // // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';

// // // // // // // // // // export default RealEstateDetailPageItem;

// // // // // // // // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // // // // // // // import CryptoJS from 'crypto-js';
// // // // // // // // // import DOMPurify from 'dompurify';
// // // // // // // // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // // // // // // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // // // // // // // import DoubleSidebarBanners  from './SidebarBanner';
// // // // // // // // // import { 
// // // // // // // // //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// // // // // // // // //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// // // // // // // // //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// // // // // // // // //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark
// // // // // // // // // } from 'react-icons/fa';
// // // // // // // // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // // // // // // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // // // // // // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // // // // // // // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // // // // // // // // import 'swiper/css';
// // // // // // // // // import 'swiper/css/navigation';
// // // // // // // // // import 'swiper/css/pagination';
// // // // // // // // // import './RealEstateDetailPageItem.css';

// // // // // // // // // const stripHtml = (html) => {
// // // // // // // // //   if (!html) return '';
// // // // // // // // //   const temp = document.createElement('div');
// // // // // // // // //   temp.innerHTML = html;
// // // // // // // // //   return temp.textContent || temp.innerText || '';
// // // // // // // // // };

// // // // // // // // // const truncateText = (text, maxLength) => {
// // // // // // // // //   if (!text) return '';
// // // // // // // // //   if (text.length <= maxLength) return text;
// // // // // // // // //   return text.substring(0, maxLength - 2) + '…';
// // // // // // // // // };

// // // // // // // // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // // // // // // // //   useEffect(() => {
// // // // // // // // //     if (!property) return;
// // // // // // // // //     let title = property.title 
// // // // // // // // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // // // // // // // //       : `ملک ${property.area} متری ${property.regionName}`;
// // // // // // // // //     title = truncateText(title, 65);
// // // // // // // // //     document.title = title;
// // // // // // // // //     const plainDescription = stripHtml(property.description || '');
// // // // // // // // //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// // // // // // // // //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// // // // // // // // //     description = truncateText(description, 155);
// // // // // // // // //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// // // // // // // // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // // // // // // // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // // // // // // // //       let meta = document.querySelector(selector);
// // // // // // // // //       if (!meta) {
// // // // // // // // //         meta = document.createElement('meta');
// // // // // // // // //         if (isProperty) meta.setAttribute('property', name);
// // // // // // // // //         else meta.setAttribute('name', name);
// // // // // // // // //         document.head.appendChild(meta);
// // // // // // // // //       }
// // // // // // // // //       meta.setAttribute('content', content);
// // // // // // // // //     };
// // // // // // // // //     updateOrCreateMeta('description', description);
// // // // // // // // //     updateOrCreateMeta('keywords', keywords);
// // // // // // // // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// // // // // // // // //     let canonical = document.querySelector('link[rel="canonical"]');
// // // // // // // // //     if (!canonical) {
// // // // // // // // //       canonical = document.createElement('link');
// // // // // // // // //       canonical.rel = 'canonical';
// // // // // // // // //       document.head.appendChild(canonical);
// // // // // // // // //     }
// // // // // // // // //     canonical.href = window.location.href;
// // // // // // // // //     updateOrCreateMeta('og:title', title, true);
// // // // // // // // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // // // // // // // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // // // // // // // //     updateOrCreateMeta('og:url', window.location.href, true);
// // // // // // // // //     updateOrCreateMeta('og:type', 'product', true);
// // // // // // // // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // // // // // // // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// // // // // // // // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // // // // // // // //     updateOrCreateMeta('twitter:title', title);
// // // // // // // // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // // // // // // // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// // // // // // // // //     document.documentElement.lang = 'fa';
// // // // // // // // //     document.documentElement.dir = 'rtl';
// // // // // // // // //   }, [property, isForSale, isForRent]);
// // // // // // // // //   return null;
// // // // // // // // // };

// // // // // // // // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // // // // // // // //   useEffect(() => {
// // // // // // // // //     if (!property) return;
// // // // // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// // // // // // // // //     removeOldScript();
// // // // // // // // //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// // // // // // // // //     const structuredData = {
// // // // // // // // //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// // // // // // // // //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// // // // // // // // //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// // // // // // // // //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// // // // // // // // //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// // // // // // // // //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// // // // // // // // //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// // // // // // // // //       "numberOfRooms": property.rooms || 0,
// // // // // // // // //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// // // // // // // // //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// // // // // // // // //     };
// // // // // // // // //     const script = document.createElement('script');
// // // // // // // // //     script.id = 'json-ld-structured-data';
// // // // // // // // //     script.type = 'application/ld+json';
// // // // // // // // //     script.textContent = JSON.stringify(structuredData);
// // // // // // // // //     document.head.appendChild(script);
// // // // // // // // //     return () => removeOldScript();
// // // // // // // // //   }, [property, isForSale, isForRent]);
// // // // // // // // //   return null;
// // // // // // // // // };

// // // // // // // // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // // // // // // // //   useEffect(() => {
// // // // // // // // //     if (!property) return;
// // // // // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// // // // // // // // //     removeOldScript();
// // // // // // // // //     const baseUrl = window.location.origin;
// // // // // // // // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// // // // // // // // //     const breadcrumbData = {
// // // // // // // // //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// // // // // // // // //       "itemListElement": [
// // // // // // // // //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// // // // // // // // //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// // // // // // // // //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// // // // // // // // //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// // // // // // // // //       ]
// // // // // // // // //     };
// // // // // // // // //     const script = document.createElement('script');
// // // // // // // // //     script.id = 'json-ld-breadcrumb';
// // // // // // // // //     script.type = 'application/ld+json';
// // // // // // // // //     script.textContent = JSON.stringify(breadcrumbData);
// // // // // // // // //     document.head.appendChild(script);
// // // // // // // // //     return () => removeOldScript();
// // // // // // // // //   }, [property, isForSale]);
// // // // // // // // //   return null;
// // // // // // // // // };

// // // // // // // // // const DetailSkeleton = () => (
// // // // // // // // //   <div className="detail-skeleton">
// // // // // // // // //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// // // // // // // // //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// // // // // // // // //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// // // // // // // // //   </div>
// // // // // // // // // );

// // // // // // // // // const RealEstateDetailPageItem = memo(() => {
// // // // // // // // //   const location = useLocation();
// // // // // // // // //   const navigate = useNavigate();
// // // // // // // // //   const { id: paramId } = useParams();
// // // // // // // // //   const queryParams = new URLSearchParams(location.search);
// // // // // // // // //   const id = paramId || queryParams.get('id');
// // // // // // // // //   const [property, setProperty] = useState(null);
// // // // // // // // //   const [loading, setLoading] = useState(true);
// // // // // // // // //   const [error, setError] = useState(null);
// // // // // // // // //   const [copied, setCopied] = useState(false);
// // // // // // // // //   const [selectedImage, setSelectedImage] = useState(0);
// // // // // // // // //   const [activeTab, setActiveTab] = useState('details');
// // // // // // // // //   const [isFavorite, setIsFavorite] = useState(false);
// // // // // // // // //   const [imagesLoaded, setImagesLoaded] = useState({});

// // // // // // // // //   useEffect(() => {
// // // // // // // // //     const fetchPropertyData = async () => {
// // // // // // // // //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// // // // // // // // //       setLoading(true); setError(null);
// // // // // // // // //       try {
// // // // // // // // //         const controller = new AbortController();
// // // // // // // // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// // // // // // // // //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// // // // // // // // //         clearTimeout(timeoutId);
// // // // // // // // //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// // // // // // // // //         const result = await response.json();
// // // // // // // // //         if (result.status === 200 && result.data) {
// // // // // // // // //           const data = result.data;
// // // // // // // // //           setProperty({
// // // // // // // // //             id: data.id, title: data.title || `ملک در ${data.regionName || 'منطقه'} `, price: data.price?.toLocaleString("fa-IR") || "۰",
// // // // // // // // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // // // // // // // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // // // // // // // //             type: data.categoryType, area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, rooms: data.rooms || 0,
// // // // // // // // //             floor: data.floor || 1, regionName: data.regionName || "منطقه نامشخص", totalFloors: data.countFloor || 1,
// // // // // // // // //             year: data.constructionYear || "نامشخص", address: data.address || "آدرس درج نشده", showExactLocation: data.showExactLocation,
// // // // // // // // //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// // // // // // // // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", features: data.facilities || [],
// // // // // // // // //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// // // // // // // // //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// // // // // // // // //             agent: { name: data.agents?.name || "مشاور املاک", phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", whatsapp: data.agents?.connectSocialMedia || "", address: data.agents?.address || "آدرس دفتر درج نشده", rating: data.agents?.rating || 4.5, deals: data.agents?.deals || 120, image: data.agents?.image || "https://randomuser.me/api/portraits/men/32.jpg" },
// // // // // // // // //             views: data.views || 0, saved: data.saved || 0, createdAt: data.createdAtPersianRelative || "امروز", certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // // // // // // // //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// // // // // // // // //           });
// // // // // // // // //         } else throw new Error(result.message || 'ملک یافت نشد');
// // // // // // // // //       } catch (error) { console.error('خطا:', error); setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); } 
// // // // // // // // //       finally { setLoading(false); }
// // // // // // // // //     };
// // // // // // // // //     fetchPropertyData();
// // // // // // // // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // // // // // // // //   }, [id]);

// // // // // // // // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // // // // // // // //   const isForRent = useMemo(() => property?.type === 2, [property]);
// // // // // // // // //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// // // // // // // // //   const shareUrl = useMemo(() => window.location.href, []);

// // // // // // // // //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// // // // // // // // //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// // // // // // // // //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// // // // // // // // //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// // // // // // // // //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);

// // // // // // // // //   if (error) return ( <> <PageMetadata property={null} /> <div className="detail-container"><div className="detail-header"><button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button><h1 className="header-title">خطا</h1><div className="header-btn"></div></div><div className="error-message"><h2>متاسفانه خطایی رخ داده است</h2><p>{error}</p><button onClick={() => window.location.reload()}>تلاش مجدد</button><button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button></div></div></> );
// // // // // // // // //   if (loading) return <DetailSkeleton />;
// // // // // // // // //   if (!property) return ( <> <PageMetadata property={null} /> <div className="detail-container"><div className="detail-header"><button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button><h1 className="header-title">ملک یافت نشد</h1><div className="header-btn"></div></div><div className="error-message"><p>متاسفانه ملک مورد نظر یافت نشد</p><button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button></div></div></> );

// // // // // // // // //   return ( <>
// // // // // // // // //     <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // // // //     <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // // // //     <BreadcrumbStructuredData property={property} isForSale={isForSale} />
// // // // // // // // //     <div className="detail-container">
// // // // // // // // //       <nav className="breadcrumb-nav"><ol className="breadcrumb-list"><li className="breadcrumb-item"><a href="/">خانه</a></li><li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li><li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li><li className="breadcrumb-item active">{truncateText(property.title, 50)}</li></ol></nav>
// // // // // // // // //       <div className="detail-header"><button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button><h1 className="header-title">{property.title}</h1><button className="header-btn" onClick={handleShare}><FaShare /></button></div>
// // // // // // // // //       <div className="detail-gallery"><Swiper modules={[Navigation, Pagination, Autoplay]} navigation pagination={{ clickable: true }} autoplay={{ delay: 4000, disableOnInteraction: false }} spaceBetween={0} slidesPerView={1} onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} className="gallery-swiper">{property.images.length > 0 ? property.images.map((img, index) => (<SwiperSlide key={index}><div className="gallery-slide">{!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}<img src={img} alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} loading={index === 0 ? 'eager' : 'lazy'} onLoad={() => handleImageLoad(index)} style={{ display: imagesLoaded[index] ? 'block' : 'none' }} /></div></SwiperSlide>)) : (<SwiperSlide><div className="gallery-slide no-image"><FaHome /><span>تصویری موجود نیست</span></div></SwiperSlide>)}</Swiper><button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>{isFavorite ? <FaHeart /> : <FaRegHeart />}</button><div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div></div>
// // // // // // // // //       <div className="detail-main">
// // // // // // // // //         <div className="detail-title-section"><div className="title-row"><div className="property-stats"><span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span><span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span><span className="stat-badge"><FaClock /> {property.createdAt}</span></div></div></div>
// // // // // // // // //         <div className="price-section">
// // // // // // // // //           {isForSale && (<div className="price-card sale-price"><div className="price-card-icon"><FaTag /></div><div className="price-card-content"><span className="price-label">قیمت فروش</span><div className="price-value-wrapper"><span className="price-number">{property.price}</span><span className="price-unit">تومان</span></div>{formattedPricePerMeter && <div className="price-meta"><FaRuler /><span>متری {formattedPricePerMeter}</span></div>}</div></div>)}
// // // // // // // // //           {isForRent && (<div className="rent-price-group">{property.mortgagePrice && property.mortgagePrice !== "۰" && (<div className="price-card mortgage-price"><div className="price-card-icon"><FaBuilding /></div><div className="price-card-content"><span className="price-label">مبلغ رهن</span><div className="price-value-wrapper"><span className="price-number">{property.mortgagePrice}</span><span className="price-unit">تومان</span></div></div></div>)}{property.rentPrice && property.rentPrice !== "۰" && (<div className="price-card rent-price"><div className="price-card-icon"><FaHome /></div><div className="price-card-content"><span className="price-label">اجاره ماهانه</span><div className="price-value-wrapper"><span className="price-number">{property.rentPrice}</span><span className="price-unit">تومان</span></div></div></div>)}</div>)}
// // // // // // // // //         </div>
// // // // // // // // //         <div className="quick-specs"><div className="spec-item"><FaRulerCombined /><span className="spec-label">متراژ</span><span className="spec-value">{property.area} متر²</span></div><div className="spec-item"><FaBath /><span className="spec-label">اتاق‌خواب</span><span className="spec-value">{property.rooms} خواب</span></div><div className="spec-item"><FaLayerGroup /><span className="spec-label">طبقه</span><span className="spec-value">{property.floor} از {property.totalFloors}</span></div><div className="spec-item"><FaCalendarAlt /><span className="spec-label">سال ساخت</span><span className="spec-value">{property.year}</span></div></div>
// // // // // // // // //         <div className="info-chips"><span className="info-chip">کد ملک: {property.id}</span><span className="info-chip"><FaShieldAlt /> {property.certificate}</span><span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span></div>
// // // // // // // // //         <div className="detail-tabs"><button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button><button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button><button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button><button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button></div>
// // // // // // // // //         <div className="tab-content">
// // // // // // // // //           {activeTab === 'details' && (<div className="details-tab"><div className="address-card"><FaMapMarkerAlt /><div className="address-info"><h3>آدرس ملک</h3><div>منطقه {property.regionName}</div><p>{property.address}</p><span className="post-date">تاریخ درج: {property.createdAt}</span></div></div><div className="description-card"><h3>توضیحات کامل {property.title}</h3><div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} /></div><div className="map-card"><h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3><div className="map-location-badge">{property.showExactLocation ? <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>}</div><div className="map-container"><NeshanMap mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" center={{ latitude: property.location.lat, longitude: property.location.lng }} zoom={property.showExactLocation ? 17 : 15.9} defaultType="dreamy" poi={true} traffic={false} style={{ height: '100%', width: '100%', pointerEvents: 'none' }} /><div className="map-marker-overlay">{property.showExactLocation ? <><div className="location-dot"></div><div className="location-ripple"></div></> : <div className="location-circles"><div className="circle-3"></div></div>}</div></div><div className="map-privacy-note"><small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small></div></div></div>)}
// // // // // // // // //           {activeTab === 'features' && (<div className="features-tab"><h3>امکانات و ویژگی‌ها</h3><div className="features-grid">{property.features.length > 0 ? property.features.map((feature, idx) => { let Icon = FaCheckCircle; if (feature.includes('پارکینگ')) Icon = FaParking; else if (feature.includes('انباری')) Icon = FaWarehouse; else if (feature.includes('آسانسور')) Icon = FaArrowUp; else if (feature.includes('استخر')) Icon = FaSwimmingPool; return (<div key={idx} className="feature-card"><Icon /><span>{feature}</span></div>); }) : <p className="no-data">امکاناتی ثبت نشده است</p>}</div></div>)}
// // // // // // // // //           {activeTab === 'warnings' && (<div className="warnings-tab"><h3>⚠️ هشدارهای مهم</h3><ul className="warnings-list">{property.warnings.map((w, idx) => (<li key={idx} className="warning-item"><span className="warning-bullet"></span><span>{w}</span></li>))}</ul><div className="warning-footer"><p>⚠️ قبل از معامله مدارک را بررسی کنید</p></div></div>)}
// // // // // // // // //           {activeTab === 'nearby' && (<div className="nearby-tab"><h3>امکانات اطراف</h3><div className="nearby-list">{property.nearby.map((item, idx) => (<div key={idx} className="nearby-item"><span className="nearby-name">{item.name}</span><span className="nearby-distance">{item.distance}</span></div>))}</div></div>)}
// // // // // // // // //         </div>
// // // // // // // // //         <div className="agent-card"><div className="agent-header"><img src={property.agent.image} alt={property.agent.name} className="agent-avatar" loading="lazy" /><div className="agent-info"><h3>{property.agent.name}</h3><p>{property.agent.address}</p><div className="agent-rating"><FaStar /><span>{property.agent.rating}</span><span>({property.agent.deals} معامله)</span></div></div></div><div className="agent-actions"><button className="agent-action-btn phone" onClick={handleCopyPhone}><FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}</button><a href={`https://wa.me/${property.agent.whatsapp}`} target="_blank" rel="noopener noreferrer" className="agent-action-btn whatsapp"><FaWhatsapp /> واتساپ</a></div></div>
// // // // // // // // //       </div>
// // // // // // // // //             <DoubleSidebarBanners  />
// // // // // // // // //       <RelatedPropertiesSlider currentPropertyId={property.id} regionName={property.regionName} propertyType={property.type} />
// // // // // // // // //       {copied && <div className="toast-notification"><FaCheckCircle /> لینک کپی شد</div>}
   
// // // // // // // // //     </div>
 
// // // // // // // // //   </> );
// // // // // // // // // });

// // // // // // // // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // // // // // // // // export default RealEstateDetailPageItem;

// // // // // // // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // // // // // // import CryptoJS from 'crypto-js';
// // // // // // // // import DOMPurify from 'dompurify';
// // // // // // // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // // // // // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // // // // // // import DoubleSidebarBanners  from './SidebarBanner';
// // // // // // // // import { 
// // // // // // // //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// // // // // // // //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// // // // // // // //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// // // // // // // //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark
// // // // // // // // } from 'react-icons/fa';
// // // // // // // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // // // // // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // // // // // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // // // // // // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // // // // // // // import 'swiper/css';
// // // // // // // // import 'swiper/css/navigation';
// // // // // // // // import 'swiper/css/pagination';
// // // // // // // // import './RealEstateDetailPageItem.css';

// // // // // // // // // ========== کامپوننت SafeImage ==========
// // // // // // // // const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
// // // // // // // //   const [error, setError] = useState(false);

// // // // // // // //   if (!src || error) {
// // // // // // // //     return (
// // // // // // // //       <img 
// // // // // // // //         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
// // // // // // // //         alt={alt || 'تصویر'} 
// // // // // // // //         className={className}
// // // // // // // //         {...props}
// // // // // // // //       />
// // // // // // // //     );
// // // // // // // //   }

// // // // // // // //   return (
// // // // // // // //     <img
// // // // // // // //       src={src}
// // // // // // // //       alt={alt}
// // // // // // // //       className={className}
// // // // // // // //       onError={() => {
// // // // // // // //         setError(true);
// // // // // // // //       }}
// // // // // // // //       {...props}
// // // // // // // //     />
// // // // // // // //   );
// // // // // // // // };

// // // // // // // // // ========== توابع کمکی ==========
// // // // // // // // const stripHtml = (html) => {
// // // // // // // //   if (!html) return '';
// // // // // // // //   const temp = document.createElement('div');
// // // // // // // //   temp.innerHTML = html;
// // // // // // // //   return temp.textContent || temp.innerText || '';
// // // // // // // // };

// // // // // // // // const truncateText = (text, maxLength) => {
// // // // // // // //   if (!text) return '';
// // // // // // // //   if (text.length <= maxLength) return text;
// // // // // // // //   return text.substring(0, maxLength - 2) + '…';
// // // // // // // // };

// // // // // // // // // ========== کامپوننت‌های متا ==========
// // // // // // // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // // // // // // //   useEffect(() => {
// // // // // // // //     if (!property) return;
// // // // // // // //     let title = property.title 
// // // // // // // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // // // // // // //       : `ملک ${property.area} متری ${property.regionName}`;
// // // // // // // //     title = truncateText(title, 65);
// // // // // // // //     document.title = title;
// // // // // // // //     const plainDescription = stripHtml(property.description || '');
// // // // // // // //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// // // // // // // //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// // // // // // // //     description = truncateText(description, 155);
// // // // // // // //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// // // // // // // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // // // // // // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // // // // // // //       let meta = document.querySelector(selector);
// // // // // // // //       if (!meta) {
// // // // // // // //         meta = document.createElement('meta');
// // // // // // // //         if (isProperty) meta.setAttribute('property', name);
// // // // // // // //         else meta.setAttribute('name', name);
// // // // // // // //         document.head.appendChild(meta);
// // // // // // // //       }
// // // // // // // //       meta.setAttribute('content', content);
// // // // // // // //     };
// // // // // // // //     updateOrCreateMeta('description', description);
// // // // // // // //     updateOrCreateMeta('keywords', keywords);
// // // // // // // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// // // // // // // //     let canonical = document.querySelector('link[rel="canonical"]');
// // // // // // // //     if (!canonical) {
// // // // // // // //       canonical = document.createElement('link');
// // // // // // // //       canonical.rel = 'canonical';
// // // // // // // //       document.head.appendChild(canonical);
// // // // // // // //     }
// // // // // // // //     canonical.href = window.location.href;
// // // // // // // //     updateOrCreateMeta('og:title', title, true);
// // // // // // // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // // // // // // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // // // // // // //     updateOrCreateMeta('og:url', window.location.href, true);
// // // // // // // //     updateOrCreateMeta('og:type', 'product', true);
// // // // // // // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // // // // // // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// // // // // // // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // // // // // // //     updateOrCreateMeta('twitter:title', title);
// // // // // // // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // // // // // // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// // // // // // // //     document.documentElement.lang = 'fa';
// // // // // // // //     document.documentElement.dir = 'rtl';
// // // // // // // //   }, [property, isForSale, isForRent]);
// // // // // // // //   return null;
// // // // // // // // };

// // // // // // // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // // // // // // //   useEffect(() => {
// // // // // // // //     if (!property) return;
// // // // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// // // // // // // //     removeOldScript();
// // // // // // // //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// // // // // // // //     const structuredData = {
// // // // // // // //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// // // // // // // //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// // // // // // // //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// // // // // // // //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// // // // // // // //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// // // // // // // //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// // // // // // // //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// // // // // // // //       "numberOfRooms": property.rooms || 0,
// // // // // // // //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// // // // // // // //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// // // // // // // //     };
// // // // // // // //     const script = document.createElement('script');
// // // // // // // //     script.id = 'json-ld-structured-data';
// // // // // // // //     script.type = 'application/ld+json';
// // // // // // // //     script.textContent = JSON.stringify(structuredData);
// // // // // // // //     document.head.appendChild(script);
// // // // // // // //     return () => removeOldScript();
// // // // // // // //   }, [property, isForSale, isForRent]);
// // // // // // // //   return null;
// // // // // // // // };

// // // // // // // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // // // // // // //   useEffect(() => {
// // // // // // // //     if (!property) return;
// // // // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// // // // // // // //     removeOldScript();
// // // // // // // //     const baseUrl = window.location.origin;
// // // // // // // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// // // // // // // //     const breadcrumbData = {
// // // // // // // //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// // // // // // // //       "itemListElement": [
// // // // // // // //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// // // // // // // //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// // // // // // // //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// // // // // // // //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// // // // // // // //       ]
// // // // // // // //     };
// // // // // // // //     const script = document.createElement('script');
// // // // // // // //     script.id = 'json-ld-breadcrumb';
// // // // // // // //     script.type = 'application/ld+json';
// // // // // // // //     script.textContent = JSON.stringify(breadcrumbData);
// // // // // // // //     document.head.appendChild(script);
// // // // // // // //     return () => removeOldScript();
// // // // // // // //   }, [property, isForSale]);
// // // // // // // //   return null;
// // // // // // // // };

// // // // // // // // // ========== Skeleton ==========
// // // // // // // // const DetailSkeleton = () => (
// // // // // // // //   <div className="detail-skeleton">
// // // // // // // //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// // // // // // // //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// // // // // // // //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// // // // // // // //   </div>
// // // // // // // // );

// // // // // // // // // ========== کامپوننت اصلی ==========
// // // // // // // // const RealEstateDetailPageItem = memo(() => {
// // // // // // // //   const location = useLocation();
// // // // // // // //   const navigate = useNavigate();
// // // // // // // //   const { id: paramId } = useParams();
// // // // // // // //   const queryParams = new URLSearchParams(location.search);
// // // // // // // //   const id = paramId || queryParams.get('id');
// // // // // // // //   const [property, setProperty] = useState(null);
// // // // // // // //   const [loading, setLoading] = useState(true);
// // // // // // // //   const [error, setError] = useState(null);
// // // // // // // //   const [copied, setCopied] = useState(false);
// // // // // // // //   const [selectedImage, setSelectedImage] = useState(0);
// // // // // // // //   const [activeTab, setActiveTab] = useState('details');
// // // // // // // //   const [isFavorite, setIsFavorite] = useState(false);
// // // // // // // //   const [imagesLoaded, setImagesLoaded] = useState({});

// // // // // // // //   useEffect(() => {
// // // // // // // //     const fetchPropertyData = async () => {
// // // // // // // //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// // // // // // // //       setLoading(true); setError(null);
// // // // // // // //       try {
// // // // // // // //         const controller = new AbortController();
// // // // // // // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// // // // // // // //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// // // // // // // //         clearTimeout(timeoutId);
// // // // // // // //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// // // // // // // //         const result = await response.json();
// // // // // // // //         if (result.status === 200 && result.data) {
// // // // // // // //           const data = result.data;
          
// // // // // // // //           // ✅ ساخت آدرس کامل برای عکس مشاور
// // // // // // // //           const agentImage = data.agents?.image 
// // // // // // // //             ? `https://localhost:7178/${data.agents.image}` 
// // // // // // // //             : "https://randomuser.me/api/portraits/men/32.jpg";
          
// // // // // // // //           console.log('📸 Agent image URL:', agentImage); // برای دیباگ
          
// // // // // // // //           setProperty({
// // // // // // // //             id: data.id, 
// // // // // // // //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
// // // // // // // //             price: data.price?.toLocaleString("fa-IR") || "۰",
// // // // // // // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
// // // // // // // //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // // // // // // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
// // // // // // // //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // // // // // // //             type: data.categoryType, 
// // // // // // // //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
// // // // // // // //             rooms: data.rooms || 0,
// // // // // // // //             floor: data.floor || 1, 
// // // // // // // //             regionName: data.regionName || "منطقه نامشخص", 
// // // // // // // //             totalFloors: data.countFloor || 1,
// // // // // // // //             year: data.constructionYear || "نامشخص", 
// // // // // // // //             address: data.address || "آدرس درج نشده", 
// // // // // // // //             showExactLocation: data.showExactLocation,
// // // // // // // //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// // // // // // // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
// // // // // // // //             features: data.facilities || [],
// // // // // // // //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// // // // // // // //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// // // // // // // //             agent: { 
// // // // // // // //               name: data.agents?.name || "مشاور املاک", 
// // // // // // // //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
// // // // // // // //               whatsapp: data.agents?.connectSocialMedia || "", 
// // // // // // // //               address: data.agents?.address || "آدرس دفتر درج نشده", 
// // // // // // // //               rating: data.agents?.rating || 4.5, 
// // // // // // // //               deals: data.agents?.deals || 120, 
// // // // // // // //               image: agentImage // ✅ آدرس کامل عکس مشاور
// // // // // // // //             },
// // // // // // // //             views: data.views || 0, 
// // // // // // // //             saved: data.saved || 0, 
// // // // // // // //             createdAt: data.createdAtPersianRelative || "امروز", 
// // // // // // // //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
// // // // // // // //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // // // // // // //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// // // // // // // //           });
// // // // // // // //         } else throw new Error(result.message || 'ملک یافت نشد');
// // // // // // // //       } catch (error) { 
// // // // // // // //         console.error('خطا:', error); 
// // // // // // // //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
// // // // // // // //       } finally { 
// // // // // // // //         setLoading(false); 
// // // // // // // //       }
// // // // // // // //     };
// // // // // // // //     fetchPropertyData();
// // // // // // // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // // // // // // //   }, [id]);

// // // // // // // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // // // // // // //   const isForRent = useMemo(() => property?.type === 2, [property]);
// // // // // // // //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// // // // // // // //   const shareUrl = useMemo(() => window.location.href, []);

// // // // // // // //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// // // // // // // //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// // // // // // // //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// // // // // // // //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// // // // // // // //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);

// // // // // // // //   if (error) return ( 
// // // // // // // //     <> 
// // // // // // // //       <PageMetadata property={null} /> 
// // // // // // // //       <div className="detail-container">
// // // // // // // //         <div className="detail-header">
// // // // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // // // //           <h1 className="header-title">خطا</h1>
// // // // // // // //           <div className="header-btn"></div>
// // // // // // // //         </div>
// // // // // // // //         <div className="error-message">
// // // // // // // //           <h2>متاسفانه خطایی رخ داده است</h2>
// // // // // // // //           <p>{error}</p>
// // // // // // // //           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
// // // // // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // // // // //         </div>
// // // // // // // //       </div>
// // // // // // // //     </> 
// // // // // // // //   );
  
// // // // // // // //   if (loading) return <DetailSkeleton />;
  
// // // // // // // //   if (!property) return ( 
// // // // // // // //     <> 
// // // // // // // //       <PageMetadata property={null} /> 
// // // // // // // //       <div className="detail-container">
// // // // // // // //         <div className="detail-header">
// // // // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // // // //           <h1 className="header-title">ملک یافت نشد</h1>
// // // // // // // //           <div className="header-btn"></div>
// // // // // // // //         </div>
// // // // // // // //         <div className="error-message">
// // // // // // // //           <p>متاسفانه ملک مورد نظر یافت نشد</p>
// // // // // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // // // // //         </div>
// // // // // // // //       </div>
// // // // // // // //     </> 
// // // // // // // //   );

// // // // // // // //   return ( 
// // // // // // // //     <>
// // // // // // // //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // // //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // // //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
// // // // // // // //       <div className="detail-container">
// // // // // // // //         <nav className="breadcrumb-nav">
// // // // // // // //           <ol className="breadcrumb-list">
// // // // // // // //             <li className="breadcrumb-item"><a href="/">خانه</a></li>
// // // // // // // //             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
// // // // // // // //             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
// // // // // // // //             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
// // // // // // // //           </ol>
// // // // // // // //         </nav>
        
// // // // // // // //         <div className="detail-header">
// // // // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // // // //           <h1 className="header-title">{property.title}</h1>
// // // // // // // //           <button className="header-btn" onClick={handleShare}><FaShare /></button>
// // // // // // // //         </div>
        
// // // // // // // //         <div className="detail-gallery">
// // // // // // // //           <Swiper 
// // // // // // // //             modules={[Navigation, Pagination, Autoplay]} 
// // // // // // // //             navigation 
// // // // // // // //             pagination={{ clickable: true }} 
// // // // // // // //             autoplay={{ delay: 4000, disableOnInteraction: false }} 
// // // // // // // //             spaceBetween={0} 
// // // // // // // //             slidesPerView={1} 
// // // // // // // //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
// // // // // // // //             className="gallery-swiper"
// // // // // // // //           >
// // // // // // // //             {property.images.length > 0 ? 
// // // // // // // //               property.images.map((img, index) => (
// // // // // // // //                 <SwiperSlide key={index}>
// // // // // // // //                   <div className="gallery-slide">
// // // // // // // //                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
// // // // // // // //                     <img 
// // // // // // // //                       src={img} 
// // // // // // // //                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
// // // // // // // //                       loading={index === 0 ? 'eager' : 'lazy'} 
// // // // // // // //                       onLoad={() => handleImageLoad(index)} 
// // // // // // // //                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
// // // // // // // //                     />
// // // // // // // //                   </div>
// // // // // // // //                 </SwiperSlide>
// // // // // // // //               )) : 
// // // // // // // //               (<SwiperSlide>
// // // // // // // //                 <div className="gallery-slide no-image">
// // // // // // // //                   <FaHome />
// // // // // // // //                   <span>تصویری موجود نیست</span>
// // // // // // // //                 </div>
// // // // // // // //               </SwiperSlide>)
// // // // // // // //             }
// // // // // // // //           </Swiper>
// // // // // // // //           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
// // // // // // // //             {isFavorite ? <FaHeart /> : <FaRegHeart />}
// // // // // // // //           </button>
// // // // // // // //           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
// // // // // // // //         </div>
        
// // // // // // // //         <div className="detail-main">
// // // // // // // //           <div className="detail-title-section">
// // // // // // // //             <div className="title-row">
// // // // // // // //               <div className="property-stats">
// // // // // // // //                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
// // // // // // // //                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
// // // // // // // //                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
// // // // // // // //               </div>
// // // // // // // //             </div>
// // // // // // // //           </div>
          
// // // // // // // //           <div className="price-section">
// // // // // // // //             {isForSale && (
// // // // // // // //               <div className="price-card sale-price">
// // // // // // // //                 <div className="price-card-icon"><FaTag /></div>
// // // // // // // //                 <div className="price-card-content">
// // // // // // // //                   <span className="price-label">قیمت فروش</span>
// // // // // // // //                   <div className="price-value-wrapper">
// // // // // // // //                     <span className="price-number">{property.price}</span>
// // // // // // // //                     <span className="price-unit">تومان</span>
// // // // // // // //                   </div>
// // // // // // // //                   {formattedPricePerMeter && 
// // // // // // // //                     <div className="price-meta">
// // // // // // // //                       <FaRuler />
// // // // // // // //                       <span>متری {formattedPricePerMeter}</span>
// // // // // // // //                     </div>
// // // // // // // //                   }
// // // // // // // //                 </div>
// // // // // // // //               </div>
// // // // // // // //             )}
            
// // // // // // // //             {isForRent && (
// // // // // // // //               <div className="rent-price-group">
// // // // // // // //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// // // // // // // //                   <div className="price-card mortgage-price">
// // // // // // // //                     <div className="price-card-icon"><FaBuilding /></div>
// // // // // // // //                     <div className="price-card-content">
// // // // // // // //                       <span className="price-label">مبلغ رهن</span>
// // // // // // // //                       <div className="price-value-wrapper">
// // // // // // // //                         <span className="price-number">{property.mortgagePrice}</span>
// // // // // // // //                         <span className="price-unit">تومان</span>
// // // // // // // //                       </div>
// // // // // // // //                     </div>
// // // // // // // //                   </div>
// // // // // // // //                 )}
// // // // // // // //                 {property.rentPrice && property.rentPrice !== "۰" && (
// // // // // // // //                   <div className="price-card rent-price">
// // // // // // // //                     <div className="price-card-icon"><FaHome /></div>
// // // // // // // //                     <div className="price-card-content">
// // // // // // // //                       <span className="price-label">اجاره ماهانه</span>
// // // // // // // //                       <div className="price-value-wrapper">
// // // // // // // //                         <span className="price-number">{property.rentPrice}</span>
// // // // // // // //                         <span className="price-unit">تومان</span>
// // // // // // // //                       </div>
// // // // // // // //                     </div>
// // // // // // // //                   </div>
// // // // // // // //                 )}
// // // // // // // //               </div>
// // // // // // // //             )}
// // // // // // // //           </div>
          
// // // // // // // //           <div className="quick-specs">
// // // // // // // //             <div className="spec-item">
// // // // // // // //               <FaRulerCombined />
// // // // // // // //               <span className="spec-label">متراژ</span>
// // // // // // // //               <span className="spec-value">{property.area} متر²</span>
// // // // // // // //             </div>
// // // // // // // //             <div className="spec-item">
// // // // // // // //               <FaBath />
// // // // // // // //               <span className="spec-label">اتاق‌خواب</span>
// // // // // // // //               <span className="spec-value">{property.rooms} خواب</span>
// // // // // // // //             </div>
// // // // // // // //             <div className="spec-item">
// // // // // // // //               <FaLayerGroup />
// // // // // // // //               <span className="spec-label">طبقه</span>
// // // // // // // //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// // // // // // // //             </div>
// // // // // // // //             <div className="spec-item">
// // // // // // // //               <FaCalendarAlt />
// // // // // // // //               <span className="spec-label">سال ساخت</span>
// // // // // // // //               <span className="spec-value">{property.year}</span>
// // // // // // // //             </div>
// // // // // // // //           </div>
          
// // // // // // // //           <div className="info-chips">
// // // // // // // //             <span className="info-chip">کد ملک: {property.id}</span>
// // // // // // // //             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
// // // // // // // //             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
// // // // // // // //           </div>
          
// // // // // // // //           <div className="detail-tabs">
// // // // // // // //             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
// // // // // // // //             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
// // // // // // // //             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
// // // // // // // //             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
// // // // // // // //           </div>
          
// // // // // // // //           <div className="tab-content">
// // // // // // // //             {activeTab === 'details' && (
// // // // // // // //               <div className="details-tab">
// // // // // // // //                 <div className="address-card">
// // // // // // // //                   <FaMapMarkerAlt />
// // // // // // // //                   <div className="address-info">
// // // // // // // //                     <h3>آدرس ملک</h3>
// // // // // // // //                     <div>منطقه {property.regionName}</div>
// // // // // // // //                     <p>{property.address}</p>
// // // // // // // //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// // // // // // // //                   </div>
// // // // // // // //                 </div>
// // // // // // // //                 <div className="description-card">
// // // // // // // //                   <h3>توضیحات کامل {property.title}</h3>
// // // // // // // //                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
// // // // // // // //                 </div>
// // // // // // // //                 <div className="map-card">
// // // // // // // //                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
// // // // // // // //                   <div className="map-location-badge">
// // // // // // // //                     {property.showExactLocation ? 
// // // // // // // //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
// // // // // // // //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
// // // // // // // //                     }
// // // // // // // //                   </div>
// // // // // // // //                   <div className="map-container">
// // // // // // // //                     <NeshanMap 
// // // // // // // //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
// // // // // // // //                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
// // // // // // // //                       zoom={property.showExactLocation ? 17 : 15.9} 
// // // // // // // //                       defaultType="dreamy" 
// // // // // // // //                       poi={true} 
// // // // // // // //                       traffic={false} 
// // // // // // // //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
// // // // // // // //                     />
// // // // // // // //                     <div className="map-marker-overlay">
// // // // // // // //                       {property.showExactLocation ? 
// // // // // // // //                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
// // // // // // // //                         <div className="location-circles"><div className="circle-3"></div></div>
// // // // // // // //                       }
// // // // // // // //                     </div>
// // // // // // // //                   </div>
// // // // // // // //                   <div className="map-privacy-note">
// // // // // // // //                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
// // // // // // // //                   </div>
// // // // // // // //                 </div>
// // // // // // // //               </div>
// // // // // // // //             )}
            
// // // // // // // //             {activeTab === 'features' && (
// // // // // // // //               <div className="features-tab">
// // // // // // // //                 <h3>امکانات و ویژگی‌ها</h3>
// // // // // // // //                 <div className="features-grid">
// // // // // // // //                   {property.features.length > 0 ? 
// // // // // // // //                     property.features.map((feature, idx) => {
// // // // // // // //                       let Icon = FaCheckCircle;
// // // // // // // //                       if (feature.includes('پارکینگ')) Icon = FaParking;
// // // // // // // //                       else if (feature.includes('انباری')) Icon = FaWarehouse;
// // // // // // // //                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
// // // // // // // //                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
// // // // // // // //                       return (
// // // // // // // //                         <div key={idx} className="feature-card">
// // // // // // // //                           <Icon />
// // // // // // // //                           <span>{feature}</span>
// // // // // // // //                         </div>
// // // // // // // //                       );
// // // // // // // //                     }) : 
// // // // // // // //                     <p className="no-data">امکاناتی ثبت نشده است</p>
// // // // // // // //                   }
// // // // // // // //                 </div>
// // // // // // // //               </div>
// // // // // // // //             )}
            
// // // // // // // //             {activeTab === 'warnings' && (
// // // // // // // //               <div className="warnings-tab">
// // // // // // // //                 <h3>⚠️ هشدارهای مهم</h3>
// // // // // // // //                 <ul className="warnings-list">
// // // // // // // //                   {property.warnings.map((w, idx) => (
// // // // // // // //                     <li key={idx} className="warning-item">
// // // // // // // //                       <span className="warning-bullet"></span>
// // // // // // // //                       <span>{w}</span>
// // // // // // // //                     </li>
// // // // // // // //                   ))}
// // // // // // // //                 </ul>
// // // // // // // //                 <div className="warning-footer">
// // // // // // // //                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
// // // // // // // //                 </div>
// // // // // // // //               </div>
// // // // // // // //             )}
            
// // // // // // // //             {activeTab === 'nearby' && (
// // // // // // // //               <div className="nearby-tab">
// // // // // // // //                 <h3>امکانات اطراف</h3>
// // // // // // // //                 <div className="nearby-list">
// // // // // // // //                   {property.nearby.map((item, idx) => (
// // // // // // // //                     <div key={idx} className="nearby-item">
// // // // // // // //                       <span className="nearby-name">{item.name}</span>
// // // // // // // //                       <span className="nearby-distance">{item.distance}</span>
// // // // // // // //                     </div>
// // // // // // // //                   ))}
// // // // // // // //                 </div>
// // // // // // // //               </div>
// // // // // // // //             )}
// // // // // // // //           </div>
          
// // // // // // // //           {/* ========== کارت مشاور با SafeImage ========== */}
// // // // // // // //           <div className="agent-card">
// // // // // // // //             <div className="agent-header">
// // // // // // // //               <SafeImage 
// // // // // // // //                 src={property.agent.image} 
// // // // // // // //                 alt={property.agent.name} 
// // // // // // // //                 className="agent-avatar" 
// // // // // // // //                 fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
// // // // // // // //               />
// // // // // // // //               <div className="agent-info">
// // // // // // // //                 <h3>{property.agent.name}</h3>
// // // // // // // //                 <p>{property.agent.address}</p>
// // // // // // // //                 <div className="agent-rating">
// // // // // // // //                   <FaStar />
// // // // // // // //                   <span>{property.agent.rating}</span>
// // // // // // // //                   <span>({property.agent.deals} معامله)</span>
// // // // // // // //                 </div>
// // // // // // // //               </div>
// // // // // // // //             </div>
// // // // // // // //             <div className="agent-actions">
// // // // // // // //               <button className="agent-action-btn phone" onClick={handleCopyPhone}>
// // // // // // // //                 <FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}
// // // // // // // //               </button>
// // // // // // // //               <a 
// // // // // // // //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// // // // // // // //                 target="_blank" 
// // // // // // // //                 rel="noopener noreferrer" 
// // // // // // // //                 className="agent-action-btn whatsapp"
// // // // // // // //               >
// // // // // // // //                 <FaWhatsapp /> واتساپ
// // // // // // // //               </a>
// // // // // // // //             </div>
// // // // // // // //           </div>
// // // // // // // //         </div>
        
// // // // // // // //         <DoubleSidebarBanners />
// // // // // // // //         <RelatedPropertiesSlider 
// // // // // // // //           currentPropertyId={property.id} 
// // // // // // // //           regionName={property.regionName} 
// // // // // // // //           propertyType={property.type} 
// // // // // // // //         />
        
// // // // // // // //         {copied && (
// // // // // // // //           <div className="toast-notification">
// // // // // // // //             <FaCheckCircle /> لینک کپی شد
// // // // // // // //           </div>
// // // // // // // //         )}
// // // // // // // //       </div>
// // // // // // // //     </> 
// // // // // // // //   );
// // // // // // // // });

// // // // // // // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // // // // // // // export default RealEstateDetailPageItem;

// // // // // // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // // // // // import CryptoJS from 'crypto-js';
// // // // // // // import DOMPurify from 'dompurify';
// // // // // // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // // // // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // // // // // import DoubleSidebarBanners  from './SidebarBanner';
// // // // // // // import { 
// // // // // // //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// // // // // // //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// // // // // // //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// // // // // // //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaPlay  // ✅ FaPlay اضافه شد
// // // // // // // } from 'react-icons/fa';
// // // // // // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // // // // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // // // // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // // // // // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // // // // // // import 'swiper/css';
// // // // // // // import 'swiper/css/navigation';
// // // // // // // import 'swiper/css/pagination';
// // // // // // // import './RealEstateDetailPageItem.css';

// // // // // // // // ========== کامپوننت استوری ==========
// // // // // // // const StoryIndicator = ({ hasStory, agentName, agentImage, onStoryClick }) => {
// // // // // // //   if (!hasStory) return null;
  
// // // // // // //   return (
// // // // // // //     <div className="story-indicator-wrapper" onClick={onStoryClick}>
// // // // // // //       <div className="story-ring">
// // // // // // //         <img 
// // // // // // //           src={agentImage} 
// // // // // // //           alt={agentName} 
// // // // // // //           className="story-avatar"
// // // // // // //         />
// // // // // // //         <div className="story-gradient-ring"></div>
// // // // // // //       </div>
// // // // // // //       <div className="story-badge">
// // // // // // //         <span>استوری</span>
// // // // // // //       </div>
// // // // // // //     </div>
// // // // // // //   );
// // // // // // // };

// // // // // // // // ========== کامپوننت پاپ‌آپ استوری ==========
// // // // // // // const StoryPopup = ({ agentName, agentImage, hasStory, onClose }) => {
// // // // // // //   const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
// // // // // // //   const [progress, setProgress] = useState(0);
// // // // // // //   const [isPaused, setIsPaused] = useState(false);

// // // // // // //   // نمونه استوری‌ها - در API واقعی این‌ها از سرور می‌آیند
// // // // // // //   const stories = hasStory ? [
// // // // // // //     { type: 'image', url: agentImage, duration: 5000 },
// // // // // // //     { type: 'image', url: 'https://via.placeholder.com/600x800/7d0000/ffffff?text=استوری+2', duration: 5000 },
// // // // // // //     { type: 'image', url: 'https://via.placeholder.com/600x800/a30000/ffffff?text=استوری+3', duration: 5000 }
// // // // // // //   ] : [];

// // // // // // //   useEffect(() => {
// // // // // // //     if (!isPaused && stories.length > 0) {
// // // // // // //       const timer = setInterval(() => {
// // // // // // //         setProgress(prev => {
// // // // // // //           const newProgress = prev + 1;
// // // // // // //           if (newProgress >= 100) {
// // // // // // //             if (currentStoryIndex < stories.length - 1) {
// // // // // // //               setCurrentStoryIndex(prev => prev + 1);
// // // // // // //               return 0;
// // // // // // //             } else {
// // // // // // //               onClose();
// // // // // // //               return 0;
// // // // // // //             }
// // // // // // //           }
// // // // // // //           return newProgress;
// // // // // // //         });
// // // // // // //       }, stories[currentStoryIndex]?.duration / 100 || 50);

// // // // // // //       return () => clearInterval(timer);
// // // // // // //     }
// // // // // // //   }, [currentStoryIndex, isPaused, stories, onClose]);

// // // // // // //   if (!hasStory || stories.length === 0) return null;

// // // // // // //   return (
// // // // // // //     <div 
// // // // // // //       className="story-popup-overlay"
// // // // // // //       onClick={onClose}
// // // // // // //       onMouseEnter={() => setIsPaused(true)}
// // // // // // //       onMouseLeave={() => setIsPaused(false)}
// // // // // // //     >
// // // // // // //       <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // // // // //         {/* Progress bars */}
// // // // // // //         <div className="story-progress-container">
// // // // // // //           {stories.map((_, index) => (
// // // // // // //             <div 
// // // // // // //               key={index} 
// // // // // // //               className="story-progress-bar"
// // // // // // //             >
// // // // // // //               <div 
// // // // // // //                 className="story-progress-fill"
// // // // // // //                 style={{
// // // // // // //                   width: index < currentStoryIndex ? '100%' : 
// // // // // // //                          index === currentStoryIndex ? `${progress}%` : '0%'
// // // // // // //                 }}
// // // // // // //               />
// // // // // // //             </div>
// // // // // // //           ))}
// // // // // // //         </div>

// // // // // // //         {/* Header */}
// // // // // // //         <div className="story-header">
// // // // // // //           <div className="story-user-info">
// // // // // // //             <img 
// // // // // // //               src={agentImage} 
// // // // // // //               alt={agentName} 
// // // // // // //               className="story-user-avatar"
// // // // // // //             />
// // // // // // //             <span className="story-user-name">{agentName}</span>
// // // // // // //             <span className="story-time">لحظاتی پیش</span>
// // // // // // //           </div>
// // // // // // //           <button className="story-close-btn" onClick={onClose}>✕</button>
// // // // // // //         </div>

// // // // // // //         {/* Story content */}
// // // // // // //         <div className="story-content">
// // // // // // //           <img 
// // // // // // //             src={stories[currentStoryIndex]?.url} 
// // // // // // //             alt={`استوری ${currentStoryIndex + 1}`}
// // // // // // //             className="story-image"
// // // // // // //           />
// // // // // // //         </div>

// // // // // // //         {/* Navigation buttons */}
// // // // // // //         <div 
// // // // // // //           className="story-nav-left"
// // // // // // //           onClick={(e) => {
// // // // // // //             e.stopPropagation();
// // // // // // //             if (currentStoryIndex > 0) {
// // // // // // //               setCurrentStoryIndex(prev => prev - 1);
// // // // // // //               setProgress(0);
// // // // // // //             }
// // // // // // //           }}
// // // // // // //         />
// // // // // // //         <div 
// // // // // // //           className="story-nav-right"
// // // // // // //           onClick={(e) => {
// // // // // // //             e.stopPropagation();
// // // // // // //             if (currentStoryIndex < stories.length - 1) {
// // // // // // //               setCurrentStoryIndex(prev => prev + 1);
// // // // // // //               setProgress(0);
// // // // // // //             } else {
// // // // // // //               onClose();
// // // // // // //             }
// // // // // // //           }}
// // // // // // //         />
// // // // // // //       </div>
// // // // // // //     </div>
// // // // // // //   );
// // // // // // // };

// // // // // // // // ========== کامپوننت SafeImage ==========
// // // // // // // const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
// // // // // // //   const [error, setError] = useState(false);

// // // // // // //   if (!src || error) {
// // // // // // //     return (
// // // // // // //       <img 
// // // // // // //         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
// // // // // // //         alt={alt || 'تصویر'} 
// // // // // // //         className={className}
// // // // // // //         {...props}
// // // // // // //       />
// // // // // // //     );
// // // // // // //   }

// // // // // // //   return (
// // // // // // //     <img
// // // // // // //       src={src}
// // // // // // //       alt={alt}
// // // // // // //       className={className}
// // // // // // //       onError={() => {
// // // // // // //         setError(true);
// // // // // // //       }}
// // // // // // //       {...props}
// // // // // // //     />
// // // // // // //   );
// // // // // // // };

// // // // // // // // ========== توابع کمکی ==========
// // // // // // // const stripHtml = (html) => {
// // // // // // //   if (!html) return '';
// // // // // // //   const temp = document.createElement('div');
// // // // // // //   temp.innerHTML = html;
// // // // // // //   return temp.textContent || temp.innerText || '';
// // // // // // // };

// // // // // // // const truncateText = (text, maxLength) => {
// // // // // // //   if (!text) return '';
// // // // // // //   if (text.length <= maxLength) return text;
// // // // // // //   return text.substring(0, maxLength - 2) + '…';
// // // // // // // };

// // // // // // // // ========== کامپوننت‌های متا ==========
// // // // // // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // // // // // //   useEffect(() => {
// // // // // // //     if (!property) return;
// // // // // // //     let title = property.title 
// // // // // // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // // // // // //       : `ملک ${property.area} متری ${property.regionName}`;
// // // // // // //     title = truncateText(title, 65);
// // // // // // //     document.title = title;
// // // // // // //     const plainDescription = stripHtml(property.description || '');
// // // // // // //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// // // // // // //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// // // // // // //     description = truncateText(description, 155);
// // // // // // //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// // // // // // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // // // // // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // // // // // //       let meta = document.querySelector(selector);
// // // // // // //       if (!meta) {
// // // // // // //         meta = document.createElement('meta');
// // // // // // //         if (isProperty) meta.setAttribute('property', name);
// // // // // // //         else meta.setAttribute('name', name);
// // // // // // //         document.head.appendChild(meta);
// // // // // // //       }
// // // // // // //       meta.setAttribute('content', content);
// // // // // // //     };
// // // // // // //     updateOrCreateMeta('description', description);
// // // // // // //     updateOrCreateMeta('keywords', keywords);
// // // // // // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// // // // // // //     let canonical = document.querySelector('link[rel="canonical"]');
// // // // // // //     if (!canonical) {
// // // // // // //       canonical = document.createElement('link');
// // // // // // //       canonical.rel = 'canonical';
// // // // // // //       document.head.appendChild(canonical);
// // // // // // //     }
// // // // // // //     canonical.href = window.location.href;
// // // // // // //     updateOrCreateMeta('og:title', title, true);
// // // // // // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // // // // // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // // // // // //     updateOrCreateMeta('og:url', window.location.href, true);
// // // // // // //     updateOrCreateMeta('og:type', 'product', true);
// // // // // // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // // // // // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// // // // // // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // // // // // //     updateOrCreateMeta('twitter:title', title);
// // // // // // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // // // // // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// // // // // // //     document.documentElement.lang = 'fa';
// // // // // // //     document.documentElement.dir = 'rtl';
// // // // // // //   }, [property, isForSale, isForRent]);
// // // // // // //   return null;
// // // // // // // };

// // // // // // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // // // // // //   useEffect(() => {
// // // // // // //     if (!property) return;
// // // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// // // // // // //     removeOldScript();
// // // // // // //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// // // // // // //     const structuredData = {
// // // // // // //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// // // // // // //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// // // // // // //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// // // // // // //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// // // // // // //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// // // // // // //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// // // // // // //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// // // // // // //       "numberOfRooms": property.rooms || 0,
// // // // // // //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// // // // // // //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// // // // // // //     };
// // // // // // //     const script = document.createElement('script');
// // // // // // //     script.id = 'json-ld-structured-data';
// // // // // // //     script.type = 'application/ld+json';
// // // // // // //     script.textContent = JSON.stringify(structuredData);
// // // // // // //     document.head.appendChild(script);
// // // // // // //     return () => removeOldScript();
// // // // // // //   }, [property, isForSale, isForRent]);
// // // // // // //   return null;
// // // // // // // };

// // // // // // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // // // // // //   useEffect(() => {
// // // // // // //     if (!property) return;
// // // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// // // // // // //     removeOldScript();
// // // // // // //     const baseUrl = window.location.origin;
// // // // // // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// // // // // // //     const breadcrumbData = {
// // // // // // //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// // // // // // //       "itemListElement": [
// // // // // // //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// // // // // // //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// // // // // // //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// // // // // // //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// // // // // // //       ]
// // // // // // //     };
// // // // // // //     const script = document.createElement('script');
// // // // // // //     script.id = 'json-ld-breadcrumb';
// // // // // // //     script.type = 'application/ld+json';
// // // // // // //     script.textContent = JSON.stringify(breadcrumbData);
// // // // // // //     document.head.appendChild(script);
// // // // // // //     return () => removeOldScript();
// // // // // // //   }, [property, isForSale]);
// // // // // // //   return null;
// // // // // // // };

// // // // // // // // ========== Skeleton ==========
// // // // // // // const DetailSkeleton = () => (
// // // // // // //   <div className="detail-skeleton">
// // // // // // //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// // // // // // //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// // // // // // //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// // // // // // //   </div>
// // // // // // // );

// // // // // // // // ========== کامپوننت اصلی ==========
// // // // // // // const RealEstateDetailPageItem = memo(() => {
// // // // // // //   const location = useLocation();
// // // // // // //   const navigate = useNavigate();
// // // // // // //   const { id: paramId } = useParams();
// // // // // // //   const queryParams = new URLSearchParams(location.search);
// // // // // // //   const id = paramId || queryParams.get('id');
// // // // // // //   const [property, setProperty] = useState(null);
// // // // // // //   const [loading, setLoading] = useState(true);
// // // // // // //   const [error, setError] = useState(null);
// // // // // // //   const [copied, setCopied] = useState(false);
// // // // // // //   const [selectedImage, setSelectedImage] = useState(0);
// // // // // // //   const [activeTab, setActiveTab] = useState('details');
// // // // // // //   const [isFavorite, setIsFavorite] = useState(false);
// // // // // // //   const [imagesLoaded, setImagesLoaded] = useState({});
// // // // // // //   const [showStoryPopup, setShowStoryPopup] = useState(false);

// // // // // // //   useEffect(() => {
// // // // // // //     const fetchPropertyData = async () => {
// // // // // // //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// // // // // // //       setLoading(true); setError(null);
// // // // // // //       try {
// // // // // // //         const controller = new AbortController();
// // // // // // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// // // // // // //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// // // // // // //         clearTimeout(timeoutId);
// // // // // // //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// // // // // // //         const result = await response.json();
// // // // // // //         if (result.status === 200 && result.data) {
// // // // // // //           const data = result.data;
          
// // // // // // //           const agentImage = data.agents?.image 
// // // // // // //             ? `https://localhost:7178/${data.agents.image}` 
// // // // // // //             : "https://randomuser.me/api/portraits/men/32.jpg";
          
// // // // // // //           console.log('📸 Agent hasStory:', data.agents?.hasStory); // برای دیباگ
          
// // // // // // //           setProperty({
// // // // // // //             id: data.id, 
// // // // // // //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
// // // // // // //             price: data.price?.toLocaleString("fa-IR") || "۰",
// // // // // // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
// // // // // // //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // // // // // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
// // // // // // //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // // // // // //             type: data.categoryType, 
// // // // // // //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
// // // // // // //             rooms: data.rooms || 0,
// // // // // // //             floor: data.floor || 1, 
// // // // // // //             regionName: data.regionName || "منطقه نامشخص", 
// // // // // // //             totalFloors: data.countFloor || 1,
// // // // // // //             year: data.constructionYear || "نامشخص", 
// // // // // // //             address: data.address || "آدرس درج نشده", 
// // // // // // //             showExactLocation: data.showExactLocation,
// // // // // // //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// // // // // // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
// // // // // // //             features: data.facilities || [],
// // // // // // //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// // // // // // //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// // // // // // //             agent: { 
// // // // // // //               name: data.agents?.name || "مشاور املاک", 
// // // // // // //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
// // // // // // //               whatsapp: data.agents?.connectSocialMedia || "", 
// // // // // // //               address: data.agents?.address || "آدرس دفتر درج نشده", 
// // // // // // //               rating: data.agents?.rating || 4.5, 
// // // // // // //               deals: data.agents?.deals || 120, 
// // // // // // //               image: agentImage,
// // // // // // //               hasStory: data.agents?.hasStory || false // ✅ دریافت از API
// // // // // // //             },
// // // // // // //             views: data.views || 0, 
// // // // // // //             saved: data.saved || 0, 
// // // // // // //             createdAt: data.createdAtPersianRelative || "امروز", 
// // // // // // //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
// // // // // // //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // // // // // //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// // // // // // //           });
// // // // // // //         } else throw new Error(result.message || 'ملک یافت نشد');
// // // // // // //       } catch (error) { 
// // // // // // //         console.error('خطا:', error); 
// // // // // // //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
// // // // // // //       } finally { 
// // // // // // //         setLoading(false); 
// // // // // // //       }
// // // // // // //     };
// // // // // // //     fetchPropertyData();
// // // // // // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // // // // // //   }, [id]);

// // // // // // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // // // // // //   const isForRent = useMemo(() => property?.type === 2, [property]);
// // // // // // //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// // // // // // //   const shareUrl = useMemo(() => window.location.href, []);

// // // // // // //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// // // // // // //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// // // // // // //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// // // // // // //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// // // // // // //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
// // // // // // //   // ✅ هندلر باز کردن استوری
// // // // // // //   const handleStoryClick = useCallback(() => {
// // // // // // //     if (property?.agent?.hasStory) {
// // // // // // //       setShowStoryPopup(true);
// // // // // // //       document.body.style.overflow = 'hidden';
// // // // // // //     }
// // // // // // //   }, [property]);

// // // // // // //   // ✅ هندلر بستن استوری
// // // // // // //   const handleStoryClose = useCallback(() => {
// // // // // // //     setShowStoryPopup(false);
// // // // // // //     document.body.style.overflow = '';
// // // // // // //   }, []);

// // // // // // //   if (error) return ( 
// // // // // // //     <> 
// // // // // // //       <PageMetadata property={null} /> 
// // // // // // //       <div className="detail-container">
// // // // // // //         <div className="detail-header">
// // // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // // //           <h1 className="header-title">خطا</h1>
// // // // // // //           <div className="header-btn"></div>
// // // // // // //         </div>
// // // // // // //         <div className="error-message">
// // // // // // //           <h2>متاسفانه خطایی رخ داده است</h2>
// // // // // // //           <p>{error}</p>
// // // // // // //           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
// // // // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // // // //         </div>
// // // // // // //       </div>
// // // // // // //     </> 
// // // // // // //   );
  
// // // // // // //   if (loading) return <DetailSkeleton />;
  
// // // // // // //   if (!property) return ( 
// // // // // // //     <> 
// // // // // // //       <PageMetadata property={null} /> 
// // // // // // //       <div className="detail-container">
// // // // // // //         <div className="detail-header">
// // // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // // //           <h1 className="header-title">ملک یافت نشد</h1>
// // // // // // //           <div className="header-btn"></div>
// // // // // // //         </div>
// // // // // // //         <div className="error-message">
// // // // // // //           <p>متاسفانه ملک مورد نظر یافت نشد</p>
// // // // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // // // //         </div>
// // // // // // //       </div>
// // // // // // //     </> 
// // // // // // //   );

// // // // // // //   return ( 
// // // // // // //     <>
// // // // // // //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // // //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
// // // // // // //       {/* ✅ پاپ‌آپ استوری */}
// // // // // // //       {showStoryPopup && (
// // // // // // //         <StoryPopup 
// // // // // // //           agentName={property.agent.name}
// // // // // // //           agentImage={property.agent.image}
// // // // // // //           hasStory={property.agent.hasStory}
// // // // // // //           onClose={handleStoryClose}
// // // // // // //         />
// // // // // // //       )}
      
// // // // // // //       <div className="detail-container">
// // // // // // //         <nav className="breadcrumb-nav">
// // // // // // //           <ol className="breadcrumb-list">
// // // // // // //             <li className="breadcrumb-item"><a href="/">خانه</a></li>
// // // // // // //             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
// // // // // // //             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
// // // // // // //             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
// // // // // // //           </ol>
// // // // // // //         </nav>
        
// // // // // // //         <div className="detail-header">
// // // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // // //           <h1 className="header-title">{property.title}</h1>
// // // // // // //           <button className="header-btn" onClick={handleShare}><FaShare /></button>
// // // // // // //         </div>
        
// // // // // // //         <div className="detail-gallery">
// // // // // // //           <Swiper 
// // // // // // //             modules={[Navigation, Pagination, Autoplay]} 
// // // // // // //             navigation 
// // // // // // //             pagination={{ clickable: true }} 
// // // // // // //             autoplay={{ delay: 4000, disableOnInteraction: false }} 
// // // // // // //             spaceBetween={0} 
// // // // // // //             slidesPerView={1} 
// // // // // // //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
// // // // // // //             className="gallery-swiper"
// // // // // // //           >
// // // // // // //             {property.images.length > 0 ? 
// // // // // // //               property.images.map((img, index) => (
// // // // // // //                 <SwiperSlide key={index}>
// // // // // // //                   <div className="gallery-slide">
// // // // // // //                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
// // // // // // //                     <img 
// // // // // // //                       src={img} 
// // // // // // //                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
// // // // // // //                       loading={index === 0 ? 'eager' : 'lazy'} 
// // // // // // //                       onLoad={() => handleImageLoad(index)} 
// // // // // // //                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
// // // // // // //                     />
// // // // // // //                   </div>
// // // // // // //                 </SwiperSlide>
// // // // // // //               )) : 
// // // // // // //               (<SwiperSlide>
// // // // // // //                 <div className="gallery-slide no-image">
// // // // // // //                   <FaHome />
// // // // // // //                   <span>تصویری موجود نیست</span>
// // // // // // //                 </div>
// // // // // // //               </SwiperSlide>)
// // // // // // //             }
// // // // // // //           </Swiper>
// // // // // // //           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
// // // // // // //             {isFavorite ? <FaHeart /> : <FaRegHeart />}
// // // // // // //           </button>
// // // // // // //           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
// // // // // // //         </div>
        
// // // // // // //         <div className="detail-main">
// // // // // // //           <div className="detail-title-section">
// // // // // // //             <div className="title-row">
// // // // // // //               <div className="property-stats">
// // // // // // //                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
// // // // // // //                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
// // // // // // //                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
// // // // // // //               </div>
// // // // // // //             </div>
// // // // // // //           </div>
          
// // // // // // //           <div className="price-section">
// // // // // // //             {isForSale && (
// // // // // // //               <div className="price-card sale-price">
// // // // // // //                 <div className="price-card-icon"><FaTag /></div>
// // // // // // //                 <div className="price-card-content">
// // // // // // //                   <span className="price-label">قیمت فروش</span>
// // // // // // //                   <div className="price-value-wrapper">
// // // // // // //                     <span className="price-number">{property.price}</span>
// // // // // // //                     <span className="price-unit">تومان</span>
// // // // // // //                   </div>
// // // // // // //                   {formattedPricePerMeter && 
// // // // // // //                     <div className="price-meta">
// // // // // // //                       <FaRuler />
// // // // // // //                       <span>متری {formattedPricePerMeter}</span>
// // // // // // //                     </div>
// // // // // // //                   }
// // // // // // //                 </div>
// // // // // // //               </div>
// // // // // // //             )}
            
// // // // // // //             {isForRent && (
// // // // // // //               <div className="rent-price-group">
// // // // // // //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// // // // // // //                   <div className="price-card mortgage-price">
// // // // // // //                     <div className="price-card-icon"><FaBuilding /></div>
// // // // // // //                     <div className="price-card-content">
// // // // // // //                       <span className="price-label">مبلغ رهن</span>
// // // // // // //                       <div className="price-value-wrapper">
// // // // // // //                         <span className="price-number">{property.mortgagePrice}</span>
// // // // // // //                         <span className="price-unit">تومان</span>
// // // // // // //                       </div>
// // // // // // //                     </div>
// // // // // // //                   </div>
// // // // // // //                 )}
// // // // // // //                 {property.rentPrice && property.rentPrice !== "۰" && (
// // // // // // //                   <div className="price-card rent-price">
// // // // // // //                     <div className="price-card-icon"><FaHome /></div>
// // // // // // //                     <div className="price-card-content">
// // // // // // //                       <span className="price-label">اجاره ماهانه</span>
// // // // // // //                       <div className="price-value-wrapper">
// // // // // // //                         <span className="price-number">{property.rentPrice}</span>
// // // // // // //                         <span className="price-unit">تومان</span>
// // // // // // //                       </div>
// // // // // // //                     </div>
// // // // // // //                   </div>
// // // // // // //                 )}
// // // // // // //               </div>
// // // // // // //             )}
// // // // // // //           </div>
          
// // // // // // //           <div className="quick-specs">
// // // // // // //             <div className="spec-item">
// // // // // // //               <FaRulerCombined />
// // // // // // //               <span className="spec-label">متراژ</span>
// // // // // // //               <span className="spec-value">{property.area} متر²</span>
// // // // // // //             </div>
// // // // // // //             <div className="spec-item">
// // // // // // //               <FaBath />
// // // // // // //               <span className="spec-label">اتاق‌خواب</span>
// // // // // // //               <span className="spec-value">{property.rooms} خواب</span>
// // // // // // //             </div>
// // // // // // //             <div className="spec-item">
// // // // // // //               <FaLayerGroup />
// // // // // // //               <span className="spec-label">طبقه</span>
// // // // // // //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// // // // // // //             </div>
// // // // // // //             <div className="spec-item">
// // // // // // //               <FaCalendarAlt />
// // // // // // //               <span className="spec-label">سال ساخت</span>
// // // // // // //               <span className="spec-value">{property.year}</span>
// // // // // // //             </div>
// // // // // // //           </div>
          
// // // // // // //           <div className="info-chips">
// // // // // // //             <span className="info-chip">کد ملک: {property.id}</span>
// // // // // // //             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
// // // // // // //             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
// // // // // // //           </div>
          
// // // // // // //           <div className="detail-tabs">
// // // // // // //             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
// // // // // // //             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
// // // // // // //             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
// // // // // // //             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
// // // // // // //           </div>
          
// // // // // // //           <div className="tab-content">
// // // // // // //             {activeTab === 'details' && (
// // // // // // //               <div className="details-tab">
// // // // // // //                 <div className="address-card">
// // // // // // //                   <FaMapMarkerAlt />
// // // // // // //                   <div className="address-info">
// // // // // // //                     <h3>آدرس ملک</h3>
// // // // // // //                     <div>منطقه {property.regionName}</div>
// // // // // // //                     <p>{property.address}</p>
// // // // // // //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// // // // // // //                   </div>
// // // // // // //                 </div>
// // // // // // //                 <div className="description-card">
// // // // // // //                   <h3>توضیحات کامل {property.title}</h3>
// // // // // // //                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
// // // // // // //                 </div>
// // // // // // //                 <div className="map-card">
// // // // // // //                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
// // // // // // //                   <div className="map-location-badge">
// // // // // // //                     {property.showExactLocation ? 
// // // // // // //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
// // // // // // //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
// // // // // // //                     }
// // // // // // //                   </div>
// // // // // // //                   <div className="map-container">
// // // // // // //                     <NeshanMap 
// // // // // // //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
// // // // // // //                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
// // // // // // //                       zoom={property.showExactLocation ? 17 : 15.9} 
// // // // // // //                       defaultType="dreamy" 
// // // // // // //                       poi={true} 
// // // // // // //                       traffic={false} 
// // // // // // //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
// // // // // // //                     />
// // // // // // //                     <div className="map-marker-overlay">
// // // // // // //                       {property.showExactLocation ? 
// // // // // // //                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
// // // // // // //                         <div className="location-circles"><div className="circle-3"></div></div>
// // // // // // //                       }
// // // // // // //                     </div>
// // // // // // //                   </div>
// // // // // // //                   <div className="map-privacy-note">
// // // // // // //                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
// // // // // // //                   </div>
// // // // // // //                 </div>
// // // // // // //               </div>
// // // // // // //             )}
            
// // // // // // //             {activeTab === 'features' && (
// // // // // // //               <div className="features-tab">
// // // // // // //                 <h3>امکانات و ویژگی‌ها</h3>
// // // // // // //                 <div className="features-grid">
// // // // // // //                   {property.features.length > 0 ? 
// // // // // // //                     property.features.map((feature, idx) => {
// // // // // // //                       let Icon = FaCheckCircle;
// // // // // // //                       if (feature.includes('پارکینگ')) Icon = FaParking;
// // // // // // //                       else if (feature.includes('انباری')) Icon = FaWarehouse;
// // // // // // //                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
// // // // // // //                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
// // // // // // //                       return (
// // // // // // //                         <div key={idx} className="feature-card">
// // // // // // //                           <Icon />
// // // // // // //                           <span>{feature}</span>
// // // // // // //                         </div>
// // // // // // //                       );
// // // // // // //                     }) : 
// // // // // // //                     <p className="no-data">امکاناتی ثبت نشده است</p>
// // // // // // //                   }
// // // // // // //                 </div>
// // // // // // //               </div>
// // // // // // //             )}
            
// // // // // // //             {activeTab === 'warnings' && (
// // // // // // //               <div className="warnings-tab">
// // // // // // //                 <h3>⚠️ هشدارهای مهم</h3>
// // // // // // //                 <ul className="warnings-list">
// // // // // // //                   {property.warnings.map((w, idx) => (
// // // // // // //                     <li key={idx} className="warning-item">
// // // // // // //                       <span className="warning-bullet"></span>
// // // // // // //                       <span>{w}</span>
// // // // // // //                     </li>
// // // // // // //                   ))}
// // // // // // //                 </ul>
// // // // // // //                 <div className="warning-footer">
// // // // // // //                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
// // // // // // //                 </div>
// // // // // // //               </div>
// // // // // // //             )}
            
// // // // // // //             {activeTab === 'nearby' && (
// // // // // // //               <div className="nearby-tab">
// // // // // // //                 <h3>امکانات اطراف</h3>
// // // // // // //                 <div className="nearby-list">
// // // // // // //                   {property.nearby.map((item, idx) => (
// // // // // // //                     <div key={idx} className="nearby-item">
// // // // // // //                       <span className="nearby-name">{item.name}</span>
// // // // // // //                       <span className="nearby-distance">{item.distance}</span>
// // // // // // //                     </div>
// // // // // // //                   ))}
// // // // // // //                 </div>
// // // // // // //               </div>
// // // // // // //             )}
// // // // // // //           </div>
          
// // // // // // //           {/* ========== کارت مشاور با استوری ========== */}
// // // // // // //           <div className="agent-card">
// // // // // // //             <div className="agent-header">
// // // // // // //               <div className="agent-avatar-wrapper">
// // // // // // //                 <SafeImage 
// // // // // // //                   src={property.agent.image} 
// // // // // // //                   alt={property.agent.name} 
// // // // // // //                   className="agent-avatar" 
// // // // // // //                   fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
// // // // // // //                 />
// // // // // // //                 {/* ✅ ایندیکاتور استوری - رینگ قرمز دور آواتار */}
// // // // // // //                 {property.agent.hasStory && (
// // // // // // //                   <div className="story-ring-indicator" onClick={handleStoryClick}>
// // // // // // //                     <div className="story-ring-gradient"></div>
// // // // // // //                     <div className="story-play-icon">
// // // // // // //                       <FaPlay />
// // // // // // //                     </div>
// // // // // // //                   </div>
// // // // // // //                 )}
// // // // // // //               </div>
// // // // // // //               <div className="agent-info">
// // // // // // //                 <div className="agent-name-wrapper">
// // // // // // //                   <h3>{property.agent.name}</h3>
// // // // // // //                   {property.agent.hasStory && (
// // // // // // //                     <span className="story-label" onClick={handleStoryClick}>
// // // // // // //                       <span className="story-dot"></span>
// // // // // // //                       استوری
// // // // // // //                     </span>
// // // // // // //                   )}
// // // // // // //                 </div>
// // // // // // //                 <p>{property.agent.address}</p>
// // // // // // //                 <div className="agent-rating">
// // // // // // //                   <FaStar />
// // // // // // //                   <span>{property.agent.rating}</span>
// // // // // // //                   <span>({property.agent.deals} معامله)</span>
// // // // // // //                 </div>
// // // // // // //               </div>
// // // // // // //             </div>
// // // // // // //             <div className="agent-actions">
// // // // // // //               <button className="agent-action-btn phone" onClick={handleCopyPhone}>
// // // // // // //                 <FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}
// // // // // // //               </button>
// // // // // // //               <a 
// // // // // // //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// // // // // // //                 target="_blank" 
// // // // // // //                 rel="noopener noreferrer" 
// // // // // // //                 className="agent-action-btn whatsapp"
// // // // // // //               >
// // // // // // //                 <FaWhatsapp /> واتساپ
// // // // // // //               </a>
// // // // // // //             </div>
// // // // // // //           </div>
// // // // // // //         </div>
        
// // // // // // //         <DoubleSidebarBanners />
// // // // // // //         <RelatedPropertiesSlider 
// // // // // // //           currentPropertyId={property.id} 
// // // // // // //           regionName={property.regionName} 
// // // // // // //           propertyType={property.type} 
// // // // // // //         />
        
// // // // // // //         {copied && (
// // // // // // //           <div className="toast-notification">
// // // // // // //             <FaCheckCircle /> لینک کپی شد
// // // // // // //           </div>
// // // // // // //         )}
// // // // // // //       </div>
// // // // // // //     </> 
// // // // // // //   );
// // // // // // // });

// // // // // // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // // // // // // export default RealEstateDetailPageItem;


// // // // // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // // // // import CryptoJS from 'crypto-js';
// // // // // // import DOMPurify from 'dompurify';
// // // // // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // // // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // // // // import DoubleSidebarBanners  from './SidebarBanner';
// // // // // // import { 
// // // // // //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// // // // // //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// // // // // //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// // // // // //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaPlay, FaLink
// // // // // // } from 'react-icons/fa';
// // // // // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // // // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // // // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // // // // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // // // // // import 'swiper/css';
// // // // // // import 'swiper/css/navigation';
// // // // // // import 'swiper/css/pagination';
// // // // // // import './RealEstateDetailPageItem.css';

// // // // // // // ========== کامپوننت پاپ‌آپ استوری ==========
// // // // // // const StoryPopup = ({ agentName, agentImage, userId, onClose }) => {
// // // // // //   const [stories, setStories] = useState([]);
// // // // // //   const [loading, setLoading] = useState(true);
// // // // // //   const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
// // // // // //   const [progress, setProgress] = useState(0);
// // // // // //   const [isPaused, setIsPaused] = useState(false);
// // // // // //   const [error, setError] = useState(null);

// // // // // //   // دریافت استوری‌ها از API
// // // // // //   useEffect(() => {
// // // // // //     const fetchStories = async () => {
// // // // // //       if (!userId) {
// // // // // //         setError('شناسه کاربر یافت نشد');
// // // // // //         setLoading(false);
// // // // // //         return;
// // // // // //       }

// // // // // //       try {
// // // // // //         setLoading(true);

// // // // // //         const response = await fetch(`https://localhost:7178/api/Story/StoryForSiteForUser?userId=${userId}`);
        
// // // // // //         if (!response.ok) {
// // // // // //           throw new Error(`HTTP ${response.status}`);
// // // // // //         }
        
// // // // // //         const result = await response.json();
        
// // // // // //         if (result.status === 200 && result.data && result.data.length > 0) {
// // // // // //           // استوری‌های کاربر را استخراج می‌کنیم
// // // // // //           const userStories = result.data[0]?.storyUser || [];
// // // // // //           // آدرس کامل تصاویر را می‌سازیم
// // // // // //           const formattedStories = userStories.map(story => ({
// // // // // //             ...story,
// // // // // //             url: `https://localhost:7178${story.url}`
// // // // // //           }));
// // // // // //           setStories(formattedStories);
// // // // // //         } else {
// // // // // //           setStories([]);
// // // // // //         }
// // // // // //       } catch (error) {
// // // // // //         console.error('خطا در دریافت استوری:', error);
// // // // // //         setError('مشکل در دریافت استوری‌ها');
// // // // // //       } finally {
// // // // // //         setLoading(false);
// // // // // //       }
// // // // // //     };

// // // // // //     fetchStories();
// // // // // //   }, [userId]);

// // // // // //   // مدیریت پخش خودکار استوری‌ها
// // // // // //   useEffect(() => {
// // // // // //     if (isPaused || loading || stories.length === 0) return;

// // // // // //     const timer = setInterval(() => {
// // // // // //       setProgress(prev => {
// // // // // //         const newProgress = prev + 1;
// // // // // //         if (newProgress >= 100) {
// // // // // //           if (currentStoryIndex < stories.length - 1) {
// // // // // //             setCurrentStoryIndex(prev => prev + 1);
// // // // // //             return 0;
// // // // // //           } else {
// // // // // //             onClose(); // بستن پاپ‌آپ بعد از آخرین استوری
// // // // // //             return 0;
// // // // // //           }
// // // // // //         }
// // // // // //         return newProgress;
// // // // // //       });
// // // // // //     }, 50); // هر 50 میلی‌ثانیه 1% افزایش (5 ثانیه برای هر استوری)

// // // // // //     return () => clearInterval(timer);
// // // // // //   }, [currentStoryIndex, isPaused, loading, stories, onClose]);

// // // // // //   // هندلرهای ناوبری
// // // // // //   const handlePrevStory = useCallback((e) => {
// // // // // //     e.stopPropagation();
// // // // // //     if (currentStoryIndex > 0) {
// // // // // //       setCurrentStoryIndex(prev => prev - 1);
// // // // // //       setProgress(0);
// // // // // //     }
// // // // // //   }, [currentStoryIndex]);

// // // // // //   const handleNextStory = useCallback((e) => {
// // // // // //     e.stopPropagation();
// // // // // //     if (currentStoryIndex < stories.length - 1) {
// // // // // //       setCurrentStoryIndex(prev => prev + 1);
// // // // // //       setProgress(0);
// // // // // //     } else {
// // // // // //       onClose();
// // // // // //     }
// // // // // //   }, [currentStoryIndex, stories.length, onClose]);

// // // // // //   // کلیک روی لینک استوری
// // // // // //   const handleStoryLink = useCallback((link) => {
// // // // // //     if (link) {
// // // // // //       window.location.href = link;
// // // // // //     }
// // // // // //   }, []);

// // // // // //   if (loading) {
// // // // // //     return (
// // // // // //       <div className="story-popup-overlay" onClick={onClose}>
// // // // // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // // // //           <div style={{ 
// // // // // //             display: 'flex', 
// // // // // //             alignItems: 'center', 
// // // // // //             justifyContent: 'center', 
// // // // // //             height: '100%',
// // // // // //             color: 'white',
// // // // // //             fontSize: '18px'
// // // // // //           }}>
// // // // // //             در حال بارگذاری استوری‌ها...
// // // // // //           </div>
// // // // // //         </div>
// // // // // //       </div>
// // // // // //     );
// // // // // //   }

// // // // // //   if (error || stories.length === 0) {
// // // // // //     return (
// // // // // //       <div className="story-popup-overlay" onClick={onClose}>
// // // // // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // // // //           <div style={{ 
// // // // // //             display: 'flex', 
// // // // // //             flexDirection: 'column',
// // // // // //             alignItems: 'center', 
// // // // // //             justifyContent: 'center', 
// // // // // //             height: '100%',
// // // // // //             color: 'white',
// // // // // //             fontSize: '16px',
// // // // // //             padding: '20px',
// // // // // //             textAlign: 'center'
// // // // // //           }}>
// // // // // //             <p>{error || 'هیچ استوری برای این کاربر وجود ندارد'}</p>
// // // // // //             <button 
// // // // // //               onClick={onClose}
// // // // // //               style={{
// // // // // //                 marginTop: '20px',
// // // // // //                 padding: '10px 30px',
// // // // // //                 background: '#ff0000',
// // // // // //                 color: 'white',
// // // // // //                 border: 'none',
// // // // // //                 borderRadius: '8px',
// // // // // //                 cursor: 'pointer',
// // // // // //                 fontSize: '14px'
// // // // // //               }}
// // // // // //             >
// // // // // //               بستن
// // // // // //             </button>
// // // // // //           </div>
// // // // // //         </div>
// // // // // //       </div>
// // // // // //     );
// // // // // //   }

// // // // // //   const currentStory = stories[currentStoryIndex];

// // // // // //   return (
// // // // // //     <div 
// // // // // //       className="story-popup-overlay"
// // // // // //       onClick={onClose}
// // // // // //       onMouseEnter={() => setIsPaused(true)}
// // // // // //       onMouseLeave={() => setIsPaused(false)}
// // // // // //     >
// // // // // //       <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // // // //         {/* نوارهای پیشرفت */}
// // // // // //         <div className="story-progress-container">
// // // // // //           {stories.map((_, index) => (
// // // // // //             <div 
// // // // // //               key={index} 
// // // // // //               className="story-progress-bar"
// // // // // //             >
// // // // // //               <div 
// // // // // //                 className="story-progress-fill"
// // // // // //                 style={{
// // // // // //                   width: index < currentStoryIndex ? '100%' : 
// // // // // //                          index === currentStoryIndex ? `${progress}%` : '0%'
// // // // // //                 }}
// // // // // //               />
// // // // // //             </div>
// // // // // //           ))}
// // // // // //         </div>

// // // // // //         {/* هدر */}
// // // // // //         <div className="story-header">
// // // // // //           <div className="story-user-info">
// // // // // //             <img 
// // // // // //               src={agentImage} 
// // // // // //               alt={agentName} 
// // // // // //               className="story-user-avatar"
// // // // // //             />
// // // // // //             <span className="story-user-name">{agentName}</span>
// // // // // //             <span className="story-time">لحظاتی پیش</span>
// // // // // //           </div>
// // // // // //           <button className="story-close-btn" onClick={onClose}>✕</button>
// // // // // //         </div>

// // // // // //         {/* محتوای استوری */}
// // // // // //         <div className="story-content">
// // // // // //           <img 
// // // // // //             src={currentStory.url} 
// // // // // //             alt={currentStory.caption || 'استوری'} 
// // // // // //             className="story-image"
// // // // // //           />
          
// // // // // //           {/* کپشن */}
// // // // // //           {currentStory.caption && (
// // // // // //             <div className="story-caption">
// // // // // //               {currentStory.caption}
// // // // // //             </div>
// // // // // //           )}

// // // // // //           {/* لینک استوری */}
// // // // // //           {currentStory.link && (
// // // // // //             <div 
// // // // // //               className="story-link-button"
// // // // // //               onClick={() => handleStoryLink(currentStory.link)}
// // // // // //             >
// // // // // //               <FaLink />
// // // // // //               <span>{currentStory.linkText || 'مشاهده بیشتر'}</span>
// // // // // //             </div>
// // // // // //           )}
// // // // // //         </div>

// // // // // //         {/* دکمه‌های ناوبری */}
// // // // // //         <div 
// // // // // //           className="story-nav-left"
// // // // // //           onClick={handlePrevStory}
// // // // // //         />
// // // // // //         <div 
// // // // // //           className="story-nav-right"
// // // // // //           onClick={handleNextStory}
// // // // // //         />
// // // // // //       </div>
// // // // // //     </div>
// // // // // //   );
// // // // // // };

// // // // // // // ========== کامپوننت SafeImage ==========
// // // // // // const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
// // // // // //   const [error, setError] = useState(false);

// // // // // //   if (!src || error) {
// // // // // //     return (
// // // // // //       <img 
// // // // // //         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
// // // // // //         alt={alt || 'تصویر'} 
// // // // // //         className={className}
// // // // // //         {...props}
// // // // // //       />
// // // // // //     );
// // // // // //   }

// // // // // //   return (
// // // // // //     <img
// // // // // //       src={src}
// // // // // //       alt={alt}
// // // // // //       className={className}
// // // // // //       onError={() => {
// // // // // //         setError(true);
// // // // // //       }}
// // // // // //       {...props}
// // // // // //     />
// // // // // //   );
// // // // // // };

// // // // // // // ========== توابع کمکی ==========
// // // // // // const stripHtml = (html) => {
// // // // // //   if (!html) return '';
// // // // // //   const temp = document.createElement('div');
// // // // // //   temp.innerHTML = html;
// // // // // //   return temp.textContent || temp.innerText || '';
// // // // // // };

// // // // // // const truncateText = (text, maxLength) => {
// // // // // //   if (!text) return '';
// // // // // //   if (text.length <= maxLength) return text;
// // // // // //   return text.substring(0, maxLength - 2) + '…';
// // // // // // };

// // // // // // // ========== کامپوننت‌های متا ==========
// // // // // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // // // // //   useEffect(() => {
// // // // // //     if (!property) return;
// // // // // //     let title = property.title 
// // // // // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // // // // //       : `ملک ${property.area} متری ${property.regionName}`;
// // // // // //     title = truncateText(title, 65);
// // // // // //     document.title = title;
// // // // // //     const plainDescription = stripHtml(property.description || '');
// // // // // //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// // // // // //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// // // // // //     description = truncateText(description, 155);
// // // // // //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// // // // // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // // // // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // // // // //       let meta = document.querySelector(selector);
// // // // // //       if (!meta) {
// // // // // //         meta = document.createElement('meta');
// // // // // //         if (isProperty) meta.setAttribute('property', name);
// // // // // //         else meta.setAttribute('name', name);
// // // // // //         document.head.appendChild(meta);
// // // // // //       }
// // // // // //       meta.setAttribute('content', content);
// // // // // //     };
// // // // // //     updateOrCreateMeta('description', description);
// // // // // //     updateOrCreateMeta('keywords', keywords);
// // // // // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// // // // // //     let canonical = document.querySelector('link[rel="canonical"]');
// // // // // //     if (!canonical) {
// // // // // //       canonical = document.createElement('link');
// // // // // //       canonical.rel = 'canonical';
// // // // // //       document.head.appendChild(canonical);
// // // // // //     }
// // // // // //     canonical.href = window.location.href;
// // // // // //     updateOrCreateMeta('og:title', title, true);
// // // // // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // // // // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // // // // //     updateOrCreateMeta('og:url', window.location.href, true);
// // // // // //     updateOrCreateMeta('og:type', 'product', true);
// // // // // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // // // // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// // // // // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // // // // //     updateOrCreateMeta('twitter:title', title);
// // // // // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // // // // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// // // // // //     document.documentElement.lang = 'fa';
// // // // // //     document.documentElement.dir = 'rtl';
// // // // // //   }, [property, isForSale, isForRent]);
// // // // // //   return null;
// // // // // // };

// // // // // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // // // // //   useEffect(() => {
// // // // // //     if (!property) return;
// // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// // // // // //     removeOldScript();
// // // // // //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// // // // // //     const structuredData = {
// // // // // //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// // // // // //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// // // // // //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// // // // // //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// // // // // //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// // // // // //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// // // // // //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// // // // // //       "numberOfRooms": property.rooms || 0,
// // // // // //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// // // // // //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// // // // // //     };
// // // // // //     const script = document.createElement('script');
// // // // // //     script.id = 'json-ld-structured-data';
// // // // // //     script.type = 'application/ld+json';
// // // // // //     script.textContent = JSON.stringify(structuredData);
// // // // // //     document.head.appendChild(script);
// // // // // //     return () => removeOldScript();
// // // // // //   }, [property, isForSale, isForRent]);
// // // // // //   return null;
// // // // // // };

// // // // // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // // // // //   useEffect(() => {
// // // // // //     if (!property) return;
// // // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// // // // // //     removeOldScript();
// // // // // //     const baseUrl = window.location.origin;
// // // // // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// // // // // //     const breadcrumbData = {
// // // // // //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// // // // // //       "itemListElement": [
// // // // // //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// // // // // //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// // // // // //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// // // // // //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// // // // // //       ]
// // // // // //     };
// // // // // //     const script = document.createElement('script');
// // // // // //     script.id = 'json-ld-breadcrumb';
// // // // // //     script.type = 'application/ld+json';
// // // // // //     script.textContent = JSON.stringify(breadcrumbData);
// // // // // //     document.head.appendChild(script);
// // // // // //     return () => removeOldScript();
// // // // // //   }, [property, isForSale]);
// // // // // //   return null;
// // // // // // };

// // // // // // // ========== Skeleton ==========
// // // // // // const DetailSkeleton = () => (
// // // // // //   <div className="detail-skeleton">
// // // // // //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// // // // // //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// // // // // //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// // // // // //   </div>
// // // // // // );

// // // // // // // ========== کامپوننت اصلی ==========
// // // // // // const RealEstateDetailPageItem = memo(() => {
// // // // // //   const location = useLocation();
// // // // // //   const navigate = useNavigate();
// // // // // //   const { id: paramId } = useParams();
// // // // // //   const queryParams = new URLSearchParams(location.search);
// // // // // //   const id = paramId || queryParams.get('id');
// // // // // //   const [property, setProperty] = useState(null);
// // // // // //   const [loading, setLoading] = useState(true);
// // // // // //   const [error, setError] = useState(null);
// // // // // //   const [copied, setCopied] = useState(false);
// // // // // //   const [selectedImage, setSelectedImage] = useState(0);
// // // // // //   const [activeTab, setActiveTab] = useState('details');
// // // // // //   const [isFavorite, setIsFavorite] = useState(false);
// // // // // //   const [imagesLoaded, setImagesLoaded] = useState({});
// // // // // //   const [showStoryPopup, setShowStoryPopup] = useState(false);
// // // // // //   const [userId, setUserId] = useState(null);

// // // // // //   useEffect(() => {
// // // // // //     const fetchPropertyData = async () => {
// // // // // //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// // // // // //       setLoading(true); setError(null);
// // // // // //       try {
// // // // // //         const controller = new AbortController();
// // // // // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// // // // // //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// // // // // //         clearTimeout(timeoutId);
// // // // // //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// // // // // //         const result = await response.json();
// // // // // //         if (result.status === 200 && result.data) {
// // // // // //           const data = result.data;
          
// // // // // //           const agentImage = data.agents?.image 
// // // // // //             ? `https://localhost:7178/${data.agents.image}` 
// // // // // //             : "https://randomuser.me/api/portraits/men/32.jpg";
          
// // // // // //           // استخراج userId از agents
// // // // // //           const agentUserId = data.agents?.userId || null;
// // // // // //           setUserId(agentUserId);
          
// // // // // //           setProperty({
// // // // // //             id: data.id, 
// // // // // //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
// // // // // //             price: data.price?.toLocaleString("fa-IR") || "۰",
// // // // // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
// // // // // //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // // // // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
// // // // // //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // // // // //             type: data.categoryType, 
// // // // // //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
// // // // // //             rooms: data.rooms || 0,
// // // // // //             floor: data.floor || 1, 
// // // // // //             regionName: data.regionName || "منطقه نامشخص", 
// // // // // //             totalFloors: data.countFloor || 1,
// // // // // //             year: data.constructionYear || "نامشخص", 
// // // // // //             address: data.address || "آدرس درج نشده", 
// // // // // //             showExactLocation: data.showExactLocation,
// // // // // //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// // // // // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
// // // // // //             features: data.facilities || [],
// // // // // //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// // // // // //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// // // // // //             agent: { 
// // // // // //               name: data.agents?.name || "مشاور املاک", 
// // // // // //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
// // // // // //               whatsapp: data.agents?.connectSocialMedia || "", 
// // // // // //               address: data.agents?.address || "آدرس دفتر درج نشده", 
// // // // // //               rating: data.agents?.rating || 4.5, 
// // // // // //               deals: data.agents?.deals || 120, 
// // // // // //               image: agentImage,
// // // // // //               hasStory: data.agents?.hasStory || false,
// // // // // //               userId: data.agents?.userId || null // ✅ ذخیره userId
// // // // // //             },
// // // // // //             views: data.views || 0, 
// // // // // //             saved: data.saved || 0, 
// // // // // //             createdAt: data.createdAtPersianRelative || "امروز", 
// // // // // //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
// // // // // //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // // // // //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// // // // // //           });
// // // // // //         } else throw new Error(result.message || 'ملک یافت نشد');
// // // // // //       } catch (error) { 
// // // // // //         console.error('خطا:', error); 
// // // // // //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
// // // // // //       } finally { 
// // // // // //         setLoading(false); 
// // // // // //       }
// // // // // //     };
// // // // // //     fetchPropertyData();
// // // // // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // // // // //   }, [id]);

// // // // // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // // // // //   const isForRent = useMemo(() => property?.type === 2, [property]);
// // // // // //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// // // // // //   const shareUrl = useMemo(() => window.location.href, []);

// // // // // //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// // // // // //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// // // // // //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// // // // // //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// // // // // //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
// // // // // //   // ✅ هندلر باز کردن استوری با userId
// // // // // //   const handleStoryClick = useCallback(() => {
// // // // // //     const userId = property?.agent?.userId;
// // // // // //     if (property?.agent?.hasStory && userId) {
// // // // // //       setShowStoryPopup(true);
// // // // // //       document.body.style.overflow = 'hidden';
// // // // // //     } else {
// // // // // //       alert('هیچ استوری برای این کاربر وجود ندارد');
// // // // // //     }
// // // // // //   }, [property]);

// // // // // //   // ✅ هندلر بستن استوری
// // // // // //   const handleStoryClose = useCallback(() => {
// // // // // //     setShowStoryPopup(false);
// // // // // //     document.body.style.overflow = '';
// // // // // //   }, []);

// // // // // //   if (error) return ( 
// // // // // //     <> 
// // // // // //       <PageMetadata property={null} /> 
// // // // // //       <div className="detail-container">
// // // // // //         <div className="detail-header">
// // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // //           <h1 className="header-title">خطا</h1>
// // // // // //           <div className="header-btn"></div>
// // // // // //         </div>
// // // // // //         <div className="error-message">
// // // // // //           <h2>متاسفانه خطایی رخ داده است</h2>
// // // // // //           <p>{error}</p>
// // // // // //           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
// // // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // // //         </div>
// // // // // //       </div>
// // // // // //     </> 
// // // // // //   );
  
// // // // // //   if (loading) return <DetailSkeleton />;
  
// // // // // //   if (!property) return ( 
// // // // // //     <> 
// // // // // //       <PageMetadata property={null} /> 
// // // // // //       <div className="detail-container">
// // // // // //         <div className="detail-header">
// // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // //           <h1 className="header-title">ملک یافت نشد</h1>
// // // // // //           <div className="header-btn"></div>
// // // // // //         </div>
// // // // // //         <div className="error-message">
// // // // // //           <p>متاسفانه ملک مورد نظر یافت نشد</p>
// // // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // // //         </div>
// // // // // //       </div>
// // // // // //     </> 
// // // // // //   );

// // // // // //   return ( 
// // // // // //     <>
// // // // // //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // // //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
// // // // // //       {/* ✅ پاپ‌آپ استوری با userId */}
// // // // // //       {showStoryPopup && (
// // // // // //         <StoryPopup 
// // // // // //           agentName={property.agent.name}
// // // // // //           agentImage={property.agent.image}
// // // // // //           userId={property.agent.userId} // ✅ ارسال userId به پاپ‌آپ
// // // // // //           onClose={handleStoryClose}
// // // // // //         />
// // // // // //       )}
      
// // // // // //       <div className="detail-container">
// // // // // //         <nav className="breadcrumb-nav">
// // // // // //           <ol className="breadcrumb-list">
// // // // // //             <li className="breadcrumb-item"><a href="/">خانه</a></li>
// // // // // //             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
// // // // // //             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
// // // // // //             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
// // // // // //           </ol>
// // // // // //         </nav>
        
// // // // // //         <div className="detail-header">
// // // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // // //           <h1 className="header-title">{property.title}</h1>
// // // // // //           <button className="header-btn" onClick={handleShare}><FaShare /></button>
// // // // // //         </div>
        
// // // // // //         <div className="detail-gallery">
// // // // // //           <Swiper 
// // // // // //             modules={[Navigation, Pagination, Autoplay]} 
// // // // // //             navigation 
// // // // // //             pagination={{ clickable: true }} 
// // // // // //             autoplay={{ delay: 4000, disableOnInteraction: false }} 
// // // // // //             spaceBetween={0} 
// // // // // //             slidesPerView={1} 
// // // // // //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
// // // // // //             className="gallery-swiper"
// // // // // //           >
// // // // // //             {property.images.length > 0 ? 
// // // // // //               property.images.map((img, index) => (
// // // // // //                 <SwiperSlide key={index}>
// // // // // //                   <div className="gallery-slide">
// // // // // //                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
// // // // // //                     <img 
// // // // // //                       src={img} 
// // // // // //                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
// // // // // //                       loading={index === 0 ? 'eager' : 'lazy'} 
// // // // // //                       onLoad={() => handleImageLoad(index)} 
// // // // // //                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
// // // // // //                     />
// // // // // //                   </div>
// // // // // //                 </SwiperSlide>
// // // // // //               )) : 
// // // // // //               (<SwiperSlide>
// // // // // //                 <div className="gallery-slide no-image">
// // // // // //                   <FaHome />
// // // // // //                   <span>تصویری موجود نیست</span>
// // // // // //                 </div>
// // // // // //               </SwiperSlide>)
// // // // // //             }
// // // // // //           </Swiper>
// // // // // //           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
// // // // // //             {isFavorite ? <FaHeart /> : <FaRegHeart />}
// // // // // //           </button>
// // // // // //           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
// // // // // //         </div>
        
// // // // // //         <div className="detail-main">
// // // // // //           <div className="detail-title-section">
// // // // // //             <div className="title-row">
// // // // // //               <div className="property-stats">
// // // // // //                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
// // // // // //                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
// // // // // //                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
// // // // // //               </div>
// // // // // //             </div>
// // // // // //           </div>
          
// // // // // //           <div className="price-section">
// // // // // //             {isForSale && (
// // // // // //               <div className="price-card sale-price">
// // // // // //                 <div className="price-card-icon"><FaTag /></div>
// // // // // //                 <div className="price-card-content">
// // // // // //                   <span className="price-label">قیمت فروش</span>
// // // // // //                   <div className="price-value-wrapper">
// // // // // //                     <span className="price-number">{property.price}</span>
// // // // // //                     <span className="price-unit">تومان</span>
// // // // // //                   </div>
// // // // // //                   {formattedPricePerMeter && 
// // // // // //                     <div className="price-meta">
// // // // // //                       <FaRuler />
// // // // // //                       <span>متری {formattedPricePerMeter}</span>
// // // // // //                     </div>
// // // // // //                   }
// // // // // //                 </div>
// // // // // //               </div>
// // // // // //             )}
            
// // // // // //             {isForRent && (
// // // // // //               <div className="rent-price-group">
// // // // // //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// // // // // //                   <div className="price-card mortgage-price">
// // // // // //                     <div className="price-card-icon"><FaBuilding /></div>
// // // // // //                     <div className="price-card-content">
// // // // // //                       <span className="price-label">مبلغ رهن</span>
// // // // // //                       <div className="price-value-wrapper">
// // // // // //                         <span className="price-number">{property.mortgagePrice}</span>
// // // // // //                         <span className="price-unit">تومان</span>
// // // // // //                       </div>
// // // // // //                     </div>
// // // // // //                   </div>
// // // // // //                 )}
// // // // // //                 {property.rentPrice && property.rentPrice !== "۰" && (
// // // // // //                   <div className="price-card rent-price">
// // // // // //                     <div className="price-card-icon"><FaHome /></div>
// // // // // //                     <div className="price-card-content">
// // // // // //                       <span className="price-label">اجاره ماهانه</span>
// // // // // //                       <div className="price-value-wrapper">
// // // // // //                         <span className="price-number">{property.rentPrice}</span>
// // // // // //                         <span className="price-unit">تومان</span>
// // // // // //                       </div>
// // // // // //                     </div>
// // // // // //                   </div>
// // // // // //                 )}
// // // // // //               </div>
// // // // // //             )}
// // // // // //           </div>
          
// // // // // //           <div className="quick-specs">
// // // // // //             <div className="spec-item">
// // // // // //               <FaRulerCombined />
// // // // // //               <span className="spec-label">متراژ</span>
// // // // // //               <span className="spec-value">{property.area} متر²</span>
// // // // // //             </div>
// // // // // //             <div className="spec-item">
// // // // // //               <FaBath />
// // // // // //               <span className="spec-label">اتاق‌خواب</span>
// // // // // //               <span className="spec-value">{property.rooms} خواب</span>
// // // // // //             </div>
// // // // // //             <div className="spec-item">
// // // // // //               <FaLayerGroup />
// // // // // //               <span className="spec-label">طبقه</span>
// // // // // //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// // // // // //             </div>
// // // // // //             <div className="spec-item">
// // // // // //               <FaCalendarAlt />
// // // // // //               <span className="spec-label">سال ساخت</span>
// // // // // //               <span className="spec-value">{property.year}</span>
// // // // // //             </div>
// // // // // //           </div>
          
// // // // // //           <div className="info-chips">
// // // // // //             <span className="info-chip">کد ملک: {property.id}</span>
// // // // // //             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
// // // // // //             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
// // // // // //           </div>
          
// // // // // //           <div className="detail-tabs">
// // // // // //             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
// // // // // //             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
// // // // // //             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
// // // // // //             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
// // // // // //           </div>
          
// // // // // //           <div className="tab-content">
// // // // // //             {activeTab === 'details' && (
// // // // // //               <div className="details-tab">
// // // // // //                 <div className="address-card">
// // // // // //                   <FaMapMarkerAlt />
// // // // // //                   <div className="address-info">
// // // // // //                     <h3>آدرس ملک</h3>
// // // // // //                     <div>منطقه {property.regionName}</div>
// // // // // //                     <p>{property.address}</p>
// // // // // //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// // // // // //                   </div>
// // // // // //                 </div>
// // // // // //                 <div className="description-card">
// // // // // //                   <h3>توضیحات کامل {property.title}</h3>
// // // // // //                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
// // // // // //                 </div>
// // // // // //                 <div className="map-card">
// // // // // //                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
// // // // // //                   <div className="map-location-badge">
// // // // // //                     {property.showExactLocation ? 
// // // // // //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
// // // // // //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
// // // // // //                     }
// // // // // //                   </div>
// // // // // //                   <div className="map-container">
// // // // // //                     <NeshanMap 
// // // // // //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
// // // // // //                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
// // // // // //                       zoom={property.showExactLocation ? 17 : 15.9} 
// // // // // //                       defaultType="dreamy" 
// // // // // //                       poi={true} 
// // // // // //                       traffic={false} 
// // // // // //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
// // // // // //                     />
// // // // // //                     <div className="map-marker-overlay">
// // // // // //                       {property.showExactLocation ? 
// // // // // //                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
// // // // // //                         <div className="location-circles"><div className="circle-3"></div></div>
// // // // // //                       }
// // // // // //                     </div>
// // // // // //                   </div>
// // // // // //                   <div className="map-privacy-note">
// // // // // //                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
// // // // // //                   </div>
// // // // // //                 </div>
// // // // // //               </div>
// // // // // //             )}
            
// // // // // //             {activeTab === 'features' && (
// // // // // //               <div className="features-tab">
// // // // // //                 <h3>امکانات و ویژگی‌ها</h3>
// // // // // //                 <div className="features-grid">
// // // // // //                   {property.features.length > 0 ? 
// // // // // //                     property.features.map((feature, idx) => {
// // // // // //                       let Icon = FaCheckCircle;
// // // // // //                       if (feature.includes('پارکینگ')) Icon = FaParking;
// // // // // //                       else if (feature.includes('انباری')) Icon = FaWarehouse;
// // // // // //                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
// // // // // //                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
// // // // // //                       return (
// // // // // //                         <div key={idx} className="feature-card">
// // // // // //                           <Icon />
// // // // // //                           <span>{feature}</span>
// // // // // //                         </div>
// // // // // //                       );
// // // // // //                     }) : 
// // // // // //                     <p className="no-data">امکاناتی ثبت نشده است</p>
// // // // // //                   }
// // // // // //                 </div>
// // // // // //               </div>
// // // // // //             )}
            
// // // // // //             {activeTab === 'warnings' && (
// // // // // //               <div className="warnings-tab">
// // // // // //                 <h3>⚠️ هشدارهای مهم</h3>
// // // // // //                 <ul className="warnings-list">
// // // // // //                   {property.warnings.map((w, idx) => (
// // // // // //                     <li key={idx} className="warning-item">
// // // // // //                       <span className="warning-bullet"></span>
// // // // // //                       <span>{w}</span>
// // // // // //                     </li>
// // // // // //                   ))}
// // // // // //                 </ul>
// // // // // //                 <div className="warning-footer">
// // // // // //                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
// // // // // //                 </div>
// // // // // //               </div>
// // // // // //             )}
            
// // // // // //             {activeTab === 'nearby' && (
// // // // // //               <div className="nearby-tab">
// // // // // //                 <h3>امکانات اطراف</h3>
// // // // // //                 <div className="nearby-list">
// // // // // //                   {property.nearby.map((item, idx) => (
// // // // // //                     <div key={idx} className="nearby-item">
// // // // // //                       <span className="nearby-name">{item.name}</span>
// // // // // //                       <span className="nearby-distance">{item.distance}</span>
// // // // // //                     </div>
// // // // // //                   ))}
// // // // // //                 </div>
// // // // // //               </div>
// // // // // //             )}
// // // // // //           </div>
          
// // // // // //           {/* ========== کارت مشاور با استوری ========== */}
// // // // // //           <div className="agent-card">
// // // // // //             <div className="agent-header">
// // // // // //               <div className="agent-avatar-wrapper">
// // // // // //                 <SafeImage 
// // // // // //                   src={property.agent.image} 
// // // // // //                   alt={property.agent.name} 
// // // // // //                   className={`agent-avatar ${property.agent.hasStory ? 'has-story' : ''}`}
// // // // // //                   fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
// // // // // //                 />
// // // // // //                 {/* ✅ ایندیکاتور استوری - رینگ قرمز دور آواتار */}
// // // // // //                 {property.agent.hasStory && (
// // // // // //                   <div className="story-ring-indicator" onClick={handleStoryClick}>
// // // // // //                     <div className="story-ring-gradient"></div>
// // // // // //                     <div className="story-play-icon">
// // // // // //                       <FaPlay />
// // // // // //                     </div>
// // // // // //                   </div>
// // // // // //                 )}
// // // // // //               </div>
// // // // // //               <div className="agent-info">
// // // // // //                 <div className="agent-name-wrapper">
// // // // // //                   <h3>{property.agent.name}</h3>
// // // // // //                   {property.agent.hasStory && (
// // // // // //                     <span className="story-label" onClick={handleStoryClick}>
// // // // // //                       <span className="story-dot"></span>
// // // // // //                       استوری
// // // // // //                     </span>
// // // // // //                   )}
// // // // // //                 </div>
// // // // // //                 <p>{property.agent.address}</p>
// // // // // //                 <div className="agent-rating">
// // // // // //                   <FaStar />
// // // // // //                   <span>{property.agent.rating}</span>
// // // // // //                   <span>({property.agent.deals} معامله)</span>
// // // // // //                 </div>
// // // // // //               </div>
// // // // // //             </div>
// // // // // //             <div className="agent-actions">
// // // // // //               <button className="agent-action-btn phone" onClick={handleCopyPhone}>
// // // // // //                 <FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}
// // // // // //               </button>
// // // // // //               <a 
// // // // // //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// // // // // //                 target="_blank" 
// // // // // //                 rel="noopener noreferrer" 
// // // // // //                 className="agent-action-btn whatsapp"
// // // // // //               >
// // // // // //                 <FaWhatsapp /> واتساپ
// // // // // //               </a>
// // // // // //             </div>
// // // // // //           </div>
// // // // // //         </div>
        
// // // // // //         <DoubleSidebarBanners />
// // // // // //         <RelatedPropertiesSlider 
// // // // // //           currentPropertyId={property.id} 
// // // // // //           regionName={property.regionName} 
// // // // // //           propertyType={property.type} 
// // // // // //         />
        
// // // // // //         {copied && (
// // // // // //           <div className="toast-notification">
// // // // // //             <FaCheckCircle /> لینک کپی شد
// // // // // //           </div>
// // // // // //         )}
// // // // // //       </div>
// // // // // //     </> 
// // // // // //   );
// // // // // // });

// // // // // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // // // // // export default RealEstateDetailPageItem;

// // // // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // // // import CryptoJS from 'crypto-js';
// // // // // import DOMPurify from 'dompurify';
// // // // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // // // import DoubleSidebarBanners from './SidebarBanner';
// // // // // import { 
// // // // //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// // // // //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// // // // //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// // // // //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaPlay, FaLink
// // // // // } from 'react-icons/fa';
// // // // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // // // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // // // // import 'swiper/css';
// // // // // import 'swiper/css/navigation';
// // // // // import 'swiper/css/pagination';
// // // // // import './RealEstateDetailPageItem.css';

// // // // // // ========== کامپوننت پاپ‌آپ استوری ==========
// // // // // const StoryPopup = ({ agentName, agentImage, userId, onClose }) => {
// // // // //   const [stories, setStories] = useState([]);
// // // // //   const [loading, setLoading] = useState(true);
// // // // //   const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
// // // // //   const [progress, setProgress] = useState(0);
// // // // //   const [isPaused, setIsPaused] = useState(false);
// // // // //   const [error, setError] = useState(null);

// // // // //   // دریافت استوری‌ها از API
// // // // //   useEffect(() => {
// // // // //     const fetchStories = async () => {
// // // // //       if (!userId) {
// // // // //         setError('شناسه کاربر یافت نشد');
// // // // //         setLoading(false);
// // // // //         return;
// // // // //       }

// // // // //       try {
// // // // //         setLoading(true);
// // // // //         console.log('📡 در حال دریافت استوری برای userId:', userId);
        
// // // // //         const response = await fetch(`https://localhost:7178/api/Story/StoryForSiteForUser?userId=${userId}`);
        
// // // // //         console.log('📡 Response status:', response.status);
        
// // // // //         if (!response.ok) {
// // // // //           throw new Error(`HTTP ${response.status}`);
// // // // //         }
        
// // // // //         const result = await response.json();
// // // // //         console.log('📦 نتیجه استوری:', result);
        
// // // // //         if (result.status === 200 && result.data && result.data.length > 0) {
// // // // //           const userStories = result.data[0]?.storyUser || [];
// // // // //           console.log('📸 تعداد استوری‌ها:', userStories.length);
          
// // // // //           const formattedStories = userStories.map(story => ({
// // // // //             ...story,
// // // // //             url: `https://localhost:7178${story.url}`
// // // // //           }));
// // // // //           setStories(formattedStories);
// // // // //         } else {
// // // // //           console.log('⚠️ هیچ استوری پیدا نشد');
// // // // //           setStories([]);
// // // // //         }
// // // // //       } catch (error) {
// // // // //         console.error('❌ خطا در دریافت استوری:', error);
// // // // //         setError('مشکل در دریافت استوری‌ها');
// // // // //       } finally {
// // // // //         setLoading(false);
// // // // //       }
// // // // //     };

// // // // //     fetchStories();
// // // // //   }, [userId]);

// // // // //   // مدیریت پخش خودکار استوری‌ها
// // // // //   useEffect(() => {
// // // // //     if (isPaused || loading || stories.length === 0) return;

// // // // //     const timer = setInterval(() => {
// // // // //       setProgress(prev => {
// // // // //         const newProgress = prev + 1;
// // // // //         if (newProgress >= 100) {
// // // // //           if (currentStoryIndex < stories.length - 1) {
// // // // //             setCurrentStoryIndex(prev => prev + 1);
// // // // //             return 0;
// // // // //           } else {
// // // // //             onClose();
// // // // //             return 0;
// // // // //           }
// // // // //         }
// // // // //         return newProgress;
// // // // //       });
// // // // //     }, 50);

// // // // //     return () => clearInterval(timer);
// // // // //   }, [currentStoryIndex, isPaused, loading, stories, onClose]);

// // // // //   // هندلرهای ناوبری
// // // // //   const handlePrevStory = useCallback((e) => {
// // // // //     e.stopPropagation();
// // // // //     if (currentStoryIndex > 0) {
// // // // //       setCurrentStoryIndex(prev => prev - 1);
// // // // //       setProgress(0);
// // // // //     }
// // // // //   }, [currentStoryIndex]);

// // // // //   const handleNextStory = useCallback((e) => {
// // // // //     e.stopPropagation();
// // // // //     if (currentStoryIndex < stories.length - 1) {
// // // // //       setCurrentStoryIndex(prev => prev + 1);
// // // // //       setProgress(0);
// // // // //     } else {
// // // // //       onClose();
// // // // //     }
// // // // //   }, [currentStoryIndex, stories.length, onClose]);

// // // // //   // کلیک روی لینک استوری
// // // // //   const handleStoryLink = useCallback((link) => {
// // // // //     if (link) {
// // // // //       window.location.href = link;
// // // // //     }
// // // // //   }, []);

// // // // //   if (loading) {
// // // // //     return (
// // // // //       <div className="story-popup-overlay" onClick={onClose}>
// // // // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // // //           <div style={{ 
// // // // //             display: 'flex', 
// // // // //             alignItems: 'center', 
// // // // //             justifyContent: 'center', 
// // // // //             height: '100%',
// // // // //             color: 'white',
// // // // //             fontSize: '18px'
// // // // //           }}>
// // // // //             در حال بارگذاری استوری‌ها...
// // // // //           </div>
// // // // //         </div>
// // // // //       </div>
// // // // //     );
// // // // //   }

// // // // //   if (error || stories.length === 0) {
// // // // //     return (
// // // // //       <div className="story-popup-overlay" onClick={onClose}>
// // // // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // // //           <div style={{ 
// // // // //             display: 'flex', 
// // // // //             flexDirection: 'column',
// // // // //             alignItems: 'center', 
// // // // //             justifyContent: 'center', 
// // // // //             height: '100%',
// // // // //             color: 'white',
// // // // //             fontSize: '16px',
// // // // //             padding: '20px',
// // // // //             textAlign: 'center'
// // // // //           }}>
// // // // //             <p>{error || 'هیچ استوری برای این کاربر وجود ندارد'}</p>
// // // // //             <button 
// // // // //               onClick={onClose}
// // // // //               style={{
// // // // //                 marginTop: '20px',
// // // // //                 padding: '10px 30px',
// // // // //                 background: '#ff0000',
// // // // //                 color: 'white',
// // // // //                 border: 'none',
// // // // //                 borderRadius: '8px',
// // // // //                 cursor: 'pointer',
// // // // //                 fontSize: '14px'
// // // // //               }}
// // // // //             >
// // // // //               بستن
// // // // //             </button>
// // // // //           </div>
// // // // //         </div>
// // // // //       </div>
// // // // //     );
// // // // //   }

// // // // //   const currentStory = stories[currentStoryIndex];

// // // // //   return (
// // // // //     <div 
// // // // //       className="story-popup-overlay"
// // // // //       onClick={onClose}
// // // // //       onMouseEnter={() => setIsPaused(true)}
// // // // //       onMouseLeave={() => setIsPaused(false)}
// // // // //     >
// // // // //       <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // // //         {/* نوارهای پیشرفت */}
// // // // //         <div className="story-progress-container">
// // // // //           {stories.map((_, index) => (
// // // // //             <div 
// // // // //               key={index} 
// // // // //               className="story-progress-bar"
// // // // //             >
// // // // //               <div 
// // // // //                 className="story-progress-fill"
// // // // //                 style={{
// // // // //                   width: index < currentStoryIndex ? '100%' : 
// // // // //                          index === currentStoryIndex ? `${progress}%` : '0%'
// // // // //                 }}
// // // // //               />
// // // // //             </div>
// // // // //           ))}
// // // // //         </div>

// // // // //         {/* هدر */}
// // // // //         <div className="story-header">
// // // // //           <div className="story-user-info">
// // // // //             <img 
// // // // //               src={agentImage} 
// // // // //               alt={agentName} 
// // // // //               className="story-user-avatar"
// // // // //             />
// // // // //             <span className="story-user-name">{agentName}</span>
// // // // //             <span className="story-time">لحظاتی پیش</span>
// // // // //           </div>
// // // // //           <button className="story-close-btn" onClick={onClose}>✕</button>
// // // // //         </div>

// // // // //         {/* محتوای استوری */}
// // // // //         <div className="story-content">
// // // // //           <img 
// // // // //             src={currentStory.url} 
// // // // //             alt={currentStory.caption || 'استوری'} 
// // // // //             className="story-image"
// // // // //           />
          
// // // // //           {/* کپشن */}
// // // // //           {currentStory.caption && (
// // // // //             <div className="story-caption">
// // // // //               {currentStory.caption}
// // // // //             </div>
// // // // //           )}

// // // // //           {/* لینک استوری */}
// // // // //           {currentStory.link && (
// // // // //             <div 
// // // // //               className="story-link-button"
// // // // //               onClick={() => handleStoryLink(currentStory.link)}
// // // // //             >
// // // // //               <FaLink />
// // // // //               <span>{currentStory.linkText || 'مشاهده بیشتر'}</span>
// // // // //             </div>
// // // // //           )}
// // // // //         </div>

// // // // //         {/* دکمه‌های ناوبری */}
// // // // //         <div 
// // // // //           className="story-nav-left"
// // // // //           onClick={handlePrevStory}
// // // // //         />
// // // // //         <div 
// // // // //           className="story-nav-right"
// // // // //           onClick={handleNextStory}
// // // // //         />
// // // // //       </div>
// // // // //     </div>
// // // // //   );
// // // // // };

// // // // // // ========== کامپوننت SafeImage ==========
// // // // // const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
// // // // //   const [error, setError] = useState(false);

// // // // //   if (!src || error) {
// // // // //     return (
// // // // //       <img 
// // // // //         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
// // // // //         alt={alt || 'تصویر'} 
// // // // //         className={className}
// // // // //         {...props}
// // // // //       />
// // // // //     );
// // // // //   }

// // // // //   return (
// // // // //     <img
// // // // //       src={src}
// // // // //       alt={alt}
// // // // //       className={className}
// // // // //       onError={() => {
// // // // //         setError(true);
// // // // //       }}
// // // // //       {...props}
// // // // //     />
// // // // //   );
// // // // // };

// // // // // // ========== توابع کمکی ==========
// // // // // const stripHtml = (html) => {
// // // // //   if (!html) return '';
// // // // //   const temp = document.createElement('div');
// // // // //   temp.innerHTML = html;
// // // // //   return temp.textContent || temp.innerText || '';
// // // // // };

// // // // // const truncateText = (text, maxLength) => {
// // // // //   if (!text) return '';
// // // // //   if (text.length <= maxLength) return text;
// // // // //   return text.substring(0, maxLength - 2) + '…';
// // // // // };

// // // // // // ========== کامپوننت‌های متا ==========
// // // // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // // // //   useEffect(() => {
// // // // //     if (!property) return;
// // // // //     let title = property.title 
// // // // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // // // //       : `ملک ${property.area} متری ${property.regionName}`;
// // // // //     title = truncateText(title, 65);
// // // // //     document.title = title;
// // // // //     const plainDescription = stripHtml(property.description || '');
// // // // //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// // // // //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// // // // //     description = truncateText(description, 155);
// // // // //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// // // // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // // // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // // // //       let meta = document.querySelector(selector);
// // // // //       if (!meta) {
// // // // //         meta = document.createElement('meta');
// // // // //         if (isProperty) meta.setAttribute('property', name);
// // // // //         else meta.setAttribute('name', name);
// // // // //         document.head.appendChild(meta);
// // // // //       }
// // // // //       meta.setAttribute('content', content);
// // // // //     };
// // // // //     updateOrCreateMeta('description', description);
// // // // //     updateOrCreateMeta('keywords', keywords);
// // // // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// // // // //     let canonical = document.querySelector('link[rel="canonical"]');
// // // // //     if (!canonical) {
// // // // //       canonical = document.createElement('link');
// // // // //       canonical.rel = 'canonical';
// // // // //       document.head.appendChild(canonical);
// // // // //     }
// // // // //     canonical.href = window.location.href;
// // // // //     updateOrCreateMeta('og:title', title, true);
// // // // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // // // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // // // //     updateOrCreateMeta('og:url', window.location.href, true);
// // // // //     updateOrCreateMeta('og:type', 'product', true);
// // // // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // // // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// // // // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // // // //     updateOrCreateMeta('twitter:title', title);
// // // // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // // // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// // // // //     document.documentElement.lang = 'fa';
// // // // //     document.documentElement.dir = 'rtl';
// // // // //   }, [property, isForSale, isForRent]);
// // // // //   return null;
// // // // // };

// // // // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // // // //   useEffect(() => {
// // // // //     if (!property) return;
// // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// // // // //     removeOldScript();
// // // // //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// // // // //     const structuredData = {
// // // // //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// // // // //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// // // // //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// // // // //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// // // // //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// // // // //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// // // // //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// // // // //       "numberOfRooms": property.rooms || 0,
// // // // //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// // // // //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// // // // //     };
// // // // //     const script = document.createElement('script');
// // // // //     script.id = 'json-ld-structured-data';
// // // // //     script.type = 'application/ld+json';
// // // // //     script.textContent = JSON.stringify(structuredData);
// // // // //     document.head.appendChild(script);
// // // // //     return () => removeOldScript();
// // // // //   }, [property, isForSale, isForRent]);
// // // // //   return null;
// // // // // };

// // // // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // // // //   useEffect(() => {
// // // // //     if (!property) return;
// // // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// // // // //     removeOldScript();
// // // // //     const baseUrl = window.location.origin;
// // // // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// // // // //     const breadcrumbData = {
// // // // //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// // // // //       "itemListElement": [
// // // // //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// // // // //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// // // // //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// // // // //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// // // // //       ]
// // // // //     };
// // // // //     const script = document.createElement('script');
// // // // //     script.id = 'json-ld-breadcrumb';
// // // // //     script.type = 'application/ld+json';
// // // // //     script.textContent = JSON.stringify(breadcrumbData);
// // // // //     document.head.appendChild(script);
// // // // //     return () => removeOldScript();
// // // // //   }, [property, isForSale]);
// // // // //   return null;
// // // // // };

// // // // // // ========== Skeleton ==========
// // // // // const DetailSkeleton = () => (
// // // // //   <div className="detail-skeleton">
// // // // //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// // // // //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// // // // //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// // // // //   </div>
// // // // // );

// // // // // // ========== کامپوننت اصلی ==========
// // // // // const RealEstateDetailPageItem = memo(() => {
// // // // //   const location = useLocation();
// // // // //   const navigate = useNavigate();
// // // // //   const { id: paramId } = useParams();
// // // // //   const queryParams = new URLSearchParams(location.search);
// // // // //   const id = paramId || queryParams.get('id');
// // // // //   const [property, setProperty] = useState(null);
// // // // //   const [loading, setLoading] = useState(true);
// // // // //   const [error, setError] = useState(null);
// // // // //   const [copied, setCopied] = useState(false);
// // // // //   const [selectedImage, setSelectedImage] = useState(0);
// // // // //   const [activeTab, setActiveTab] = useState('details');
// // // // //   const [isFavorite, setIsFavorite] = useState(false);
// // // // //   const [imagesLoaded, setImagesLoaded] = useState({});
// // // // //   const [showStoryPopup, setShowStoryPopup] = useState(false);
// // // // //   const [storyUserId, setStoryUserId] = useState(null);

// // // // //   useEffect(() => {
// // // // //     const fetchPropertyData = async () => {
// // // // //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// // // // //       setLoading(true); setError(null);
// // // // //       try {
// // // // //         const controller = new AbortController();
// // // // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// // // // //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// // // // //         clearTimeout(timeoutId);
// // // // //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// // // // //         const result = await response.json();
        
// // // // //         console.log('📦 Full API response:', result);
        
// // // // //         if (result.status === 200 && result.data) {
// // // // //           const data = result.data;
          
// // // // //           const agentImage = data.agents?.image 
// // // // //             ? `https://localhost:7178/${data.agents.image}` 
// // // // //             : "https://randomuser.me/api/portraits/men/32.jpg";
          
// // // // //           const userId = data.agents?.userId || null;
// // // // //           const hasStory = data.agents?.hasStory || false;
          
// // // // //           console.log('👤 Agent UserId:', userId);
// // // // //           console.log('📱 HasStory:', hasStory);
          
// // // // //           setStoryUserId(userId);
          
// // // // //           setProperty({
// // // // //             id: data.id, 
// // // // //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
// // // // //             price: data.price?.toLocaleString("fa-IR") || "۰",
// // // // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
// // // // //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // // // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
// // // // //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // // // //             type: data.categoryType, 
// // // // //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
// // // // //             rooms: data.rooms || 0,
// // // // //             floor: data.floor || 1, 
// // // // //             regionName: data.regionName || "منطقه نامشخص", 
// // // // //             totalFloors: data.countFloor || 1,
// // // // //             year: data.constructionYear || "نامشخص", 
// // // // //             address: data.address || "آدرس درج نشده", 
// // // // //             showExactLocation: data.showExactLocation,
// // // // //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// // // // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
// // // // //             features: data.facilities || [],
// // // // //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// // // // //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// // // // //             agent: { 
// // // // //               name: data.agents?.name || "مشاور املاک", 
// // // // //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
// // // // //               whatsapp: data.agents?.connectSocialMedia || "", 
// // // // //               address: data.agents?.address || "آدرس دفتر درج نشده", 
// // // // //               rating: data.agents?.rating || 4.5, 
// // // // //               deals: data.agents?.deals || 120, 
// // // // //               image: agentImage,
// // // // //               hasStory: hasStory,
// // // // //               userId: userId
// // // // //             },
// // // // //             views: data.views || 0, 
// // // // //             saved: data.saved || 0, 
// // // // //             createdAt: data.createdAtPersianRelative || "امروز", 
// // // // //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
// // // // //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // // // //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// // // // //           });
// // // // //         } else throw new Error(result.message || 'ملک یافت نشد');
// // // // //       } catch (error) { 
// // // // //         console.error('خطا:', error); 
// // // // //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
// // // // //       } finally { 
// // // // //         setLoading(false); 
// // // // //       }
// // // // //     };
// // // // //     fetchPropertyData();
// // // // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // // // //   }, [id]);

// // // // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // // // //   const isForRent = useMemo(() => property?.type === 2, [property]);
// // // // //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// // // // //   const shareUrl = useMemo(() => window.location.href, []);

// // // // //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// // // // //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// // // // //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// // // // //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// // // // //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
// // // // //   // ✅ هندلر باز کردن استوری
// // // // //   const handleStoryClick = useCallback(() => {
// // // // //     console.log('🖱️ کلیک روی استوری');
// // // // //     console.log('🆔 storyUserId:', storyUserId);
    
// // // // //     if (storyUserId) {
// // // // //       console.log('✅ باز کردن استوری برای userId:', storyUserId);
// // // // //       setShowStoryPopup(true);
// // // // //       document.body.style.overflow = 'hidden';
// // // // //     } else {
// // // // //       console.log('❌ userId وجود ندارد');
// // // // //       alert('هیچ استوری برای این کاربر وجود ندارد');
// // // // //     }
// // // // //   }, [storyUserId]);

// // // // //   // ✅ هندلر بستن استوری
// // // // //   const handleStoryClose = useCallback(() => {
// // // // //     setShowStoryPopup(false);
// // // // //     document.body.style.overflow = '';
// // // // //   }, []);

// // // // //   if (error) return ( 
// // // // //     <> 
// // // // //       <PageMetadata property={null} /> 
// // // // //       <div className="detail-container">
// // // // //         <div className="detail-header">
// // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // //           <h1 className="header-title">خطا</h1>
// // // // //           <div className="header-btn"></div>
// // // // //         </div>
// // // // //         <div className="error-message">
// // // // //           <h2>متاسفانه خطایی رخ داده است</h2>
// // // // //           <p>{error}</p>
// // // // //           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
// // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // //         </div>
// // // // //       </div>
// // // // //     </> 
// // // // //   );
  
// // // // //   if (loading) return <DetailSkeleton />;
  
// // // // //   if (!property) return ( 
// // // // //     <> 
// // // // //       <PageMetadata property={null} /> 
// // // // //       <div className="detail-container">
// // // // //         <div className="detail-header">
// // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // //           <h1 className="header-title">ملک یافت نشد</h1>
// // // // //           <div className="header-btn"></div>
// // // // //         </div>
// // // // //         <div className="error-message">
// // // // //           <p>متاسفانه ملک مورد نظر یافت نشد</p>
// // // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // // //         </div>
// // // // //       </div>
// // // // //     </> 
// // // // //   );

// // // // //   return ( 
// // // // //     <>
// // // // //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // // // //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
// // // // //       {/* ✅ پاپ‌آپ استوری */}
// // // // //       {showStoryPopup && (
// // // // //         <StoryPopup 
// // // // //           agentName={property.agent.name}
// // // // //           agentImage={property.agent.image}
// // // // //           userId={storyUserId}
// // // // //           onClose={handleStoryClose}
// // // // //         />
// // // // //       )}
      
// // // // //       <div className="detail-container">
// // // // //         <nav className="breadcrumb-nav">
// // // // //           <ol className="breadcrumb-list">
// // // // //             <li className="breadcrumb-item"><a href="/">خانه</a></li>
// // // // //             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
// // // // //             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
// // // // //             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
// // // // //           </ol>
// // // // //         </nav>
        
// // // // //         <div className="detail-header">
// // // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // // //           <h1 className="header-title">{property.title}</h1>
// // // // //           <button className="header-btn" onClick={handleShare}><FaShare /></button>
// // // // //         </div>
        
// // // // //         <div className="detail-gallery">
// // // // //           <Swiper 
// // // // //             modules={[Navigation, Pagination, Autoplay]} 
// // // // //             navigation 
// // // // //             pagination={{ clickable: true }} 
// // // // //             autoplay={{ delay: 4000, disableOnInteraction: false }} 
// // // // //             spaceBetween={0} 
// // // // //             slidesPerView={1} 
// // // // //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
// // // // //             className="gallery-swiper"
// // // // //           >
// // // // //             {property.images.length > 0 ? 
// // // // //               property.images.map((img, index) => (
// // // // //                 <SwiperSlide key={index}>
// // // // //                   <div className="gallery-slide">
// // // // //                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
// // // // //                     <img 
// // // // //                       src={img} 
// // // // //                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
// // // // //                       loading={index === 0 ? 'eager' : 'lazy'} 
// // // // //                       onLoad={() => handleImageLoad(index)} 
// // // // //                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
// // // // //                     />
// // // // //                   </div>
// // // // //                 </SwiperSlide>
// // // // //               )) : 
// // // // //               (<SwiperSlide>
// // // // //                 <div className="gallery-slide no-image">
// // // // //                   <FaHome />
// // // // //                   <span>تصویری موجود نیست</span>
// // // // //                 </div>
// // // // //               </SwiperSlide>)
// // // // //             }
// // // // //           </Swiper>
// // // // //           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
// // // // //             {isFavorite ? <FaHeart /> : <FaRegHeart />}
// // // // //           </button>
// // // // //           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
// // // // //         </div>
        
// // // // //         <div className="detail-main">
// // // // //           <div className="detail-title-section">
// // // // //             <div className="title-row">
// // // // //               <div className="property-stats">
// // // // //                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
// // // // //                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
// // // // //                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
// // // // //               </div>
// // // // //             </div>
// // // // //           </div>
          
// // // // //           <div className="price-section">
// // // // //             {isForSale && (
// // // // //               <div className="price-card sale-price">
// // // // //                 <div className="price-card-icon"><FaTag /></div>
// // // // //                 <div className="price-card-content">
// // // // //                   <span className="price-label">قیمت فروش</span>
// // // // //                   <div className="price-value-wrapper">
// // // // //                     <span className="price-number">{property.price}</span>
// // // // //                     <span className="price-unit">تومان</span>
// // // // //                   </div>
// // // // //                   {formattedPricePerMeter && 
// // // // //                     <div className="price-meta">
// // // // //                       <FaRuler />
// // // // //                       <span>متری {formattedPricePerMeter}</span>
// // // // //                     </div>
// // // // //                   }
// // // // //                 </div>
// // // // //               </div>
// // // // //             )}
            
// // // // //             {isForRent && (
// // // // //               <div className="rent-price-group">
// // // // //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// // // // //                   <div className="price-card mortgage-price">
// // // // //                     <div className="price-card-icon"><FaBuilding /></div>
// // // // //                     <div className="price-card-content">
// // // // //                       <span className="price-label">مبلغ رهن</span>
// // // // //                       <div className="price-value-wrapper">
// // // // //                         <span className="price-number">{property.mortgagePrice}</span>
// // // // //                         <span className="price-unit">تومان</span>
// // // // //                       </div>
// // // // //                     </div>
// // // // //                   </div>
// // // // //                 )}
// // // // //                 {property.rentPrice && property.rentPrice !== "۰" && (
// // // // //                   <div className="price-card rent-price">
// // // // //                     <div className="price-card-icon"><FaHome /></div>
// // // // //                     <div className="price-card-content">
// // // // //                       <span className="price-label">اجاره ماهانه</span>
// // // // //                       <div className="price-value-wrapper">
// // // // //                         <span className="price-number">{property.rentPrice}</span>
// // // // //                         <span className="price-unit">تومان</span>
// // // // //                       </div>
// // // // //                     </div>
// // // // //                   </div>
// // // // //                 )}
// // // // //               </div>
// // // // //             )}
// // // // //           </div>
          
// // // // //           <div className="quick-specs">
// // // // //             <div className="spec-item">
// // // // //               <FaRulerCombined />
// // // // //               <span className="spec-label">متراژ</span>
// // // // //               <span className="spec-value">{property.area} متر²</span>
// // // // //             </div>
// // // // //             <div className="spec-item">
// // // // //               <FaBath />
// // // // //               <span className="spec-label">اتاق‌خواب</span>
// // // // //               <span className="spec-value">{property.rooms} خواب</span>
// // // // //             </div>
// // // // //             <div className="spec-item">
// // // // //               <FaLayerGroup />
// // // // //               <span className="spec-label">طبقه</span>
// // // // //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// // // // //             </div>
// // // // //             <div className="spec-item">
// // // // //               <FaCalendarAlt />
// // // // //               <span className="spec-label">سال ساخت</span>
// // // // //               <span className="spec-value">{property.year}</span>
// // // // //             </div>
// // // // //           </div>
          
// // // // //           <div className="info-chips">
// // // // //             <span className="info-chip">کد ملک: {property.id}</span>
// // // // //             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
// // // // //             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
// // // // //           </div>
          
// // // // //           <div className="detail-tabs">
// // // // //             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
// // // // //             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
// // // // //             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
// // // // //             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
// // // // //           </div>
          
// // // // //           <div className="tab-content">
// // // // //             {activeTab === 'details' && (
// // // // //               <div className="details-tab">
// // // // //                 <div className="address-card">
// // // // //                   <FaMapMarkerAlt />
// // // // //                   <div className="address-info">
// // // // //                     <h3>آدرس ملک</h3>
// // // // //                     <div>منطقه {property.regionName}</div>
// // // // //                     <p>{property.address}</p>
// // // // //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// // // // //                   </div>
// // // // //                 </div>
// // // // //                 <div className="description-card">
// // // // //                   <h3>توضیحات کامل {property.title}</h3>
// // // // //                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
// // // // //                 </div>
// // // // //                 <div className="map-card">
// // // // //                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
// // // // //                   <div className="map-location-badge">
// // // // //                     {property.showExactLocation ? 
// // // // //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
// // // // //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
// // // // //                     }
// // // // //                   </div>
// // // // //                   <div className="map-container">
// // // // //                     <NeshanMap 
// // // // //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
// // // // //                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
// // // // //                       zoom={property.showExactLocation ? 17 : 15.9} 
// // // // //                       defaultType="dreamy" 
// // // // //                       poi={true} 
// // // // //                       traffic={false} 
// // // // //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
// // // // //                     />
// // // // //                     <div className="map-marker-overlay">
// // // // //                       {property.showExactLocation ? 
// // // // //                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
// // // // //                         <div className="location-circles"><div className="circle-3"></div></div>
// // // // //                       }
// // // // //                     </div>
// // // // //                   </div>
// // // // //                   <div className="map-privacy-note">
// // // // //                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
// // // // //                   </div>
// // // // //                 </div>
// // // // //               </div>
// // // // //             )}
            
// // // // //             {activeTab === 'features' && (
// // // // //               <div className="features-tab">
// // // // //                 <h3>امکانات و ویژگی‌ها</h3>
// // // // //                 <div className="features-grid">
// // // // //                   {property.features.length > 0 ? 
// // // // //                     property.features.map((feature, idx) => {
// // // // //                       let Icon = FaCheckCircle;
// // // // //                       if (feature.includes('پارکینگ')) Icon = FaParking;
// // // // //                       else if (feature.includes('انباری')) Icon = FaWarehouse;
// // // // //                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
// // // // //                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
// // // // //                       return (
// // // // //                         <div key={idx} className="feature-card">
// // // // //                           <Icon />
// // // // //                           <span>{feature}</span>
// // // // //                         </div>
// // // // //                       );
// // // // //                     }) : 
// // // // //                     <p className="no-data">امکاناتی ثبت نشده است</p>
// // // // //                   }
// // // // //                 </div>
// // // // //               </div>
// // // // //             )}
            
// // // // //             {activeTab === 'warnings' && (
// // // // //               <div className="warnings-tab">
// // // // //                 <h3>⚠️ هشدارهای مهم</h3>
// // // // //                 <ul className="warnings-list">
// // // // //                   {property.warnings.map((w, idx) => (
// // // // //                     <li key={idx} className="warning-item">
// // // // //                       <span className="warning-bullet"></span>
// // // // //                       <span>{w}</span>
// // // // //                     </li>
// // // // //                   ))}
// // // // //                 </ul>
// // // // //                 <div className="warning-footer">
// // // // //                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
// // // // //                 </div>
// // // // //               </div>
// // // // //             )}
            
// // // // //             {activeTab === 'nearby' && (
// // // // //               <div className="nearby-tab">
// // // // //                 <h3>امکانات اطراف</h3>
// // // // //                 <div className="nearby-list">
// // // // //                   {property.nearby.map((item, idx) => (
// // // // //                     <div key={idx} className="nearby-item">
// // // // //                       <span className="nearby-name">{item.name}</span>
// // // // //                       <span className="nearby-distance">{item.distance}</span>
// // // // //                     </div>
// // // // //                   ))}
// // // // //                 </div>
// // // // //               </div>
// // // // //             )}
// // // // //           </div>
          
// // // // //           {/* ========== کارت مشاور با استوری ========== */}
// // // // //           <div className="agent-card">
// // // // //             <div className="agent-header">
// // // // //               <div 
// // // // //                 className="agent-avatar-wrapper"
// // // // //                 onClick={handleStoryClick}
// // // // //                 style={{ cursor: storyUserId ? 'pointer' : 'default' }}
// // // // //               >
// // // // //                 <SafeImage 
// // // // //                   src={property.agent.image} 
// // // // //                   alt={property.agent.name} 
// // // // //                   className={`agent-avatar ${storyUserId ? 'has-story' : ''}`}
// // // // //                   fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
// // // // //                 />
                
// // // // //                 {/* ✅ رینگ قرمز دور آواتار */}
// // // // //                 {storyUserId && (
// // // // //                   <div className="story-ring-indicator">
// // // // //                     <div className="story-ring-gradient"></div>
// // // // //                     <div className="story-play-icon">
// // // // //                       <FaPlay />
// // // // //                     </div>
// // // // //                   </div>
// // // // //                 )}
// // // // //               </div>
              
// // // // //               <div className="agent-info">
// // // // //                 <div className="agent-name-wrapper">
// // // // //                   <h3>{property.agent.name}</h3>
// // // // //                   {/* ✅ برچسب استوری */}
// // // // //                   {storyUserId && (
// // // // //                     <span className="story-label" onClick={handleStoryClick}>
// // // // //                       <span className="story-dot"></span>
// // // // //                       استوری
// // // // //                     </span>
// // // // //                   )}
// // // // //                 </div>
// // // // //                 <p>{property.agent.address}</p>
// // // // //                 <div className="agent-rating">
// // // // //                   <FaStar />
// // // // //                   <span>{property.agent.rating}</span>
// // // // //                   <span>({property.agent.deals} معامله)</span>
// // // // //                 </div>
// // // // //               </div>
// // // // //             </div>
            
// // // // //             {/* ✅ دکمه دیباگ */}
// // // // //             <button
// // // // //               onClick={() => {
// // // // //                 console.log('🔍 Debug Info:');
// // // // //                 console.log('storyUserId:', storyUserId);
// // // // //                 console.log('agent.userId:', property?.agent?.userId);
// // // // //                 console.log('hasStory:', property?.agent?.hasStory);
// // // // //                 alert(`UserId: ${storyUserId || 'ندارد'}`);
// // // // //               }}
// // // // //               style={{
// // // // //                 marginBottom: '10px',
// // // // //                 padding: '5px 10px',
// // // // //                 background: '#666',
// // // // //                 color: 'white',
// // // // //                 border: 'none',
// // // // //                 borderRadius: '4px',
// // // // //                 cursor: 'pointer',
// // // // //                 fontSize: '12px',
// // // // //                 width: '100%'
// // // // //               }}
// // // // //             >
// // // // //               🔍 دیباگ استوری
// // // // //             </button>
            
// // // // //             <div className="agent-actions">
// // // // //               <button className="agent-action-btn phone" onClick={handleCopyPhone}>
// // // // //                 <FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}
// // // // //               </button>
// // // // //               <a 
// // // // //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// // // // //                 target="_blank" 
// // // // //                 rel="noopener noreferrer" 
// // // // //                 className="agent-action-btn whatsapp"
// // // // //               >
// // // // //                 <FaWhatsapp /> واتساپ
// // // // //               </a>
// // // // //             </div>
// // // // //           </div>
// // // // //         </div>
        
// // // // //         <DoubleSidebarBanners />
// // // // //         <RelatedPropertiesSlider 
// // // // //           currentPropertyId={property.id} 
// // // // //           regionName={property.regionName} 
// // // // //           propertyType={property.type} 
// // // // //         />
        
// // // // //         {copied && (
// // // // //           <div className="toast-notification">
// // // // //             <FaCheckCircle /> لینک کپی شد
// // // // //           </div>
// // // // //         )}
// // // // //       </div>
// // // // //     </> 
// // // // //   );
// // // // // });

// // // // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // // // // export default RealEstateDetailPageItem;




// // // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // // import CryptoJS from 'crypto-js';
// // // // import DOMPurify from 'dompurify';
// // // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // // import DoubleSidebarBanners from './SidebarBanner';
// // // // import { 
// // // //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// // // //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// // // //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// // // //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaLink
// // // // } from 'react-icons/fa';
// // // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // // // import 'swiper/css';
// // // // import 'swiper/css/navigation';
// // // // import 'swiper/css/pagination';
// // // // import './RealEstateDetailPageItem.css';

// // // // // ========== کامپوننت پاپ‌آپ استوری ==========
// // // // const StoryPopup = ({ agentName, agentImage, userId, onClose }) => {
// // // //   const [stories, setStories] = useState([]);
// // // //   const [loading, setLoading] = useState(true);
// // // //   const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
// // // //   const [progress, setProgress] = useState(0);
// // // //   const [isPaused, setIsPaused] = useState(false);
// // // //   const [error, setError] = useState(null);

// // // //   // دریافت استوری‌ها از API
// // // //   useEffect(() => {
// // // //     const fetchStories = async () => {
// // // //       if (!userId) {
// // // //         setError('شناسه کاربر یافت نشد');
// // // //         setLoading(false);
// // // //         return;
// // // //       }

// // // //       try {
// // // //         setLoading(true);
// // // //         console.log('📡 در حال دریافت استوری برای userId:', userId);
        
// // // //         const response = await fetch(`https://localhost:7178/api/Story/StoryForSiteForUser?userId=${userId}`);
        
// // // //         console.log('📡 Response status:', response.status);
        
// // // //         if (!response.ok) {
// // // //           throw new Error(`HTTP ${response.status}`);
// // // //         }
        
// // // //         const result = await response.json();
// // // //         console.log('📦 نتیجه استوری:', result);
        
// // // //         if (result.status === 200 && result.data && result.data.length > 0) {
// // // //           const userStories = result.data[0]?.storyUser || [];
// // // //           console.log('📸 تعداد استوری‌ها:', userStories.length);
          
// // // //           const formattedStories = userStories.map(story => ({
// // // //             ...story,
// // // //             url: `https://localhost:7178${story.url}`
// // // //           }));
// // // //           setStories(formattedStories);
// // // //         } else {
// // // //           console.log('⚠️ هیچ استوری پیدا نشد');
// // // //           setStories([]);
// // // //         }
// // // //       } catch (error) {
// // // //         console.error('❌ خطا در دریافت استوری:', error);
// // // //         setError('مشکل در دریافت استوری‌ها');
// // // //       } finally {
// // // //         setLoading(false);
// // // //       }
// // // //     };

// // // //     fetchStories();
// // // //   }, [userId]);

// // // //   // مدیریت پخش خودکار استوری‌ها
// // // //   useEffect(() => {
// // // //     if (isPaused || loading || stories.length === 0) return;

// // // //     const timer = setInterval(() => {
// // // //       setProgress(prev => {
// // // //         const newProgress = prev + 1;
// // // //         if (newProgress >= 100) {
// // // //           if (currentStoryIndex < stories.length - 1) {
// // // //             setCurrentStoryIndex(prev => prev + 1);
// // // //             return 0;
// // // //           } else {
// // // //             onClose();
// // // //             return 0;
// // // //           }
// // // //         }
// // // //         return newProgress;
// // // //       });
// // // //     }, 50);

// // // //     return () => clearInterval(timer);
// // // //   }, [currentStoryIndex, isPaused, loading, stories, onClose]);

// // // //   // هندلرهای ناوبری
// // // //   const handlePrevStory = useCallback((e) => {
// // // //     e.stopPropagation();
// // // //     if (currentStoryIndex > 0) {
// // // //       setCurrentStoryIndex(prev => prev - 1);
// // // //       setProgress(0);
// // // //     }
// // // //   }, [currentStoryIndex]);

// // // //   const handleNextStory = useCallback((e) => {
// // // //     e.stopPropagation();
// // // //     if (currentStoryIndex < stories.length - 1) {
// // // //       setCurrentStoryIndex(prev => prev + 1);
// // // //       setProgress(0);
// // // //     } else {
// // // //       onClose();
// // // //     }
// // // //   }, [currentStoryIndex, stories.length, onClose]);

// // // //   // کلیک روی لینک استوری
// // // //   const handleStoryLink = useCallback((link) => {
// // // //     if (link) {
// // // //       window.location.href = link;
// // // //     }
// // // //   }, []);

// // // //   if (loading) {
// // // //     return (
// // // //       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
// // // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // //           <div style={{ 
// // // //             display: 'flex', 
// // // //             alignItems: 'center', 
// // // //             justifyContent: 'center', 
// // // //             height: '100%',
// // // //             color: 'white',
// // // //             fontSize: '18px',
// // // //             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// // // //           }}>
// // // //             در حال بارگذاری استوری‌ها...
// // // //           </div>
// // // //         </div>
// // // //       </div>
// // // //     );
// // // //   }

// // // //   if (error || stories.length === 0) {
// // // //     return (
// // // //       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
// // // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // //           <div style={{ 
// // // //             display: 'flex', 
// // // //             flexDirection: 'column',
// // // //             alignItems: 'center', 
// // // //             justifyContent: 'center', 
// // // //             height: '100%',
// // // //             color: 'white',
// // // //             fontSize: '16px',
// // // //             padding: '20px',
// // // //             textAlign: 'center',
// // // //             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// // // //           }}>
// // // //             <p>{error || 'هیچ استوری برای این کاربر وجود ندارد'}</p>
// // // //             <button 
// // // //               onClick={onClose}
// // // //               style={{
// // // //                 marginTop: '20px',
// // // //                 padding: '10px 30px',
// // // //                 background: '#ff0000',
// // // //                 color: 'white',
// // // //                 border: 'none',
// // // //                 borderRadius: '8px',
// // // //                 cursor: 'pointer',
// // // //                 fontSize: '14px',
// // // //                 fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// // // //               }}
// // // //             >
// // // //               بستن
// // // //             </button>
// // // //           </div>
// // // //         </div>
// // // //       </div>
// // // //     );
// // // //   }

// // // //   const currentStory = stories[currentStoryIndex];

// // // //   return (
// // // //     <div 
// // // //       className="realestate-detail story-popup-overlay"
// // // //       onClick={onClose}
// // // //       onMouseEnter={() => setIsPaused(true)}
// // // //       onMouseLeave={() => setIsPaused(false)}
// // // //     >
// // // //       <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // // //         {/* نوارهای پیشرفت */}
// // // //         <div className="story-progress-container">
// // // //           {stories.map((_, index) => (
// // // //             <div 
// // // //               key={index} 
// // // //               className="story-progress-bar"
// // // //             >
// // // //               <div 
// // // //                 className="story-progress-fill"
// // // //                 style={{
// // // //                   width: index < currentStoryIndex ? '100%' : 
// // // //                          index === currentStoryIndex ? `${progress}%` : '0%'
// // // //                 }}
// // // //               />
// // // //             </div>
// // // //           ))}
// // // //         </div>

// // // //         {/* هدر */}
// // // //         <div className="story-header">
// // // //           <div className="story-user-info">
// // // //             <img 
// // // //               src={agentImage} 
// // // //               alt={agentName} 
// // // //               className="story-user-avatar"
// // // //             />
// // // //             <span className="story-user-name">{agentName}</span>
// // // //             <span className="story-time">لحظاتی پیش</span>
// // // //           </div>
// // // //           <button className="story-close-btn" onClick={onClose}>✕</button>
// // // //         </div>

// // // //         {/* محتوای استوری */}
// // // //         <div className="story-content">
// // // //           <img 
// // // //             src={currentStory.url} 
// // // //             alt={currentStory.caption || 'استوری'} 
// // // //             className="story-image"
// // // //           />
          
// // // //           {/* کپشن */}
// // // //           {currentStory.caption && (
// // // //             <div className="story-caption">
// // // //               {currentStory.caption}
// // // //             </div>
// // // //           )}

// // // //           {/* لینک استوری */}
// // // //           {currentStory.link && (
// // // //             <div 
// // // //               className="story-link-button"
// // // //               onClick={() => handleStoryLink(currentStory.link)}
// // // //             >
// // // //               <FaLink />
// // // //               <span>{currentStory.linkText || 'مشاهده بیشتر'}</span>
// // // //             </div>
// // // //           )}
// // // //         </div>

// // // //         {/* دکمه‌های ناوبری */}
// // // //         <div 
// // // //           className="story-nav-left"
// // // //           onClick={handlePrevStory}
// // // //         />
// // // //         <div 
// // // //           className="story-nav-right"
// // // //           onClick={handleNextStory}
// // // //         />
// // // //       </div>
// // // //     </div>
// // // //   );
// // // // };

// // // // // ========== کامپوننت SafeImage ==========
// // // // const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
// // // //   const [error, setError] = useState(false);

// // // //   if (!src || error) {
// // // //     return (
// // // //       <img 
// // // //         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
// // // //         alt={alt || 'تصویر'} 
// // // //         className={className}
// // // //         {...props}
// // // //       />
// // // //     );
// // // //   }

// // // //   return (
// // // //     <img
// // // //       src={src}
// // // //       alt={alt}
// // // //       className={className}
// // // //       onError={() => {
// // // //         setError(true);
// // // //       }}
// // // //       {...props}
// // // //     />
// // // //   );
// // // // };

// // // // // ========== توابع کمکی ==========
// // // // const stripHtml = (html) => {
// // // //   if (!html) return '';
// // // //   const temp = document.createElement('div');
// // // //   temp.innerHTML = html;
// // // //   return temp.textContent || temp.innerText || '';
// // // // };

// // // // const truncateText = (text, maxLength) => {
// // // //   if (!text) return '';
// // // //   if (text.length <= maxLength) return text;
// // // //   return text.substring(0, maxLength - 2) + '…';
// // // // };

// // // // // ========== کامپوننت‌های متا ==========
// // // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // // //   useEffect(() => {
// // // //     if (!property) return;
// // // //     let title = property.title 
// // // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // // //       : `ملک ${property.area} متری ${property.regionName}`;
// // // //     title = truncateText(title, 65);
// // // //     document.title = title;
// // // //     const plainDescription = stripHtml(property.description || '');
// // // //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// // // //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// // // //     description = truncateText(description, 155);
// // // //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// // // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // // //       let meta = document.querySelector(selector);
// // // //       if (!meta) {
// // // //         meta = document.createElement('meta');
// // // //         if (isProperty) meta.setAttribute('property', name);
// // // //         else meta.setAttribute('name', name);
// // // //         document.head.appendChild(meta);
// // // //       }
// // // //       meta.setAttribute('content', content);
// // // //     };
// // // //     updateOrCreateMeta('description', description);
// // // //     updateOrCreateMeta('keywords', keywords);
// // // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// // // //     let canonical = document.querySelector('link[rel="canonical"]');
// // // //     if (!canonical) {
// // // //       canonical = document.createElement('link');
// // // //       canonical.rel = 'canonical';
// // // //       document.head.appendChild(canonical);
// // // //     }
// // // //     canonical.href = window.location.href;
// // // //     updateOrCreateMeta('og:title', title, true);
// // // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // // //     updateOrCreateMeta('og:url', window.location.href, true);
// // // //     updateOrCreateMeta('og:type', 'product', true);
// // // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// // // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // // //     updateOrCreateMeta('twitter:title', title);
// // // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// // // //     document.documentElement.lang = 'fa';
// // // //     document.documentElement.dir = 'rtl';
// // // //   }, [property, isForSale, isForRent]);
// // // //   return null;
// // // // };

// // // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // // //   useEffect(() => {
// // // //     if (!property) return;
// // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// // // //     removeOldScript();
// // // //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// // // //     const structuredData = {
// // // //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// // // //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// // // //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// // // //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// // // //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// // // //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// // // //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// // // //       "numberOfRooms": property.rooms || 0,
// // // //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// // // //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// // // //     };
// // // //     const script = document.createElement('script');
// // // //     script.id = 'json-ld-structured-data';
// // // //     script.type = 'application/ld+json';
// // // //     script.textContent = JSON.stringify(structuredData);
// // // //     document.head.appendChild(script);
// // // //     return () => removeOldScript();
// // // //   }, [property, isForSale, isForRent]);
// // // //   return null;
// // // // };

// // // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // // //   useEffect(() => {
// // // //     if (!property) return;
// // // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// // // //     removeOldScript();
// // // //     const baseUrl = window.location.origin;
// // // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// // // //     const breadcrumbData = {
// // // //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// // // //       "itemListElement": [
// // // //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// // // //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// // // //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// // // //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// // // //       ]
// // // //     };
// // // //     const script = document.createElement('script');
// // // //     script.id = 'json-ld-breadcrumb';
// // // //     script.type = 'application/ld+json';
// // // //     script.textContent = JSON.stringify(breadcrumbData);
// // // //     document.head.appendChild(script);
// // // //     return () => removeOldScript();
// // // //   }, [property, isForSale]);
// // // //   return null;
// // // // };

// // // // // ========== Skeleton ==========
// // // // const DetailSkeleton = () => (
// // // //   <div className="detail-skeleton">
// // // //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// // // //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// // // //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// // // //   </div>
// // // // );

// // // // // ========== کامپوننت اصلی ==========
// // // // const RealEstateDetailPageItem = memo(() => {
// // // //   const location = useLocation();
// // // //   const navigate = useNavigate();
// // // //   const { id: paramId } = useParams();
// // // //   const queryParams = new URLSearchParams(location.search);
// // // //   const id = paramId || queryParams.get('id');
// // // //   const [property, setProperty] = useState(null);
// // // //   const [loading, setLoading] = useState(true);
// // // //   const [error, setError] = useState(null);
// // // //   const [copied, setCopied] = useState(false);
// // // //   const [selectedImage, setSelectedImage] = useState(0);
// // // //   const [activeTab, setActiveTab] = useState('details');
// // // //   const [isFavorite, setIsFavorite] = useState(false);
// // // //   const [imagesLoaded, setImagesLoaded] = useState({});
// // // //   const [showStoryPopup, setShowStoryPopup] = useState(false);
// // // //   const [storyUserId, setStoryUserId] = useState(null);

// // // //   useEffect(() => {
// // // //     const fetchPropertyData = async () => {
// // // //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// // // //       setLoading(true); setError(null);
// // // //       try {
// // // //         const controller = new AbortController();
// // // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// // // //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// // // //         clearTimeout(timeoutId);
// // // //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// // // //         const result = await response.json();
        
// // // //         console.log('📦 Full API response:', result);
        
// // // //         if (result.status === 200 && result.data) {
// // // //           const data = result.data;
          
// // // //           const agentImage = data.agents?.image 
// // // //             ? `https://localhost:7178/${data.agents.image}` 
// // // //             : "https://randomuser.me/api/portraits/men/32.jpg";
          
// // // //           const userId = data.agents?.userId || null;
// // // //           const hasStory = data.agents?.hasStory || false;
          
// // // //           console.log('👤 Agent UserId:', userId);
// // // //           console.log('📱 HasStory:', hasStory);
          
// // // //           setStoryUserId(userId);
          
// // // //           setProperty({
// // // //             id: data.id, 
// // // //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
// // // //             price: data.price?.toLocaleString("fa-IR") || "۰",
// // // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
// // // //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
// // // //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // // //             type: data.categoryType, 
// // // //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
// // // //             rooms: data.rooms || 0,
// // // //             floor: data.floor || 1, 
// // // //             regionName: data.regionName || "منطقه نامشخص", 
// // // //             totalFloors: data.countFloor || 1,
// // // //             year: data.constructionYear || "نامشخص", 
// // // //             address: data.address || "آدرس درج نشده", 
// // // //             showExactLocation: data.showExactLocation,
// // // //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// // // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
// // // //             features: data.facilities || [],
// // // //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// // // //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// // // //             agent: { 
// // // //               name: data.agents?.name || "مشاور املاک", 
// // // //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
// // // //               whatsapp: data.agents?.connectSocialMedia || "", 
// // // //               address: data.agents?.address || "آدرس دفتر درج نشده", 
// // // //               rating: data.agents?.rating || 4.5, 
// // // //               deals: data.agents?.deals || 120, 
// // // //               image: agentImage,
// // // //               hasStory: hasStory,
// // // //               userId: userId
// // // //             },
// // // //             views: data.views || 0, 
// // // //             saved: data.saved || 0, 
// // // //             createdAt: data.createdAtPersianRelative || "امروز", 
// // // //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
// // // //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // // //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// // // //           });
// // // //         } else throw new Error(result.message || 'ملک یافت نشد');
// // // //       } catch (error) { 
// // // //         console.error('خطا:', error); 
// // // //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
// // // //       } finally { 
// // // //         setLoading(false); 
// // // //       }
// // // //     };
// // // //     fetchPropertyData();
// // // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // // //   }, [id]);

// // // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // // //   const isForRent = useMemo(() => property?.type === 2, [property]);
// // // //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// // // //   const shareUrl = useMemo(() => window.location.href, []);

// // // //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// // // //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// // // //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// // // //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// // // //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
// // // //   // ✅ هندلر باز کردن استوری - فقط اگر userId وجود داشته باشه
// // // //   const handleStoryClick = useCallback(() => {
// // // //     console.log('🖱️ کلیک روی استوری');
// // // //     console.log('🆔 storyUserId:', storyUserId);
    
// // // //     if (storyUserId) {
// // // //       console.log('✅ باز کردن استوری برای userId:', storyUserId);
// // // //       setShowStoryPopup(true);
// // // //       document.body.style.overflow = 'hidden';
// // // //     } else {
// // // //       console.log('❌ userId وجود ندارد - قابل کلیک نیست');
// // // //     }
// // // //   }, [storyUserId]);

// // // //   // ✅ هندلر بستن استوری
// // // //   const handleStoryClose = useCallback(() => {
// // // //     setShowStoryPopup(false);
// // // //     document.body.style.overflow = '';
// // // //   }, []);

// // // //   if (error) return ( 
// // // //     <> 
// // // //       <PageMetadata property={null} /> 
// // // //       <div className="detail-container realestate-detail">
// // // //         <div className="detail-header">
// // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // //           <h1 className="header-title">خطا</h1>
// // // //           <div className="header-btn"></div>
// // // //         </div>
// // // //         <div className="error-message">
// // // //           <h2>متاسفانه خطایی رخ داده است</h2>
// // // //           <p>{error}</p>
// // // //           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
// // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // //         </div>
// // // //       </div>
// // // //     </> 
// // // //   );
  
// // // //   if (loading) return <DetailSkeleton />;
  
// // // //   if (!property) return ( 
// // // //     <> 
// // // //       <PageMetadata property={null} /> 
// // // //       <div className="detail-container realestate-detail">
// // // //         <div className="detail-header">
// // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // //           <h1 className="header-title">ملک یافت نشد</h1>
// // // //           <div className="header-btn"></div>
// // // //         </div>
// // // //         <div className="error-message">
// // // //           <p>متاسفانه ملک مورد نظر یافت نشد</p>
// // // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // // //         </div>
// // // //       </div>
// // // //     </> 
// // // //   );

// // // //   return ( 
// // // //     <>
// // // //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // // //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // // //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
// // // //       {/* ✅ پاپ‌آپ استوری */}
// // // //       {showStoryPopup && (
// // // //         <StoryPopup 
// // // //           agentName={property.agent.name}
// // // //           agentImage={property.agent.image}
// // // //           userId={storyUserId}
// // // //           onClose={handleStoryClose}
// // // //         />
// // // //       )}
      
// // // //       <div className="detail-container realestate-detail">
// // // //         <nav className="breadcrumb-nav">
// // // //           <ol className="breadcrumb-list">
// // // //             <li className="breadcrumb-item"><a href="/">خانه</a></li>
// // // //             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
// // // //             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
// // // //             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
// // // //           </ol>
// // // //         </nav>
        
// // // //         <div className="detail-header">
// // // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // // //           <h1 className="header-title">{property.title}</h1>
// // // //           <button className="header-btn" onClick={handleShare}><FaShare /></button>
// // // //         </div>
        
// // // //         <div className="detail-gallery">
// // // //           <Swiper 
// // // //             modules={[Navigation, Pagination, Autoplay]} 
// // // //             navigation 
// // // //             pagination={{ clickable: true }} 
// // // //             autoplay={{ delay: 4000, disableOnInteraction: false }} 
// // // //             spaceBetween={0} 
// // // //             slidesPerView={1} 
// // // //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
// // // //             className="gallery-swiper"
// // // //           >
// // // //             {property.images.length > 0 ? 
// // // //               property.images.map((img, index) => (
// // // //                 <SwiperSlide key={index}>
// // // //                   <div className="gallery-slide">
// // // //                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
// // // //                     <img 
// // // //                       src={img} 
// // // //                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
// // // //                       loading={index === 0 ? 'eager' : 'lazy'} 
// // // //                       onLoad={() => handleImageLoad(index)} 
// // // //                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
// // // //                     />
// // // //                   </div>
// // // //                 </SwiperSlide>
// // // //               )) : 
// // // //               (<SwiperSlide>
// // // //                 <div className="gallery-slide no-image">
// // // //                   <FaHome />
// // // //                   <span>تصویری موجود نیست</span>
// // // //                 </div>
// // // //               </SwiperSlide>)
// // // //             }
// // // //           </Swiper>
// // // //           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
// // // //             {isFavorite ? <FaHeart /> : <FaRegHeart />}
// // // //           </button>
// // // //           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
// // // //         </div>
        
// // // //         <div className="detail-main">
// // // //           <div className="detail-title-section">
// // // //             <div className="title-row">
// // // //               <div className="property-stats">
// // // //                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
// // // //                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
// // // //                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
// // // //               </div>
// // // //             </div>
// // // //           </div>
          
// // // //           <div className="price-section">
// // // //             {isForSale && (
// // // //               <div className="price-card sale-price">
// // // //                 <div className="price-card-icon"><FaTag /></div>
// // // //                 <div className="price-card-content">
// // // //                   <span className="price-label">قیمت فروش</span>
// // // //                   <div className="price-value-wrapper">
// // // //                     <span className="price-number">{property.price}</span>
// // // //                     <span className="price-unit">تومان</span>
// // // //                   </div>
// // // //                   {formattedPricePerMeter && 
// // // //                     <div className="price-meta">
// // // //                       <FaRuler />
// // // //                       <span>متری {formattedPricePerMeter}</span>
// // // //                     </div>
// // // //                   }
// // // //                 </div>
// // // //               </div>
// // // //             )}
            
// // // //             {isForRent && (
// // // //               <div className="rent-price-group">
// // // //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// // // //                   <div className="price-card mortgage-price">
// // // //                     <div className="price-card-icon"><FaBuilding /></div>
// // // //                     <div className="price-card-content">
// // // //                       <span className="price-label">مبلغ رهن</span>
// // // //                       <div className="price-value-wrapper">
// // // //                         <span className="price-number">{property.mortgagePrice}</span>
// // // //                         <span className="price-unit">تومان</span>
// // // //                       </div>
// // // //                     </div>
// // // //                   </div>
// // // //                 )}
// // // //                 {property.rentPrice && property.rentPrice !== "۰" && (
// // // //                   <div className="price-card rent-price">
// // // //                     <div className="price-card-icon"><FaHome /></div>
// // // //                     <div className="price-card-content">
// // // //                       <span className="price-label">اجاره ماهانه</span>
// // // //                       <div className="price-value-wrapper">
// // // //                         <span className="price-number">{property.rentPrice}</span>
// // // //                         <span className="price-unit">تومان</span>
// // // //                       </div>
// // // //                     </div>
// // // //                   </div>
// // // //                 )}
// // // //               </div>
// // // //             )}
// // // //           </div>
          
// // // //           <div className="quick-specs">
// // // //             <div className="spec-item">
// // // //               <FaRulerCombined />
// // // //               <span className="spec-label">متراژ</span>
// // // //               <span className="spec-value">{property.area} متر²</span>
// // // //             </div>
// // // //             <div className="spec-item">
// // // //               <FaBath />
// // // //               <span className="spec-label">اتاق‌خواب</span>
// // // //               <span className="spec-value">{property.rooms} خواب</span>
// // // //             </div>
// // // //             <div className="spec-item">
// // // //               <FaLayerGroup />
// // // //               <span className="spec-label">طبقه</span>
// // // //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// // // //             </div>
// // // //             <div className="spec-item">
// // // //               <FaCalendarAlt />
// // // //               <span className="spec-label">سال ساخت</span>
// // // //               <span className="spec-value">{property.year}</span>
// // // //             </div>
// // // //           </div>
          
// // // //           <div className="info-chips">
// // // //             <span className="info-chip">کد ملک: {property.id}</span>
// // // //             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
// // // //             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
// // // //           </div>
          
// // // //           <div className="detail-tabs">
// // // //             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
// // // //             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
// // // //             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
// // // //             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
// // // //           </div>
          
// // // //           <div className="tab-content">
// // // //             {activeTab === 'details' && (
// // // //               <div className="details-tab">
// // // //                 <div className="address-card">
// // // //                   <FaMapMarkerAlt />
// // // //                   <div className="address-info">
// // // //                     <h3>آدرس ملک</h3>
// // // //                     <div>منطقه {property.regionName}</div>
// // // //                     <p>{property.address}</p>
// // // //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// // // //                   </div>
// // // //                 </div>
// // // //                 <div className="description-card">
// // // //                   <h3>توضیحات کامل {property.title}</h3>
// // // //                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
// // // //                 </div>
// // // //                 <div className="map-card">
// // // //                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
// // // //                   <div className="map-location-badge">
// // // //                     {property.showExactLocation ? 
// // // //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
// // // //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
// // // //                     }
// // // //                   </div>
// // // //                   <div className="map-container">
// // // //                     <NeshanMap 
// // // //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
// // // //                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
// // // //                       zoom={property.showExactLocation ? 17 : 15.9} 
// // // //                       defaultType="dreamy" 
// // // //                       poi={true} 
// // // //                       traffic={false} 
// // // //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
// // // //                     />
// // // //                     <div className="map-marker-overlay">
// // // //                       {property.showExactLocation ? 
// // // //                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
// // // //                         <div className="location-circles"><div className="circle-3"></div></div>
// // // //                       }
// // // //                     </div>
// // // //                   </div>
// // // //                   <div className="map-privacy-note">
// // // //                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
// // // //                   </div>
// // // //                 </div>
// // // //               </div>
// // // //             )}
            
// // // //             {activeTab === 'features' && (
// // // //               <div className="features-tab">
// // // //                 <h3>امکانات و ویژگی‌ها</h3>
// // // //                 <div className="features-grid">
// // // //                   {property.features.length > 0 ? 
// // // //                     property.features.map((feature, idx) => {
// // // //                       let Icon = FaCheckCircle;
// // // //                       if (feature.includes('پارکینگ')) Icon = FaParking;
// // // //                       else if (feature.includes('انباری')) Icon = FaWarehouse;
// // // //                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
// // // //                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
// // // //                       return (
// // // //                         <div key={idx} className="feature-card">
// // // //                           <Icon />
// // // //                           <span>{feature}</span>
// // // //                         </div>
// // // //                       );
// // // //                     }) : 
// // // //                     <p className="no-data">امکاناتی ثبت نشده است</p>
// // // //                   }
// // // //                 </div>
// // // //               </div>
// // // //             )}
            
// // // //             {activeTab === 'warnings' && (
// // // //               <div className="warnings-tab">
// // // //                 <h3>⚠️ هشدارهای مهم</h3>
// // // //                 <ul className="warnings-list">
// // // //                   {property.warnings.map((w, idx) => (
// // // //                     <li key={idx} className="warning-item">
// // // //                       <span className="warning-bullet"></span>
// // // //                       <span>{w}</span>
// // // //                     </li>
// // // //                   ))}
// // // //                 </ul>
// // // //                 <div className="warning-footer">
// // // //                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
// // // //                 </div>
// // // //               </div>
// // // //             )}
            
// // // //             {activeTab === 'nearby' && (
// // // //               <div className="nearby-tab">
// // // //                 <h3>امکانات اطراف</h3>
// // // //                 <div className="nearby-list">
// // // //                   {property.nearby.map((item, idx) => (
// // // //                     <div key={idx} className="nearby-item">
// // // //                       <span className="nearby-name">{item.name}</span>
// // // //                       <span className="nearby-distance">{item.distance}</span>
// // // //                     </div>
// // // //                   ))}
// // // //                 </div>
// // // //               </div>
// // // //             )}
// // // //           </div>
          
// // // //           {/* ========== کارت مشاور با استوری (مثل اینستاگرام) ========== */}
// // // //           <div className="agent-card">
// // // //             <div className="agent-header">
// // // //               <div 
// // // //                 className={`agent-avatar-wrapper ${storyUserId ? 'has-story' : ''}`}
// // // //                 onClick={storyUserId ? handleStoryClick : undefined}
// // // //                 style={{ 
// // // //                   cursor: storyUserId ? 'pointer' : 'default',
// // // //                   position: 'relative',
// // // //                   display: 'inline-block',
// // // //                   flexShrink: 0
// // // //                 }}
// // // //               >
// // // //                 <SafeImage 
// // // //                   src={property.agent.image} 
// // // //                   alt={property.agent.name} 
// // // //                   className={`agent-avatar ${storyUserId ? 'has-story' : ''}`}
// // // //                   fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
// // // //                 />
                
// // // //                 {/* ✅ رینگ قرمز - فقط در صورتی که استوری داشته باشه */}
// // // //                 {storyUserId && (
// // // //                   <div className="story-ring-indicator">
// // // //                     <div className="story-ring-gradient"></div>
// // // //                   </div>
// // // //                 )}
// // // //               </div>
              
// // // //               <div className="agent-info">
// // // //                 <div className="agent-name-wrapper">
// // // //                   <h3>{property.agent.name}</h3>
// // // //                   {/* ✅ برچسب استوری - فقط در صورتی که استوری داشته باشه */}
// // // //                   {storyUserId && (
// // // //                     <span 
// // // //                       className="story-label" 
// // // //                       onClick={handleStoryClick}
// // // //                       style={{ cursor: 'pointer' }}
// // // //                     >
// // // //                       <span className="story-dot"></span>
// // // //                       استوری
// // // //                     </span>
// // // //                   )}
// // // //                 </div>
// // // //                 <p>{property.agent.address}</p>
// // // //                 <div className="agent-rating">
// // // //                   <FaStar />
// // // //                   <span>{property.agent.rating}</span>
// // // //                   <span>({property.agent.deals} معامله)</span>
// // // //                 </div>
// // // //               </div>
// // // //             </div>
            
// // // //             <div className="agent-actions">
// // // //               <button className="agent-action-btn phone" onClick={handleCopyPhone}>
// // // //                 <FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}
// // // //               </button>
// // // //               <a 
// // // //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// // // //                 target="_blank" 
// // // //                 rel="noopener noreferrer" 
// // // //                 className="agent-action-btn whatsapp"
// // // //               >
// // // //                 <FaWhatsapp /> واتساپ
// // // //               </a>
// // // //             </div>
// // // //           </div>
// // // //         </div>
        
// // // //         <DoubleSidebarBanners />
// // // //         <RelatedPropertiesSlider 
// // // //           currentPropertyId={property.id} 
// // // //           regionName={property.regionName} 
// // // //           propertyType={property.type} 
// // // //         />
        
// // // //         {copied && (
// // // //           <div className="toast-notification">
// // // //             <FaCheckCircle /> لینک کپی شد
// // // //           </div>
// // // //         )}
// // // //       </div>  
// // // //     </> 
// // // //   );
// // // // });

// // // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // // // export default RealEstateDetailPageItem;


// // // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // // import CryptoJS from 'crypto-js';
// // // import DOMPurify from 'dompurify';
// // // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // // import DoubleSidebarBanners from './SidebarBanner';
// // // import { 
// // //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// // //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// // //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// // //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaLink
// // // } from 'react-icons/fa';
// // // import { Swiper, SwiperSlide } from 'swiper/react';
// // // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // // import 'swiper/css';
// // // import 'swiper/css/navigation';
// // // import 'swiper/css/pagination';
// // // import './RealEstateDetailPageItem.css';

// // // // ========== کامپوننت پاپ‌آپ استوری ==========
// // // const StoryPopup = ({ agentName, agentImage, userId, onClose }) => {
// // //   const [stories, setStories] = useState([]);
// // //   const [loading, setLoading] = useState(true);
// // //   const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
// // //   const [progress, setProgress] = useState(0);
// // //   const [isPaused, setIsPaused] = useState(false);
// // //   const [error, setError] = useState(null);

// // //   // دریافت استوری‌ها از API
// // //   useEffect(() => {
// // //     const fetchStories = async () => {
// // //       if (!userId) {
// // //         setError('شناسه کاربر یافت نشد');
// // //         setLoading(false);
// // //         return;
// // //       }

// // //       try {
// // //         setLoading(true);
// // //         console.log('📡 در حال دریافت استوری برای userId:', userId);
        
// // //         const response = await fetch(`https://localhost:7178/api/Story/StoryForSiteForUser?userId=${userId}`);
        
// // //         console.log('📡 Response status:', response.status);
        
// // //         if (!response.ok) {
// // //           throw new Error(`HTTP ${response.status}`);
// // //         }
        
// // //         const result = await response.json();
// // //         console.log('📦 نتیجه استوری:', result);
        
// // //         if (result.status === 200 && result.data && result.data.length > 0) {
// // //           const userStories = result.data[0]?.storyUser || [];
// // //           console.log('📸 تعداد استوری‌ها:', userStories.length);
          
// // //           const formattedStories = userStories.map(story => ({
// // //             ...story,
// // //             url: `https://localhost:7178${story.url}`
// // //           }));
// // //           setStories(formattedStories);
// // //         } else {
// // //           console.log('⚠️ هیچ استوری پیدا نشد');
// // //           setStories([]);
// // //         }
// // //       } catch (error) {
// // //         console.error('❌ خطا در دریافت استوری:', error);
// // //         setError('مشکل در دریافت استوری‌ها');
// // //       } finally {
// // //         setLoading(false);
// // //       }
// // //     };

// // //     fetchStories();
// // //   }, [userId]);

// // //   // مدیریت پخش خودکار استوری‌ها
// // //   useEffect(() => {
// // //     if (isPaused || loading || stories.length === 0) return;

// // //     const timer = setInterval(() => {
// // //       setProgress(prev => {
// // //         const newProgress = prev + 1;
// // //         if (newProgress >= 100) {
// // //           if (currentStoryIndex < stories.length - 1) {
// // //             setCurrentStoryIndex(prev => prev + 1);
// // //             return 0;
// // //           } else {
// // //             onClose();
// // //             return 0;
// // //           }
// // //         }
// // //         return newProgress;
// // //       });
// // //     }, 50);

// // //     return () => clearInterval(timer);
// // //   }, [currentStoryIndex, isPaused, loading, stories, onClose]);

// // //   // هندلرهای ناوبری
// // //   const handlePrevStory = useCallback((e) => {
// // //     e.stopPropagation();
// // //     if (currentStoryIndex > 0) {
// // //       setCurrentStoryIndex(prev => prev - 1);
// // //       setProgress(0);
// // //     }
// // //   }, [currentStoryIndex]);

// // //   const handleNextStory = useCallback((e) => {
// // //     e.stopPropagation();
// // //     if (currentStoryIndex < stories.length - 1) {
// // //       setCurrentStoryIndex(prev => prev + 1);
// // //       setProgress(0);
// // //     } else {
// // //       onClose();
// // //     }
// // //   }, [currentStoryIndex, stories.length, onClose]);

// // //   // کلیک روی لینک استوری
// // //   const handleStoryLink = useCallback((link) => {
// // //     if (link) {
// // //       window.location.href = link;
// // //     }
// // //   }, []);

// // //   if (loading) {
// // //     return (
// // //       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
// // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // //           <div style={{ 
// // //             display: 'flex', 
// // //             alignItems: 'center', 
// // //             justifyContent: 'center', 
// // //             height: '100%',
// // //             color: 'white',
// // //             fontSize: '18px',
// // //             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// // //           }}>
// // //             در حال بارگذاری استوری‌ها...
// // //           </div>
// // //         </div>
// // //       </div>
// // //     );
// // //   }

// // //   if (error || stories.length === 0) {
// // //     return (
// // //       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
// // //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // //           <div style={{ 
// // //             display: 'flex', 
// // //             flexDirection: 'column',
// // //             alignItems: 'center', 
// // //             justifyContent: 'center', 
// // //             height: '100%',
// // //             color: 'white',
// // //             fontSize: '16px',
// // //             padding: '20px',
// // //             textAlign: 'center',
// // //             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// // //           }}>
// // //             <p>{error || 'هیچ استوری برای این کاربر وجود ندارد'}</p>
// // //             <button 
// // //               onClick={onClose}
// // //               style={{
// // //                 marginTop: '20px',
// // //                 padding: '10px 30px',
// // //                 background: '#ff0000',
// // //                 color: 'white',
// // //                 border: 'none',
// // //                 borderRadius: '8px',
// // //                 cursor: 'pointer',
// // //                 fontSize: '14px',
// // //                 fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// // //               }}
// // //             >
// // //               بستن
// // //             </button>
// // //           </div>
// // //         </div>
// // //       </div>
// // //     );
// // //   }

// // //   const currentStory = stories[currentStoryIndex];

// // //   return (
// // //     <div 
// // //       className="realestate-detail story-popup-overlay"
// // //       onClick={onClose}
// // //       onMouseEnter={() => setIsPaused(true)}
// // //       onMouseLeave={() => setIsPaused(false)}
// // //     >
// // //       <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// // //         {/* نوارهای پیشرفت */}
// // //         <div className="story-progress-container">
// // //           {stories.map((_, index) => (
// // //             <div 
// // //               key={index} 
// // //               className="story-progress-bar"
// // //             >
// // //               <div 
// // //                 className="story-progress-fill"
// // //                 style={{
// // //                   width: index < currentStoryIndex ? '100%' : 
// // //                          index === currentStoryIndex ? `${progress}%` : '0%'
// // //                 }}
// // //               />
// // //             </div>
// // //           ))}
// // //         </div>

// // //         {/* هدر */}
// // //         <div className="story-header">
// // //           <div className="story-user-info">
// // //             <img 
// // //               src={agentImage} 
// // //               alt={agentName} 
// // //               className="story-user-avatar"
// // //             />
// // //             <span className="story-user-name">{agentName}</span>
// // //             <span className="story-time">لحظاتی پیش</span>
// // //           </div>
// // //           <button className="story-close-btn" onClick={onClose}>✕</button>
// // //         </div>

// // //         {/* محتوای استوری */}
// // //         <div className="story-content">
// // //           <img 
// // //             src={currentStory.url} 
// // //             alt={currentStory.caption || 'استوری'} 
// // //             className="story-image"
// // //           />
          
// // //           {/* کپشن */}
// // //           {currentStory.caption && (
// // //             <div className="story-caption">
// // //               {currentStory.caption}
// // //             </div>
// // //           )}

// // //           {/* لینک استوری */}
// // //           {currentStory.link && (
// // //             <div 
// // //               className="story-link-button"
// // //               onClick={() => handleStoryLink(currentStory.link)}
// // //             >
// // //               <FaLink />
// // //               <span>{currentStory.linkText || 'مشاهده بیشتر'}</span>
// // //             </div>
// // //           )}
// // //         </div>

// // //         {/* دکمه‌های ناوبری */}
// // //         <div 
// // //           className="story-nav-left"
// // //           onClick={handlePrevStory}
// // //         />
// // //         <div 
// // //           className="story-nav-right"
// // //           onClick={handleNextStory}
// // //         />
// // //       </div>
// // //     </div>
// // //   );
// // // };

// // // // ========== کامپوننت SafeImage ==========
// // // const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
// // //   const [error, setError] = useState(false);

// // //   if (!src || error) {
// // //     return (
// // //       <img 
// // //         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
// // //         alt={alt || 'تصویر'} 
// // //         className={className}
// // //         {...props}
// // //       />
// // //     );
// // //   }

// // //   return (
// // //     <img
// // //       src={src}
// // //       alt={alt}
// // //       className={className}
// // //       onError={() => {
// // //         setError(true);
// // //       }}
// // //       {...props}
// // //     />
// // //   );
// // // };

// // // // ========== توابع کمکی ==========
// // // const stripHtml = (html) => {
// // //   if (!html) return '';
// // //   const temp = document.createElement('div');
// // //   temp.innerHTML = html;
// // //   return temp.textContent || temp.innerText || '';
// // // };

// // // const truncateText = (text, maxLength) => {
// // //   if (!text) return '';
// // //   if (text.length <= maxLength) return text;
// // //   return text.substring(0, maxLength - 2) + '…';
// // // };

// // // // ========== کامپوننت‌های متا ==========
// // // const PageMetadata = ({ property, isForSale, isForRent }) => {
// // //   useEffect(() => {
// // //     if (!property) return;
// // //     let title = property.title 
// // //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// // //       : `ملک ${property.area} متری ${property.regionName}`;
// // //     title = truncateText(title, 65);
// // //     document.title = title;
// // //     const plainDescription = stripHtml(property.description || '');
// // //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// // //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// // //     description = truncateText(description, 155);
// // //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// // //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// // //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// // //       let meta = document.querySelector(selector);
// // //       if (!meta) {
// // //         meta = document.createElement('meta');
// // //         if (isProperty) meta.setAttribute('property', name);
// // //         else meta.setAttribute('name', name);
// // //         document.head.appendChild(meta);
// // //       }
// // //       meta.setAttribute('content', content);
// // //     };
// // //     updateOrCreateMeta('description', description);
// // //     updateOrCreateMeta('keywords', keywords);
// // //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// // //     let canonical = document.querySelector('link[rel="canonical"]');
// // //     if (!canonical) {
// // //       canonical = document.createElement('link');
// // //       canonical.rel = 'canonical';
// // //       document.head.appendChild(canonical);
// // //     }
// // //     canonical.href = window.location.href;
// // //     updateOrCreateMeta('og:title', title, true);
// // //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// // //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// // //     updateOrCreateMeta('og:url', window.location.href, true);
// // //     updateOrCreateMeta('og:type', 'product', true);
// // //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// // //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// // //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// // //     updateOrCreateMeta('twitter:title', title);
// // //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// // //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// // //     document.documentElement.lang = 'fa';
// // //     document.documentElement.dir = 'rtl';
// // //   }, [property, isForSale, isForRent]);
// // //   return null;
// // // };

// // // const StructuredData = ({ property, isForSale, isForRent }) => {
// // //   useEffect(() => {
// // //     if (!property) return;
// // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// // //     removeOldScript();
// // //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// // //     const structuredData = {
// // //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// // //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// // //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// // //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// // //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// // //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// // //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// // //       "numberOfRooms": property.rooms || 0,
// // //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// // //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// // //     };
// // //     const script = document.createElement('script');
// // //     script.id = 'json-ld-structured-data';
// // //     script.type = 'application/ld+json';
// // //     script.textContent = JSON.stringify(structuredData);
// // //     document.head.appendChild(script);
// // //     return () => removeOldScript();
// // //   }, [property, isForSale, isForRent]);
// // //   return null;
// // // };

// // // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// // //   useEffect(() => {
// // //     if (!property) return;
// // //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// // //     removeOldScript();
// // //     const baseUrl = window.location.origin;
// // //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// // //     const breadcrumbData = {
// // //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// // //       "itemListElement": [
// // //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// // //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// // //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// // //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// // //       ]
// // //     };
// // //     const script = document.createElement('script');
// // //     script.id = 'json-ld-breadcrumb';
// // //     script.type = 'application/ld+json';
// // //     script.textContent = JSON.stringify(breadcrumbData);
// // //     document.head.appendChild(script);
// // //     return () => removeOldScript();
// // //   }, [property, isForSale]);
// // //   return null;
// // // };

// // // // ========== Skeleton ==========
// // // const DetailSkeleton = () => (
// // //   <div className="detail-skeleton">
// // //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// // //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// // //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// // //   </div>
// // // );

// // // // ========== کامپوننت اصلی ==========
// // // const RealEstateDetailPageItem = memo(() => {
// // //   const location = useLocation();
// // //   const navigate = useNavigate();
// // //   const { id: paramId } = useParams();
// // //   const queryParams = new URLSearchParams(location.search);
// // //   const id = paramId || queryParams.get('id');
// // //   const [property, setProperty] = useState(null);
// // //   const [loading, setLoading] = useState(true);
// // //   const [error, setError] = useState(null);
// // //   const [copied, setCopied] = useState(false);
// // //   const [selectedImage, setSelectedImage] = useState(0);
// // //   const [activeTab, setActiveTab] = useState('details');
// // //   const [isFavorite, setIsFavorite] = useState(false);
// // //   const [imagesLoaded, setImagesLoaded] = useState({});
// // //   const [showStoryPopup, setShowStoryPopup] = useState(false);
// // //   const [storyUserId, setStoryUserId] = useState(null);

// // //   useEffect(() => {
// // //     const fetchPropertyData = async () => {
// // //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// // //       setLoading(true); setError(null);
// // //       try {
// // //         const controller = new AbortController();
// // //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// // //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// // //         clearTimeout(timeoutId);
// // //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// // //         const result = await response.json();
        
// // //         console.log('📦 Full API response:', result);
        
// // //         if (result.status === 200 && result.data) {
// // //           const data = result.data;
          
// // //           const agentImage = data.agents?.image 
// // //             ? `https://localhost:7178/${data.agents.image}` 
// // //             : "https://randomuser.me/api/portraits/men/32.jpg";
          
// // //           const userId = data.agents?.userId || null;
// // //           const hasStory = data.agents?.hasStory || false;
          
// // //           console.log('👤 Agent UserId:', userId);
// // //           console.log('📱 HasStory:', hasStory);
          
// // //             setStoryUserId(hasStory ? userId : null);
          
// // //           setProperty({
// // //             id: data.id, 
// // //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
// // //             price: data.price?.toLocaleString("fa-IR") || "۰",
// // //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
// // //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// // //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
// // //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// // //             type: data.categoryType, 
// // //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
// // //             rooms: data.rooms || 0,
// // //             floor: data.floor || 1, 
// // //             regionName: data.regionName || "منطقه نامشخص", 
// // //             totalFloors: data.countFloor || 1,
// // //             year: data.constructionYear || "نامشخص", 
// // //             address: data.address || "آدرس درج نشده", 
// // //             showExactLocation: data.showExactLocation,
// // //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// // //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
// // //             features: data.facilities || [],
// // //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// // //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// // //             agent: { 
// // //               name: data.agents?.name || "مشاور املاک", 
// // //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
// // //               whatsapp: data.agents?.connectSocialMedia || "", 
// // //               address: data.agents?.address || "آدرس دفتر درج نشده", 
// // //               rating: data.agents?.rating || 4.5, 
// // //               deals: data.agents?.deals || 120, 
// // //               image: agentImage,
// // //               hasStory: hasStory,
// // //               userId: userId
// // //             },
// // //             views: data.views || 0, 
// // //             saved: data.saved || 0, 
// // //             createdAt: data.createdAtPersianRelative || "امروز", 
// // //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
// // //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// // //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// // //           });
// // //         } else throw new Error(result.message || 'ملک یافت نشد');
// // //       } catch (error) { 
// // //         console.error('خطا:', error); 
// // //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
// // //       } finally { 
// // //         setLoading(false); 
// // //       }
// // //     };
// // //     fetchPropertyData();
// // //     window.scrollTo({ top: 0, behavior: 'smooth' });
// // //   }, [id]);

// // //   const isForSale = useMemo(() => property?.type === 1, [property]);
// // //   const isForRent = useMemo(() => property?.type === 2, [property]);
// // //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// // //   const shareUrl = useMemo(() => window.location.href, []);

// // //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// // //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// // //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// // //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// // //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
// // //   // ✅ رفتن به پروفایل کاربر
// // //   const goToProfile = useCallback(() => {
// // //     if (property?.agent?.userId) {
// // //       console.log('👤 رفتن به پروفایل کاربر:', property.agent.userId);
// // //       // مسیر پروفایل رو اینجا تنظیم کن
// // //       window.location.href = `/profile/${property.agent.userId}`;
// // //       // یا اگر از react-router استفاده می‌کنی:
// // //       // navigate(`/profile/${property.agent.userId}`);
// // //     }
// // //   }, [property]);

// // //   // ✅ باز کردن استوری
// // //   const handleStoryClick = useCallback((e) => {
// // //     if (e) {
// // //       e.stopPropagation(); // ✅ جلوگیری از رفتن به پروفایل
// // //     }
    
// // //     console.log('🖱️ کلیک روی استوری');
// // //     console.log('🆔 storyUserId:', storyUserId);
    
// // //     if (storyUserId) {
// // //       console.log('✅ باز کردن استوری برای userId:', storyUserId);
// // //       setShowStoryPopup(true);
// // //       document.body.style.overflow = 'hidden';
// // //     } else {
// // //       console.log('❌ userId وجود ندارد');
// // //     }
// // //   }, [storyUserId]);

// // //   // ✅ بستن استوری
// // //   const handleStoryClose = useCallback(() => {
// // //     setShowStoryPopup(false);
// // //     document.body.style.overflow = '';
// // //   }, []);

// // //   if (error) return ( 
// // //     <> 
// // //       <PageMetadata property={null} /> 
// // //       <div className="detail-container realestate-detail">
// // //         <div className="detail-header">
// // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // //           <h1 className="header-title">خطا</h1>
// // //           <div className="header-btn"></div>
// // //         </div>
// // //         <div className="error-message">
// // //           <h2>متاسفانه خطایی رخ داده است</h2>
// // //           <p>{error}</p>
// // //           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
// // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // //         </div>
// // //       </div>
// // //     </> 
// // //   );
  
// // //   if (loading) return <DetailSkeleton />;
  
// // //   if (!property) return ( 
// // //     <> 
// // //       <PageMetadata property={null} /> 
// // //       <div className="detail-container realestate-detail">
// // //         <div className="detail-header">
// // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // //           <h1 className="header-title">ملک یافت نشد</h1>
// // //           <div className="header-btn"></div>
// // //         </div>
// // //         <div className="error-message">
// // //           <p>متاسفانه ملک مورد نظر یافت نشد</p>
// // //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// // //         </div>
// // //       </div>
// // //     </> 
// // //   );

// // //   return ( 
// // //     <>
// // //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// // //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// // //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
// // //       {/* ✅ پاپ‌آپ استوری */}
// // //       {showStoryPopup && (
// // //         <StoryPopup 
// // //           agentName={property.agent.name}
// // //           agentImage={property.agent.image}
// // //           userId={storyUserId}
// // //           onClose={handleStoryClose}
// // //         />
// // //       )}
      
// // //       <div className="detail-container realestate-detail">
// // //         <nav className="breadcrumb-nav">
// // //           <ol className="breadcrumb-list">
// // //             <li className="breadcrumb-item"><a href="/">خانه</a></li>
// // //             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
// // //             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
// // //             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
// // //           </ol>
// // //         </nav>
        
// // //         <div className="detail-header">
// // //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// // //           <h1 className="header-title">{property.title}</h1>
// // //           <button className="header-btn" onClick={handleShare}><FaShare /></button>
// // //         </div>
        
// // //         <div className="detail-gallery">
// // //           <Swiper 
// // //             modules={[Navigation, Pagination, Autoplay]} 
// // //             navigation 
// // //             pagination={{ clickable: true }} 
// // //             autoplay={{ delay: 4000, disableOnInteraction: false }} 
// // //             spaceBetween={0} 
// // //             slidesPerView={1} 
// // //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
// // //             className="gallery-swiper"
// // //           >
// // //             {property.images.length > 0 ? 
// // //               property.images.map((img, index) => (
// // //                 <SwiperSlide key={index}>
// // //                   <div className="gallery-slide">
// // //                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
// // //                     <img 
// // //                       src={img} 
// // //                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
// // //                       loading={index === 0 ? 'eager' : 'lazy'} 
// // //                       onLoad={() => handleImageLoad(index)} 
// // //                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
// // //                     />
// // //                   </div>
// // //                 </SwiperSlide>
// // //               )) : 
// // //               (<SwiperSlide>
// // //                 <div className="gallery-slide no-image">
// // //                   <FaHome />
// // //                   <span>تصویری موجود نیست</span>
// // //                 </div>
// // //               </SwiperSlide>)
// // //             }
// // //           </Swiper>
// // //           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
// // //             {isFavorite ? <FaHeart /> : <FaRegHeart />}
// // //           </button>
// // //           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
// // //         </div>
        
// // //         <div className="detail-main">
// // //           <div className="detail-title-section">
// // //             <div className="title-row">
// // //               <div className="property-stats">
// // //                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
// // //                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
// // //                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
// // //               </div>
// // //             </div>
// // //           </div>
          
// // //           <div className="price-section">
// // //             {isForSale && (
// // //               <div className="price-card sale-price">
// // //                 <div className="price-card-icon"><FaTag /></div>
// // //                 <div className="price-card-content">
// // //                   <span className="price-label">قیمت فروش</span>
// // //                   <div className="price-value-wrapper">
// // //                     <span className="price-number">{property.price}</span>
// // //                     <span className="price-unit">تومان</span>
// // //                   </div>
// // //                   {formattedPricePerMeter && 
// // //                     <div className="price-meta">
// // //                       <FaRuler />
// // //                       <span>متری {formattedPricePerMeter}</span>
// // //                     </div>
// // //                   }
// // //                 </div>
// // //               </div>
// // //             )}
            
// // //             {isForRent && (
// // //               <div className="rent-price-group">
// // //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// // //                   <div className="price-card mortgage-price">
// // //                     <div className="price-card-icon"><FaBuilding /></div>
// // //                     <div className="price-card-content">
// // //                       <span className="price-label">مبلغ رهن</span>
// // //                       <div className="price-value-wrapper">
// // //                         <span className="price-number">{property.mortgagePrice}</span>
// // //                         <span className="price-unit">تومان</span>
// // //                       </div>
// // //                     </div>
// // //                   </div>
// // //                 )}
// // //                 {property.rentPrice && property.rentPrice !== "۰" && (
// // //                   <div className="price-card rent-price">
// // //                     <div className="price-card-icon"><FaHome /></div>
// // //                     <div className="price-card-content">
// // //                       <span className="price-label">اجاره ماهانه</span>
// // //                       <div className="price-value-wrapper">
// // //                         <span className="price-number">{property.rentPrice}</span>
// // //                         <span className="price-unit">تومان</span>
// // //                       </div>
// // //                     </div>
// // //                   </div>
// // //                 )}
// // //               </div>
// // //             )}
// // //           </div>
          
// // //           <div className="quick-specs">
// // //             <div className="spec-item">
// // //               <FaRulerCombined />
// // //               <span className="spec-label">متراژ</span>
// // //               <span className="spec-value">{property.area} متر²</span>
// // //             </div>
// // //             <div className="spec-item">
// // //               <FaBath />
// // //               <span className="spec-label">اتاق‌خواب</span>
// // //               <span className="spec-value">{property.rooms} خواب</span>
// // //             </div>
// // //             <div className="spec-item">
// // //               <FaLayerGroup />
// // //               <span className="spec-label">طبقه</span>
// // //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// // //             </div>
// // //             <div className="spec-item">
// // //               <FaCalendarAlt />
// // //               <span className="spec-label">سال ساخت</span>
// // //               <span className="spec-value">{property.year}</span>
// // //             </div>
// // //           </div>
          
// // //           <div className="info-chips">
// // //             <span className="info-chip">کد ملک: {property.id}</span>
// // //             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
// // //             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
// // //           </div>
          
// // //           <div className="detail-tabs">
// // //             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
// // //             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
// // //             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
// // //             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
// // //           </div>
          
// // //           <div className="tab-content">
// // //             {activeTab === 'details' && (
// // //               <div className="details-tab">
// // //                 <div className="address-card">
// // //                   <FaMapMarkerAlt />
// // //                   <div className="address-info">
// // //                     <h3>آدرس ملک</h3>
// // //                     <div>منطقه {property.regionName}</div>
// // //                     <p>{property.address}</p>
// // //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// // //                   </div>
// // //                 </div>
// // //                 <div className="description-card">
// // //                   <h3>توضیحات کامل {property.title}</h3>
// // //                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
// // //                 </div>
// // //                 <div className="map-card">
// // //                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
// // //                   <div className="map-location-badge">
// // //                     {property.showExactLocation ? 
// // //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
// // //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
// // //                     }
// // //                   </div>
// // //                   <div className="map-container">
// // //                     <NeshanMap 
// // //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
// // //                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
// // //                       zoom={property.showExactLocation ? 17 : 15.9} 
// // //                       defaultType="dreamy" 
// // //                       poi={true} 
// // //                       traffic={false} 
// // //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
// // //                     />
// // //                     <div className="map-marker-overlay">
// // //                       {property.showExactLocation ? 
// // //                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
// // //                         <div className="location-circles"><div className="circle-3"></div></div>
// // //                       }
// // //                     </div>
// // //                   </div>
// // //                   <div className="map-privacy-note">
// // //                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
// // //                   </div>
// // //                 </div>
// // //               </div>
// // //             )}
            
// // //             {activeTab === 'features' && (
// // //               <div className="features-tab">
// // //                 <h3>امکانات و ویژگی‌ها</h3>
// // //                 <div className="features-grid">
// // //                   {property.features.length > 0 ? 
// // //                     property.features.map((feature, idx) => {
// // //                       let Icon = FaCheckCircle;
// // //                       if (feature.includes('پارکینگ')) Icon = FaParking;
// // //                       else if (feature.includes('انباری')) Icon = FaWarehouse;
// // //                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
// // //                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
// // //                       return (
// // //                         <div key={idx} className="feature-card">
// // //                           <Icon />
// // //                           <span>{feature}</span>
// // //                         </div>
// // //                       );
// // //                     }) : 
// // //                     <p className="no-data">امکاناتی ثبت نشده است</p>
// // //                   }
// // //                 </div>
// // //               </div>
// // //             )}
            
// // //             {activeTab === 'warnings' && (
// // //               <div className="warnings-tab">
// // //                 <h3>⚠️ هشدارهای مهم</h3>
// // //                 <ul className="warnings-list">
// // //                   {property.warnings.map((w, idx) => (
// // //                     <li key={idx} className="warning-item">
// // //                       <span className="warning-bullet"></span>
// // //                       <span>{w}</span>
// // //                     </li>
// // //                   ))}
// // //                 </ul>
// // //                 <div className="warning-footer">
// // //                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
// // //                 </div>
// // //               </div>
// // //             )}
            
// // //             {activeTab === 'nearby' && (
// // //               <div className="nearby-tab">
// // //                 <h3>امکانات اطراف</h3>
// // //                 <div className="nearby-list">
// // //                   {property.nearby.map((item, idx) => (
// // //                     <div key={idx} className="nearby-item">
// // //                       <span className="nearby-name">{item.name}</span>
// // //                       <span className="nearby-distance">{item.distance}</span>
// // //                     </div>
// // //                   ))}
// // //                 </div>
// // //               </div>
// // //             )}
// // //           </div>
          
// // //           {/* ========== کارت مشاور (مثل اینستاگرام) ========== */}
// // //           <div className="agent-card">
// // //             <div className="agent-header">
// // //               {/* آواتار با قابلیت کلیک برای پروفایل و رینگ استوری */}
// // //               <div 
// // //                 className={`agent-avatar-wrapper ${storyUserId ? 'has-story' : ''}`}
// // //                 style={{ 
// // //                   position: 'relative',
// // //                   display: 'inline-block',
// // //                   flexShrink: 0,
// // //                   cursor: 'pointer'
// // //                 }}
// // //                 onClick={goToProfile} // ✅ کلیک روی آواتار → پروفایل
// // //               >
// // //                 <SafeImage 
// // //                   src={property.agent.image} 
// // //                   alt={property.agent.name} 
// // //                   className={`agent-avatar ${storyUserId ? 'has-story' : ''}`}
// // //                   fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
// // //                 />
                
// // //                 {/* ✅ رینگ قرمز - فقط در صورتی که استوری داشته باشه */}
// // //                 {storyUserId && (
// // //                   <div 
// // //                     className="story-ring-indicator"
// // //                     onClick={handleStoryClick} // ✅ کلیک روی رینگ → استوری
// // //                   >
// // //                     <div className="story-ring-gradient"></div>
// // //                   </div>
// // //                 )}
// // //               </div>
              
// // //               <div className="agent-info">
// // //                 <div className="agent-name-wrapper">
// // //                   <h3 
// // //                     style={{ cursor: 'pointer' }}
// // //                     onClick={goToProfile} // ✅ کلیک روی اسم → پروفایل
// // //                   >
// // //                     {property.agent.name}
// // //                   </h3>
// // //                   {/* ✅ برچسب استوری - فقط در صورتی که استوری داشته باشه */}
// // //                   {storyUserId && (
// // //                     <span 
// // //                       className="story-label" 
// // //                       onClick={handleStoryClick} // ✅ کلیک روی برچسب → استوری
// // //                       style={{ cursor: 'pointer' }}
// // //                     >
// // //                       <span className="story-dot"></span>
// // //                       استوری
// // //                     </span>
// // //                   )}
// // //                 </div>
// // //                 <p>{property.agent.address}</p>
// // //                 <div className="agent-rating">
// // //                   <FaStar />
// // //                   <span>{property.agent.rating}</span>
// // //                   <span>({property.agent.deals} معامله)</span>
// // //                 </div>
// // //               </div>
// // //             </div>
            
// // //             <div className="agent-actions">
// // //               <button className="agent-action-btn phone" onClick={handleCopyPhone}>
// // //                 <FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}
// // //               </button>
// // //               <a 
// // //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// // //                 target="_blank" 
// // //                 rel="noopener noreferrer" 
// // //                 className="agent-action-btn whatsapp"
// // //               >
// // //                 <FaWhatsapp /> واتساپ
// // //               </a>
// // //             </div>
// // //           </div>
// // //         </div>
        
// // //         <DoubleSidebarBanners />
// // //         <RelatedPropertiesSlider 
// // //           currentPropertyId={property.id} 
// // //           regionName={property.regionName} 
// // //           propertyType={property.type} 
// // //         />
        
// // //         {copied && (
// // //           <div className="toast-notification">
// // //             <FaCheckCircle /> لینک کپی شد
// // //           </div>
// // //         )}
// // //       </div>
// // //     </> 
// // //   );
// // // });

// // // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // // export default RealEstateDetailPageItem;




// // import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// // import CryptoJS from 'crypto-js';
// // import DOMPurify from 'dompurify';
// // import { useNavigate, useLocation, useParams } from 'react-router-dom';
// // import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// // import DoubleSidebarBanners from './SidebarBanner';
// // import { 
// //   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
// //   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
// //   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
// //   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaLink
// // } from 'react-icons/fa';
// // import { Swiper, SwiperSlide } from 'swiper/react';
// // import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// // import NeshanMap from "@neshan-maps-platform/react-openlayers";
// // import "@neshan-maps-platform/react-openlayers/dist/style.css";
// // import 'swiper/css';
// // import 'swiper/css/navigation';
// // import 'swiper/css/pagination';
// // import './RealEstateDetailPageItem.css';

// // // ========== کامپوننت پاپ‌آپ استوری ==========
// // const StoryPopup = ({ agentName, agentImage, userId, onClose }) => {
// //   const [stories, setStories] = useState([]);
// //   const [loading, setLoading] = useState(true);
// //   const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
// //   const [progress, setProgress] = useState(0);
// //   const [isPaused, setIsPaused] = useState(false);
// //   const [error, setError] = useState(null);

// //   // دریافت استوری‌ها از API
// //   useEffect(() => {
// //     const fetchStories = async () => {
// //       if (!userId) {
// //         setError('شناسه کاربر یافت نشد');
// //         setLoading(false);
// //         return;
// //       }

// //       try {
// //         setLoading(true);
// //         console.log('📡 در حال دریافت استوری برای userId:', userId);
        
// //         const response = await fetch(`https://localhost:7178/api/Story/StoryForSiteForUser?userId=${userId}`);
        
// //         console.log('📡 Response status:', response.status);
        
// //         if (!response.ok) {
// //           throw new Error(`HTTP ${response.status}`);
// //         }
        
// //         const result = await response.json();
// //         console.log('📦 نتیجه استوری:', result);
        
// //         if (result.status === 200 && result.data && result.data.length > 0) {
// //           const userStories = result.data[0]?.storyUser || [];
// //           console.log('📸 تعداد استوری‌ها:', userStories.length);
          
// //           const formattedStories = userStories.map(story => ({
// //             ...story,
// //             url: `https://localhost:7178${story.url}`
// //           }));
// //           setStories(formattedStories);
// //         } else {
// //           console.log('⚠️ هیچ استوری پیدا نشد');
// //           setStories([]);
// //         }
// //       } catch (error) {
// //         console.error('❌ خطا در دریافت استوری:', error);
// //         setError('مشکل در دریافت استوری‌ها');
// //       } finally {
// //         setLoading(false);
// //       }
// //     };

// //     fetchStories();
// //   }, [userId]);

// //   // مدیریت پخش خودکار استوری‌ها
// //   useEffect(() => {
// //     if (isPaused || loading || stories.length === 0) return;

// //     const timer = setInterval(() => {
// //       setProgress(prev => {
// //         const newProgress = prev + 1;
// //         if (newProgress >= 100) {
// //           if (currentStoryIndex < stories.length - 1) {
// //             setCurrentStoryIndex(prev => prev + 1);
// //             return 0;
// //           } else {
// //             onClose();
// //             return 0;
// //           }
// //         }
// //         return newProgress;
// //       });
// //     }, 50);

// //     return () => clearInterval(timer);
// //   }, [currentStoryIndex, isPaused, loading, stories, onClose]);

// //   // هندلرهای ناوبری
// //   const handlePrevStory = useCallback((e) => {
// //     e.stopPropagation();
// //     if (currentStoryIndex > 0) {
// //       setCurrentStoryIndex(prev => prev - 1);
// //       setProgress(0);
// //     }
// //   }, [currentStoryIndex]);

// //   const handleNextStory = useCallback((e) => {
// //     e.stopPropagation();
// //     if (currentStoryIndex < stories.length - 1) {
// //       setCurrentStoryIndex(prev => prev + 1);
// //       setProgress(0);
// //     } else {
// //       onClose();
// //     }
// //   }, [currentStoryIndex, stories.length, onClose]);

// //   // کلیک روی لینک استوری
// //   const handleStoryLink = useCallback((link) => {
// //     if (link) {
// //       window.location.href = link;
// //     }
// //   }, []);

// //   if (loading) {
// //     return (
// //       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
// //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// //           <div style={{ 
// //             display: 'flex', 
// //             alignItems: 'center', 
// //             justifyContent: 'center', 
// //             height: '100%',
// //             color: 'white',
// //             fontSize: '18px',
// //             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// //           }}>
// //             در حال بارگذاری استوری‌ها...
// //           </div>
// //         </div>
// //       </div>
// //     );
// //   }

// //   if (error || stories.length === 0) {
// //     return (
// //       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
// //         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// //           <div style={{ 
// //             display: 'flex', 
// //             flexDirection: 'column',
// //             alignItems: 'center', 
// //             justifyContent: 'center', 
// //             height: '100%',
// //             color: 'white',
// //             fontSize: '16px',
// //             padding: '20px',
// //             textAlign: 'center',
// //             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// //           }}>
// //             <p>{error || 'هیچ استوری برای این کاربر وجود ندارد'}</p>
// //             <button 
// //               onClick={onClose}
// //               style={{
// //                 marginTop: '20px',
// //                 padding: '10px 30px',
// //                 background: '#ff0000',
// //                 color: 'white',
// //                 border: 'none',
// //                 borderRadius: '8px',
// //                 cursor: 'pointer',
// //                 fontSize: '14px',
// //                 fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
// //               }}
// //             >
// //               بستن
// //             </button>
// //           </div>
// //         </div>
// //       </div>
// //     );
// //   }

// //   const currentStory = stories[currentStoryIndex];

// //   return (
// //     <div 
// //       className="realestate-detail story-popup-overlay"
// //       onClick={onClose}
// //       onMouseEnter={() => setIsPaused(true)}
// //       onMouseLeave={() => setIsPaused(false)}
// //     >
// //       <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
// //         {/* نوارهای پیشرفت */}
// //         <div className="story-progress-container">
// //           {stories.map((_, index) => (
// //             <div 
// //               key={index} 
// //               className="story-progress-bar"
// //             >
// //               <div 
// //                 className="story-progress-fill"
// //                 style={{
// //                   width: index < currentStoryIndex ? '100%' : 
// //                          index === currentStoryIndex ? `${progress}%` : '0%'
// //                 }}
// //               />
// //             </div>
// //           ))}
// //         </div>

// //         {/* هدر */}
// //         <div className="story-header">
// //           <div className="story-user-info">
// //             <img 
// //               src={agentImage} 
// //               alt={agentName} 
// //               className="story-user-avatar"
// //             />
// //             <span className="story-user-name">{agentName}</span>
// //             <span className="story-time">لحظاتی پیش</span>
// //           </div>
// //           <button className="story-close-btn" onClick={onClose}>✕</button>
// //         </div>

// //         {/* محتوای استوری */}
// //         <div className="story-content">
// //           <img 
// //             src={currentStory.url} 
// //             alt={currentStory.caption || 'استوری'} 
// //             className="story-image"
// //           />
          
// //           {/* کپشن */}
// //           {currentStory.caption && (
// //             <div className="story-caption">
// //               {currentStory.caption}
// //             </div>
// //           )}

// //           {/* لینک استوری */}
// //           {currentStory.link && (
// //             <div 
// //               className="story-link-button"
// //               onClick={() => handleStoryLink(currentStory.link)}
// //             >
// //               <FaLink />
// //               <span>{currentStory.linkText || 'مشاهده بیشتر'}</span>
// //             </div>
// //           )}
// //         </div>

// //         {/* دکمه‌های ناوبری */}
// //         <div 
// //           className="story-nav-left"
// //           onClick={handlePrevStory}
// //         />
// //         <div 
// //           className="story-nav-right"
// //           onClick={handleNextStory}
// //         />
// //       </div>
// //     </div>
// //   );
// // };

// // // ========== کامپوننت SafeImage ==========
// // const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
// //   const [error, setError] = useState(false);

// //   if (!src || error) {
// //     return (
// //       <img 
// //         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
// //         alt={alt || 'تصویر'} 
// //         className={className}
// //         {...props}
// //       />
// //     );
// //   }

// //   return (
// //     <img
// //       src={src}
// //       alt={alt}
// //       className={className}
// //       onError={() => {
// //         setError(true);
// //       }}
// //       {...props}
// //     />
// //   );
// // };

// // // ========== توابع کمکی ==========
// // const stripHtml = (html) => {
// //   if (!html) return '';
// //   const temp = document.createElement('div');
// //   temp.innerHTML = html;
// //   return temp.textContent || temp.innerText || '';
// // };

// // const truncateText = (text, maxLength) => {
// //   if (!text) return '';
// //   if (text.length <= maxLength) return text;
// //   return text.substring(0, maxLength - 2) + '…';
// // };

// // // ========== کامپوننت‌های متا ==========
// // const PageMetadata = ({ property, isForSale, isForRent }) => {
// //   useEffect(() => {
// //     if (!property) return;
// //     let title = property.title 
// //       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
// //       : `ملک ${property.area} متری ${property.regionName}`;
// //     title = truncateText(title, 65);
// //     document.title = title;
// //     const plainDescription = stripHtml(property.description || '');
// //     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
// //     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
// //     description = truncateText(description, 155);
// //     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
// //     const updateOrCreateMeta = (name, content, isProperty = false) => {
// //       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
// //       let meta = document.querySelector(selector);
// //       if (!meta) {
// //         meta = document.createElement('meta');
// //         if (isProperty) meta.setAttribute('property', name);
// //         else meta.setAttribute('name', name);
// //         document.head.appendChild(meta);
// //       }
// //       meta.setAttribute('content', content);
// //     };
// //     updateOrCreateMeta('description', description);
// //     updateOrCreateMeta('keywords', keywords);
// //     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
// //     let canonical = document.querySelector('link[rel="canonical"]');
// //     if (!canonical) {
// //       canonical = document.createElement('link');
// //       canonical.rel = 'canonical';
// //       document.head.appendChild(canonical);
// //     }
// //     canonical.href = window.location.href;
// //     updateOrCreateMeta('og:title', title, true);
// //     updateOrCreateMeta('og:description', truncateText(description, 200), true);
// //     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
// //     updateOrCreateMeta('og:url', window.location.href, true);
// //     updateOrCreateMeta('og:type', 'product', true);
// //     updateOrCreateMeta('og:locale', 'fa_IR', true);
// //     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
// //     updateOrCreateMeta('twitter:card', 'summary_large_image');
// //     updateOrCreateMeta('twitter:title', title);
// //     updateOrCreateMeta('twitter:description', truncateText(description, 200));
// //     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
// //     document.documentElement.lang = 'fa';
// //     document.documentElement.dir = 'rtl';
// //   }, [property, isForSale, isForRent]);
// //   return null;
// // };

// // const StructuredData = ({ property, isForSale, isForRent }) => {
// //   useEffect(() => {
// //     if (!property) return;
// //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
// //     removeOldScript();
// //     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
// //     const structuredData = {
// //       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
// //       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
// //       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
// //       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
// //       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
// //       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
// //       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
// //       "numberOfRooms": property.rooms || 0,
// //       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
// //       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
// //     };
// //     const script = document.createElement('script');
// //     script.id = 'json-ld-structured-data';
// //     script.type = 'application/ld+json';
// //     script.textContent = JSON.stringify(structuredData);
// //     document.head.appendChild(script);
// //     return () => removeOldScript();
// //   }, [property, isForSale, isForRent]);
// //   return null;
// // };

// // const BreadcrumbStructuredData = ({ property, isForSale }) => {
// //   useEffect(() => {
// //     if (!property) return;
// //     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
// //     removeOldScript();
// //     const baseUrl = window.location.origin;
// //     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
// //     const breadcrumbData = {
// //       "@context": "https://schema.org", "@type": "BreadcrumbList",
// //       "itemListElement": [
// //         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
// //         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
// //         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
// //         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
// //       ]
// //     };
// //     const script = document.createElement('script');
// //     script.id = 'json-ld-breadcrumb';
// //     script.type = 'application/ld+json';
// //     script.textContent = JSON.stringify(breadcrumbData);
// //     document.head.appendChild(script);
// //     return () => removeOldScript();
// //   }, [property, isForSale]);
// //   return null;
// // };

// // // ========== Skeleton ==========
// // const DetailSkeleton = () => (
// //   <div className="detail-skeleton">
// //     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
// //     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
// //     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
// //   </div>
// // );

// // // ========== کامپوننت اصلی ==========
// // const RealEstateDetailPageItem = memo(() => {
// //   const location = useLocation();
// //   const navigate = useNavigate();
// //   const { id: paramId } = useParams();
// //   const queryParams = new URLSearchParams(location.search);
// //   const id = paramId || queryParams.get('id');
// //   const [property, setProperty] = useState(null);
// //   const [loading, setLoading] = useState(true);
// //   const [error, setError] = useState(null);
// //   const [copied, setCopied] = useState(false);
// //   const [selectedImage, setSelectedImage] = useState(0);
// //   const [activeTab, setActiveTab] = useState('details');
// //   const [isFavorite, setIsFavorite] = useState(false);
// //   const [imagesLoaded, setImagesLoaded] = useState({});
// //   const [showStoryPopup, setShowStoryPopup] = useState(false);
// //   const [storyUserId, setStoryUserId] = useState(null);

// //   useEffect(() => {
// //     const fetchPropertyData = async () => {
// //       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
// //       setLoading(true); setError(null);
// //       try {
// //         const controller = new AbortController();
// //         const timeoutId = setTimeout(() => controller.abort(), 10000);
// //         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
// //         clearTimeout(timeoutId);
// //         if (!response.ok) throw new Error(`HTTP ${response.status}`);
// //         const result = await response.json();
        
// //         console.log('📦 Full API response:', result);
        
// //         if (result.status === 200 && result.data) {
// //           const data = result.data;
          
// //           const agentImage = data.agents?.image 
// //             ? `https://localhost:7178/${data.agents.image}` 
// //             : "https://randomuser.me/api/portraits/men/32.jpg";
          
// //           const userId = data.agents?.userId || null;
// //           const hasStory = data.agents?.hasStory || false;
          
// //           console.log('👤 Agent UserId:', userId);
// //           console.log('📱 HasStory:', hasStory);
          
// //           // ✅ فقط اگر hasStory=true باشه، userId رو ست کن
// //           setStoryUserId(hasStory ? userId : null);
          
// //           setProperty({
// //             id: data.id, 
// //             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
// //             price: data.price?.toLocaleString("fa-IR") || "۰",
// //             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
// //             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
// //             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
// //             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
// //             type: data.categoryType, 
// //             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
// //             rooms: data.rooms || 0,
// //             floor: data.floor || 1, 
// //             regionName: data.regionName || "منطقه نامشخص", 
// //             totalFloors: data.countFloor || 1,
// //             year: data.constructionYear || "نامشخص", 
// //             address: data.address || "آدرس درج نشده", 
// //             showExactLocation: data.showExactLocation,
// //             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
// //             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
// //             features: data.facilities || [],
// //             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
// //             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
// //             agent: { 
// //               name: data.agents?.name || "مشاور املاک", 
// //               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
// //               whatsapp: data.agents?.connectSocialMedia || "", 
// //               address: data.agents?.address || "آدرس دفتر درج نشده", 
// //               rating: data.agents?.rating || 4.5, 
// //               deals: data.agents?.deals || 120, 
// //               image: agentImage,
// //               hasStory: hasStory, // ✅ ذخیره مقدار hasStory در agent
// //               userId: userId
// //             },
// //             views: data.views || 0, 
// //             saved: data.saved || 0, 
// //             createdAt: data.createdAtPersianRelative || "امروز", 
// //             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
// //             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
// //             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
// //           });
// //         } else throw new Error(result.message || 'ملک یافت نشد');
// //       } catch (error) { 
// //         console.error('خطا:', error); 
// //         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
// //       } finally { 
// //         setLoading(false); 
// //       }
// //     };
// //     fetchPropertyData();
// //     window.scrollTo({ top: 0, behavior: 'smooth' });
// //   }, [id]);

// //   const isForSale = useMemo(() => property?.type === 1, [property]);
// //   const isForRent = useMemo(() => property?.type === 2, [property]);
// //   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
// //   const shareUrl = useMemo(() => window.location.href, []);

// //   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
// //   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
// //   const handleCopyPhone = useCallback(() => { if (!property?.agent?.phone) return; navigator.clipboard.writeText(property.agent.phone); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [property]);
// //   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
// //   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
// //   // ✅ رفتن به پروفایل کاربر
// //   const goToProfile = useCallback(() => {
// //     if (property?.agent?.userId) {
// //       console.log('👤 رفتن به پروفایل کاربر:', property.agent.userId);
// //       navigate(`/profile/${property.agent.userId}`);
// //     }
// //   }, [property, navigate]);

// //   // ✅ باز کردن استوری
// //   const handleStoryClick = useCallback((e) => {
// //     if (e) {
// //       e.stopPropagation();
// //     }
    
// //     console.log('🖱️ کلیک روی استوری');
// //     console.log('🆔 storyUserId:', storyUserId);
// //     console.log('📱 hasStory:', property?.agent?.hasStory);
    
// //     // ✅ فقط اگر storyUserId وجود داشته باشه (یعنی hasStory=true)
// //     if (storyUserId) {
// //       console.log('✅ باز کردن استوری برای userId:', storyUserId);
// //       setShowStoryPopup(true);
// //       document.body.style.overflow = 'hidden';
// //     } else {
// //       console.log('❌ این کاربر استوری ندارد');
// //     }
// //   }, [storyUserId, property]);

// //   // ✅ بستن استوری
// //   const handleStoryClose = useCallback(() => {
// //     setShowStoryPopup(false);
// //     document.body.style.overflow = '';
// //   }, []);

// //   if (error) return ( 
// //     <> 
// //       <PageMetadata property={null} /> 
// //       <div className="detail-container realestate-detail">
// //         <div className="detail-header">
// //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// //           <h1 className="header-title">خطا</h1>
// //           <div className="header-btn"></div>
// //         </div>
// //         <div className="error-message">
// //           <h2>متاسفانه خطایی رخ داده است</h2>
// //           <p>{error}</p>
// //           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
// //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// //         </div>
// //       </div>
// //     </> 
// //   );
  
// //   if (loading) return <DetailSkeleton />;
  
// //   if (!property) return ( 
// //     <> 
// //       <PageMetadata property={null} /> 
// //       <div className="detail-container realestate-detail">
// //         <div className="detail-header">
// //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// //           <h1 className="header-title">ملک یافت نشد</h1>
// //           <div className="header-btn"></div>
// //         </div>
// //         <div className="error-message">
// //           <p>متاسفانه ملک مورد نظر یافت نشد</p>
// //           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
// //         </div>
// //       </div>
// //     </> 
// //   );

// //   return ( 
// //     <>
// //       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
// //       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
// //       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
// //       {/* ✅ پاپ‌آپ استوری */}
// //       {showStoryPopup && (
// //         <StoryPopup 
// //           agentName={property.agent.name}
// //           agentImage={property.agent.image}
// //           userId={storyUserId}
// //           onClose={handleStoryClose}
// //         />
// //       )}
      
// //       <div className="detail-container realestate-detail">
// //         <nav className="breadcrumb-nav">
// //           <ol className="breadcrumb-list">
// //             <li className="breadcrumb-item"><a href="/">خانه</a></li>
// //             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
// //             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
// //             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
// //           </ol>
// //         </nav>
        
// //         <div className="detail-header">
// //           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
// //           <h1 className="header-title">{property.title}</h1>
// //           <button className="header-btn" onClick={handleShare}><FaShare /></button>
// //         </div>
        
// //         <div className="detail-gallery">
// //           <Swiper 
// //             modules={[Navigation, Pagination, Autoplay]} 
// //             navigation 
// //             pagination={{ clickable: true }} 
// //             autoplay={{ delay: 4000, disableOnInteraction: false }} 
// //             spaceBetween={0} 
// //             slidesPerView={1} 
// //             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
// //             className="gallery-swiper"
// //           >
// //             {property.images.length > 0 ? 
// //               property.images.map((img, index) => (
// //                 <SwiperSlide key={index}>
// //                   <div className="gallery-slide">
// //                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
// //                     <img 
// //                       src={img} 
// //                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
// //                       loading={index === 0 ? 'eager' : 'lazy'} 
// //                       onLoad={() => handleImageLoad(index)} 
// //                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
// //                     />
// //                   </div>
// //                 </SwiperSlide>
// //               )) : 
// //               (<SwiperSlide>
// //                 <div className="gallery-slide no-image">
// //                   <FaHome />
// //                   <span>تصویری موجود نیست</span>
// //                 </div>
// //               </SwiperSlide>)
// //             }
// //           </Swiper>
// //           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
// //             {isFavorite ? <FaHeart /> : <FaRegHeart />}
// //           </button>
// //           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
// //         </div>
        
// //         <div className="detail-main">
// //           <div className="detail-title-section">
// //             <div className="title-row">
// //               <div className="property-stats">
// //                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
// //                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
// //                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
// //               </div>
// //             </div>
// //           </div>
          
// //           <div className="price-section">
// //             {isForSale && (
// //               <div className="price-card sale-price">
// //                 <div className="price-card-icon"><FaTag /></div>
// //                 <div className="price-card-content">
// //                   <span className="price-label">قیمت فروش</span>
// //                   <div className="price-value-wrapper">
// //                     <span className="price-number">{property.price}</span>
// //                     <span className="price-unit">تومان</span>
// //                   </div>
// //                   {formattedPricePerMeter && 
// //                     <div className="price-meta">
// //                       <FaRuler />
// //                       <span>متری {formattedPricePerMeter}</span>
// //                     </div>
// //                   }
// //                 </div>
// //               </div>
// //             )}
            
// //             {isForRent && (
// //               <div className="rent-price-group">
// //                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
// //                   <div className="price-card mortgage-price">
// //                     <div className="price-card-icon"><FaBuilding /></div>
// //                     <div className="price-card-content">
// //                       <span className="price-label">مبلغ رهن</span>
// //                       <div className="price-value-wrapper">
// //                         <span className="price-number">{property.mortgagePrice}</span>
// //                         <span className="price-unit">تومان</span>
// //                       </div>
// //                     </div>
// //                   </div>
// //                 )}
// //                 {property.rentPrice && property.rentPrice !== "۰" && (
// //                   <div className="price-card rent-price">
// //                     <div className="price-card-icon"><FaHome /></div>
// //                     <div className="price-card-content">
// //                       <span className="price-label">اجاره ماهانه</span>
// //                       <div className="price-value-wrapper">
// //                         <span className="price-number">{property.rentPrice}</span>
// //                         <span className="price-unit">تومان</span>
// //                       </div>
// //                     </div>
// //                   </div>
// //                 )}
// //               </div>
// //             )}
// //           </div>
          
// //           <div className="quick-specs">
// //             <div className="spec-item">
// //               <FaRulerCombined />
// //               <span className="spec-label">متراژ</span>
// //               <span className="spec-value">{property.area} متر²</span>
// //             </div>
// //             <div className="spec-item">
// //               <FaBath />
// //               <span className="spec-label">اتاق‌خواب</span>
// //               <span className="spec-value">{property.rooms} خواب</span>
// //             </div>
// //             <div className="spec-item">
// //               <FaLayerGroup />
// //               <span className="spec-label">طبقه</span>
// //               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
// //             </div>
// //             <div className="spec-item">
// //               <FaCalendarAlt />
// //               <span className="spec-label">سال ساخت</span>
// //               <span className="spec-value">{property.year}</span>
// //             </div>
// //           </div>
          
// //           <div className="info-chips">
// //             <span className="info-chip">کد ملک: {property.id}</span>
// //             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
// //             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
// //           </div>
          
// //           <div className="detail-tabs">
// //             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
// //             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
// //             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
// //             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
// //           </div>
          
// //           <div className="tab-content">
// //             {activeTab === 'details' && (
// //               <div className="details-tab">
// //                 <div className="address-card">
// //                   <FaMapMarkerAlt />
// //                   <div className="address-info">
// //                     <h3>آدرس ملک</h3>
// //                     <div>منطقه {property.regionName}</div>
// //                     <p>{property.address}</p>
// //                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
// //                   </div>
// //                 </div>
// //                 <div className="description-card">
// //                   <h3>توضیحات کامل {property.title}</h3>
// //                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
// //                 </div>
// //                 <div className="map-card">
// //                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
// //                   <div className="map-location-badge">
// //                     {property.showExactLocation ? 
// //                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
// //                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
// //                     }
// //                   </div>
// //                   <div className="map-container">
// //                     <NeshanMap 
// //                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
// //                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
// //                       zoom={property.showExactLocation ? 17 : 15.9} 
// //                       defaultType="dreamy" 
// //                       poi={true} 
// //                       traffic={false} 
// //                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
// //                     />
// //                     <div className="map-marker-overlay">
// //                       {property.showExactLocation ? 
// //                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
// //                         <div className="location-circles"><div className="circle-3"></div></div>
// //                       }
// //                     </div>
// //                   </div>
// //                   <div className="map-privacy-note">
// //                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
// //                   </div>
// //                 </div>
// //               </div>
// //             )}
            
// //             {activeTab === 'features' && (
// //               <div className="features-tab">
// //                 <h3>امکانات و ویژگی‌ها</h3>
// //                 <div className="features-grid">
// //                   {property.features.length > 0 ? 
// //                     property.features.map((feature, idx) => {
// //                       let Icon = FaCheckCircle;
// //                       if (feature.includes('پارکینگ')) Icon = FaParking;
// //                       else if (feature.includes('انباری')) Icon = FaWarehouse;
// //                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
// //                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
// //                       return (
// //                         <div key={idx} className="feature-card">
// //                           <Icon />
// //                           <span>{feature}</span>
// //                         </div>
// //                       );
// //                     }) : 
// //                     <p className="no-data">امکاناتی ثبت نشده است</p>
// //                   }
// //                 </div>
// //               </div>
// //             )}
            
// //             {activeTab === 'warnings' && (
// //               <div className="warnings-tab">
// //                 <h3>⚠️ هشدارهای مهم</h3>
// //                 <ul className="warnings-list">
// //                   {property.warnings.map((w, idx) => (
// //                     <li key={idx} className="warning-item">
// //                       <span className="warning-bullet"></span>
// //                       <span>{w}</span>
// //                     </li>
// //                   ))}
// //                 </ul>
// //                 <div className="warning-footer">
// //                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
// //                 </div>
// //               </div>
// //             )}
            
// //             {activeTab === 'nearby' && (
// //               <div className="nearby-tab">
// //                 <h3>امکانات اطراف</h3>
// //                 <div className="nearby-list">
// //                   {property.nearby.map((item, idx) => (
// //                     <div key={idx} className="nearby-item">
// //                       <span className="nearby-name">{item.name}</span>
// //                       <span className="nearby-distance">{item.distance}</span>
// //                     </div>
// //                   ))}
// //                 </div>
// //               </div>
// //             )}
// //           </div>
          
// //           {/* ========== کارت مشاور (مثل اینستاگرام) ========== */}
// //           <div className="agent-card">
// //             <div className="agent-header">
// //               {/* آواتار با قابلیت کلیک برای پروفایل و رینگ استوری */}
// //               <div 
// //                 className={`agent-avatar-wrapper ${property.agent.hasStory ? 'has-story' : ''}`}
// //                 style={{ 
// //                   position: 'relative',
// //                   display: 'inline-block',
// //                   flexShrink: 0,
// //                   cursor: property.agent.userId ? 'pointer' : 'default'
// //                 }}
// //                 onClick={property.agent.userId ? goToProfile : undefined}
// //               >
// //                 <SafeImage 
// //                   src={property.agent.image} 
// //                   alt={property.agent.name} 
// //                   className={`agent-avatar ${property.agent.hasStory ? 'has-story' : ''}`}
// //                   fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
// //                 />
                
// //                 {/* ✅ رینگ قرمز - فقط در صورتی که hasStory=true باشد */}
// //                 {property.agent.hasStory && (
// //                   <div 
// //                     className="story-ring-indicator"
// //                     onClick={(e) => {
// //                       e.stopPropagation();
// //                       handleStoryClick(e);
// //                     }}
// //                   >
// //                     <div className="story-ring-gradient"></div>
// //                   </div>
// //                 )}
// //               </div>
              
// //               <div className="agent-info">
// //                 <div className="agent-name-wrapper">
// //                   <h3 
// //                     style={{ cursor: property.agent.userId ? 'pointer' : 'default' }}
// //                     onClick={property.agent.userId ? goToProfile : undefined}
// //                   >
// //                     {property.agent.name}
// //                   </h3>
                  
// //                   {/* ✅ برچسب استوری - فقط در صورتی که hasStory=true باشد */}
// //                   {property.agent.hasStory && (
// //                     <span 
// //                       className="story-label" 
// //                       onClick={(e) => {
// //                         e.stopPropagation();
// //                         handleStoryClick(e);
// //                       }}
// //                       style={{ cursor: 'pointer' }}
// //                     >
// //                       <span className="story-dot"></span>
// //                       استوری
// //                     </span>
// //                   )}
// //                 </div>
// //                 <p>{property.agent.address}</p>
// //                 <div className="agent-rating">
// //                   <FaStar />
// //                   <span>{property.agent.rating}</span>
// //                   <span>({property.agent.deals} معامله)</span>
// //                 </div>
// //               </div>
// //             </div>
            
// //             <div className="agent-actions">
// //               <button className="agent-action-btn phone" onClick={handleCopyPhone}>
// //                 <FaPhone /> {copied ? 'کپی شد!' : 'کپی شماره'}
// //               </button>
// //               <a 
// //                 href={`https://wa.me/${property.agent.whatsapp}`} 
// //                 target="_blank" 
// //                 rel="noopener noreferrer" 
// //                 className="agent-action-btn whatsapp"
// //               >
// //                 <FaWhatsapp /> واتساپ
// //               </a>
// //             </div>
// //           </div>
// //         </div>
        
// //         <DoubleSidebarBanners />
// //         <RelatedPropertiesSlider 
// //           currentPropertyId={property.id} 
// //           regionName={property.regionName} 
// //           propertyType={property.type} 
// //         />
        
// //         {copied && (
// //           <div className="toast-notification">
// //             <FaCheckCircle /> لینک کپی شد
// //           </div>
// //         )}
// //       </div>
// //     </> 
// //   );
// // });

// // RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// // export default RealEstateDetailPageItem;









// import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
// import CryptoJS from 'crypto-js';
// import DOMPurify from 'dompurify';
// import { useNavigate, useLocation, useParams } from 'react-router-dom';
// import RelatedPropertiesSlider from './RelatedPropertiesSlider';
// import DoubleSidebarBanners from './SidebarBanner';
// import { 
//   FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
//   FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
//   FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
//   FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaLink,
//   FaLock, FaUser
// } from 'react-icons/fa';
// import { Swiper, SwiperSlide } from 'swiper/react';
// import { Navigation, Pagination, Autoplay } from 'swiper/modules';
// import NeshanMap from "@neshan-maps-platform/react-openlayers";
// import "@neshan-maps-platform/react-openlayers/dist/style.css";
// import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';
// import './RealEstateDetailPageItem.css';

// // ============================================================
// // ========== کامپوننت پاپ‌آپ استوری ==========
// // ============================================================
// const StoryPopup = ({ agentName, agentImage, userId, onClose }) => {
//   const [stories, setStories] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
//   const [progress, setProgress] = useState(0);
//   const [isPaused, setIsPaused] = useState(false);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchStories = async () => {
//       if (!userId) {
//         setError('شناسه کاربر یافت نشد');
//         setLoading(false);
//         return;
//       }

//       try {
//         setLoading(true);
//         console.log('📡 در حال دریافت استوری برای userId:', userId);
        
//         const response = await fetch(`https://localhost:7178/api/Story/StoryForSiteForUser?userId=${userId}`);
        
//         console.log('📡 Response status:', response.status);
        
//         if (!response.ok) {
//           throw new Error(`HTTP ${response.status}`);
//         }
        
//         const result = await response.json();
//         console.log('📦 نتیجه استوری:', result);
        
//         if (result.status === 200 && result.data && result.data.length > 0) {
//           const userStories = result.data[0]?.storyUser || [];
//           console.log('📸 تعداد استوری‌ها:', userStories.length);
          
//           const formattedStories = userStories.map(story => ({
//             ...story,
//             url: `https://localhost:7178${story.url}`
//           }));
//           setStories(formattedStories);
//         } else {
//           console.log('⚠️ هیچ استوری پیدا نشد');
//           setStories([]);
//         }
//       } catch (error) {
//         console.error('❌ خطا در دریافت استوری:', error);
//         setError('مشکل در دریافت استوری‌ها');
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchStories();
//   }, [userId]);

//   useEffect(() => {
//     if (isPaused || loading || stories.length === 0) return;

//     const timer = setInterval(() => {
//       setProgress(prev => {
//         const newProgress = prev + 1;
//         if (newProgress >= 100) {
//           if (currentStoryIndex < stories.length - 1) {
//             setCurrentStoryIndex(prev => prev + 1);
//             return 0;
//           } else {
//             onClose();
//             return 0;
//           }
//         }
//         return newProgress;
//       });
//     }, 50);

//     return () => clearInterval(timer);
//   }, [currentStoryIndex, isPaused, loading, stories, onClose]);

//   const handlePrevStory = useCallback((e) => {
//     e.stopPropagation();
//     if (currentStoryIndex > 0) {
//       setCurrentStoryIndex(prev => prev - 1);
//       setProgress(0);
//     }
//   }, [currentStoryIndex]);

//   const handleNextStory = useCallback((e) => {
//     e.stopPropagation();
//     if (currentStoryIndex < stories.length - 1) {
//       setCurrentStoryIndex(prev => prev + 1);
//       setProgress(0);
//     } else {
//       onClose();
//     }
//   }, [currentStoryIndex, stories.length, onClose]);

//   const handleStoryLink = useCallback((link) => {
//     if (link) {
//       window.location.href = link;
//     }
//   }, []);

//   if (loading) {
//     return (
//       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
//         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
//           <div style={{ 
//             display: 'flex', 
//             alignItems: 'center', 
//             justifyContent: 'center', 
//             height: '100%',
//             color: 'white',
//             fontSize: '18px',
//             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
//           }}>
//             در حال بارگذاری استوری‌ها...
//           </div>
//         </div>
//       </div>
//     );
//   }

//   if (error || stories.length === 0) {
//     return (
//       <div className="realestate-detail story-popup-overlay" onClick={onClose}>
//         <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
//           <div style={{ 
//             display: 'flex', 
//             flexDirection: 'column',
//             alignItems: 'center', 
//             justifyContent: 'center', 
//             height: '100%',
//             color: 'white',
//             fontSize: '16px',
//             padding: '20px',
//             textAlign: 'center',
//             fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
//           }}>
//             <p>{error || 'هیچ استوری برای این کاربر وجود ندارد'}</p>
//             <button 
//               onClick={onClose}
//               style={{
//                 marginTop: '20px',
//                 padding: '10px 30px',
//                 background: '#ff0000',
//                 color: 'white',
//                 border: 'none',
//                 borderRadius: '8px',
//                 cursor: 'pointer',
//                 fontSize: '14px',
//                 fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
//               }}
//             >
//               بستن
//             </button>
//           </div>
//         </div>
//       </div>
//     );
//   }

//   const currentStory = stories[currentStoryIndex];

//   return (
//     <div 
//       className="realestate-detail story-popup-overlay"
//       onClick={onClose}
//       onMouseEnter={() => setIsPaused(true)}
//       onMouseLeave={() => setIsPaused(false)}
//     >
//       <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
//         <div className="story-progress-container">
//           {stories.map((_, index) => (
//             <div 
//               key={index} 
//               className="story-progress-bar"
//             >
//               <div 
//                 className="story-progress-fill"
//                 style={{
//                   width: index < currentStoryIndex ? '100%' : 
//                          index === currentStoryIndex ? `${progress}%` : '0%'
//                 }}
//               />
//             </div>
//           ))}
//         </div>

//         <div className="story-header">
//           <div className="story-user-info">
//             <img 
//               src={agentImage} 
//               alt={agentName} 
//               className="story-user-avatar"
//             />
//             <span className="story-user-name">{agentName}</span>
//             <span className="story-time">لحظاتی پیش</span>
//           </div>
//           <button className="story-close-btn" onClick={onClose}>✕</button>
//         </div>

//         <div className="story-content">
//           <img 
//             src={currentStory.url} 
//             alt={currentStory.caption || 'استوری'} 
//             className="story-image"
//           />
          
//           {currentStory.caption && (
//             <div className="story-caption">
//               {currentStory.caption}
//             </div>
//           )}

//           {currentStory.link && (
//             <div 
//               className="story-link-button"
//               onClick={() => handleStoryLink(currentStory.link)}
//             >
//               <FaLink />
//               <span>{currentStory.linkText || 'مشاهده بیشتر'}</span>
//             </div>
//           )}
//         </div>

//         <div 
//           className="story-nav-left"
//           onClick={handlePrevStory}
//         />
//         <div 
//           className="story-nav-right"
//           onClick={handleNextStory}
//         />
//       </div>
//     </div>
//   );
// };

// // ============================================================
// // ========== کامپوننت SafeImage ==========
// // ============================================================
// const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
//   const [error, setError] = useState(false);

//   if (!src || error) {
//     return (
//       <img 
//         src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
//         alt={alt || 'تصویر'} 
//         className={className}
//         {...props}
//       />
//     );
//   }

//   return (
//     <img
//       src={src}
//       alt={alt}
//       className={className}
//       onError={() => {
//         setError(true);
//       }}
//       {...props}
//     />
//   );
// };

// // ============================================================
// // ========== توابع کمکی ==========
// // ============================================================
// const stripHtml = (html) => {
//   if (!html) return '';
//   const temp = document.createElement('div');
//   temp.innerHTML = html;
//   return temp.textContent || temp.innerText || '';
// };

// const truncateText = (text, maxLength) => {
//   if (!text) return '';
//   if (text.length <= maxLength) return text;
//   return text.substring(0, maxLength - 2) + '…';
// };

// // ============================================================
// // ========== کامپوننت‌های متا ==========
// // ============================================================
// const PageMetadata = ({ property, isForSale, isForRent }) => {
//   useEffect(() => {
//     if (!property) return;
//     let title = property.title 
//       ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
//       : `ملک ${property.area} متری ${property.regionName}`;
//     title = truncateText(title, 65);
//     document.title = title;
//     const plainDescription = stripHtml(property.description || '');
//     const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
//     let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
//     description = truncateText(description, 155);
//     const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
//     const updateOrCreateMeta = (name, content, isProperty = false) => {
//       const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
//       let meta = document.querySelector(selector);
//       if (!meta) {
//         meta = document.createElement('meta');
//         if (isProperty) meta.setAttribute('property', name);
//         else meta.setAttribute('name', name);
//         document.head.appendChild(meta);
//       }
//       meta.setAttribute('content', content);
//     };
//     updateOrCreateMeta('description', description);
//     updateOrCreateMeta('keywords', keywords);
//     updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
//     let canonical = document.querySelector('link[rel="canonical"]');
//     if (!canonical) {
//       canonical = document.createElement('link');
//       canonical.rel = 'canonical';
//       document.head.appendChild(canonical);
//     }
//     canonical.href = window.location.href;
//     updateOrCreateMeta('og:title', title, true);
//     updateOrCreateMeta('og:description', truncateText(description, 200), true);
//     updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
//     updateOrCreateMeta('og:url', window.location.href, true);
//     updateOrCreateMeta('og:type', 'product', true);
//     updateOrCreateMeta('og:locale', 'fa_IR', true);
//     updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
//     updateOrCreateMeta('twitter:card', 'summary_large_image');
//     updateOrCreateMeta('twitter:title', title);
//     updateOrCreateMeta('twitter:description', truncateText(description, 200));
//     updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
//     document.documentElement.lang = 'fa';
//     document.documentElement.dir = 'rtl';
//   }, [property, isForSale, isForRent]);
//   return null;
// };

// const StructuredData = ({ property, isForSale, isForRent }) => {
//   useEffect(() => {
//     if (!property) return;
//     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
//     removeOldScript();
//     const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
//     const structuredData = {
//       "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
//       "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
//       "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
//       ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
//       ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
//       "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
//       "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
//       "numberOfRooms": property.rooms || 0,
//       "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
//       "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
//     };
//     const script = document.createElement('script');
//     script.id = 'json-ld-structured-data';
//     script.type = 'application/ld+json';
//     script.textContent = JSON.stringify(structuredData);
//     document.head.appendChild(script);
//     return () => removeOldScript();
//   }, [property, isForSale, isForRent]);
//   return null;
// };

// const BreadcrumbStructuredData = ({ property, isForSale }) => {
//   useEffect(() => {
//     if (!property) return;
//     const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
//     removeOldScript();
//     const baseUrl = window.location.origin;
//     const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
//     const breadcrumbData = {
//       "@context": "https://schema.org", "@type": "BreadcrumbList",
//       "itemListElement": [
//         { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
//         { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
//         { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
//         { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
//       ]
//     };
//     const script = document.createElement('script');
//     script.id = 'json-ld-breadcrumb';
//     script.type = 'application/ld+json';
//     script.textContent = JSON.stringify(breadcrumbData);
//     document.head.appendChild(script);
//     return () => removeOldScript();
//   }, [property, isForSale]);
//   return null;
// };

// // ============================================================
// // ========== Skeleton ==========
// // ============================================================
// const DetailSkeleton = () => (
//   <div className="detail-skeleton">
//     <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
//     <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
//     <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
//   </div>
// );

// // ============================================================
// // ========== کامپوننت مودال لاگین ==========
// // ============================================================
// const LoginModal = ({ onClose, onLogin }) => {
//   const navigate = useNavigate();

//   const goToLogin = () => {
//     navigate('/login', { 
//       state: { 
//         from: window.location.pathname,
//         message: 'برای مشاهده شماره تماس مشاور وارد سامانه شوید'
//       } 
//     });
//   };

//   return (
//     <div className="login-modal-overlay" onClick={onClose}>
//       <div className="login-modal-content" onClick={(e) => e.stopPropagation()}>
//         <button className="modal-close-btn" onClick={onClose}>✕</button>
        
//         <div className="modal-icon">
//           <FaLock className="modal-lock-icon" />
//         </div>
        
//         <h2 className="modal-title">برای مشاهده شماره تماس</h2>
//         <p className="modal-description">
//           برای مشاهده شماره تماس مشاور و ارتباط مستقیم با او،
//           <br />
//           <strong>وارد سامانه شوید</strong>
//         </p>
        
//         <div className="modal-benefits">
//           <div className="benefit-item">
//             <span className="benefit-icon">📞</span>
//             <span>مشاهده شماره تماس</span>
//           </div>
//           <div className="benefit-item">
//             <span className="benefit-icon">💬</span>
//             <span>ارسال پیام مستقیم</span>
//           </div>
//           <div className="benefit-item">
//             <span className="benefit-icon">❤️</span>
//             <span>ذخیره در علاقه‌مندی‌ها</span>
//           </div>
//           <div className="benefit-item">
//             <span className="benefit-icon">📊</span>
//             <span>مشاهده تاریخچه بازدید</span>
//           </div>
//         </div>
        
//         <div className="modal-actions">
//           <button className="modal-login-btn" onClick={goToLogin}>
//             <FaUser /> ورود به سامانه
//           </button>
//           <button className="modal-guest-btn" onClick={onClose}>
//             بازگشت
//           </button>
//         </div>
        
//         <p className="modal-footer-text">
//           عضویت در سامانه رایگان است و کمتر از ۱ دقیقه زمان می‌برد
//         </p>
//       </div>
//     </div>
//   );
// };

// // ============================================================
// // ========== کامپوننت اصلی ==========
// // ============================================================
// const RealEstateDetailPageItem = memo(() => {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const { id: paramId } = useParams();
//   const queryParams = new URLSearchParams(location.search);
//   const id = paramId || queryParams.get('id');
  
//   const [property, setProperty] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [copied, setCopied] = useState(false);
//   const [selectedImage, setSelectedImage] = useState(0);
//   const [activeTab, setActiveTab] = useState('details');
//   const [isFavorite, setIsFavorite] = useState(false);
//   const [imagesLoaded, setImagesLoaded] = useState({});
//   const [showStoryPopup, setShowStoryPopup] = useState(false);
//   const [storyUserId, setStoryUserId] = useState(null);
  
//   // ===== STATE برای لاگین و مودال =====
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [showLoginModal, setShowLoginModal] = useState(false);

//   // ===== بررسی لاگین =====
//   useEffect(() => {
//     const token = localStorage.getItem('auth_token');
//     // const user = localStorage.getItem('user');
     
//     if (token ) {
//       setIsLoggedIn(true);
//     } else {
//       setIsLoggedIn(false);
//     }
//   }, []);

//   // ============================================================
//   // ===== دریافت اطلاعات ملک =====
//   // ============================================================
//   useEffect(() => {
//     const fetchPropertyData = async () => {
//       if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
//       setLoading(true); setError(null);
//       try {
//         const controller = new AbortController();
//         const timeoutId = setTimeout(() => controller.abort(), 10000);
//         const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
//         clearTimeout(timeoutId);
//         if (!response.ok) throw new Error(`HTTP ${response.status}`);
//         const result = await response.json();
        
//         console.log('📦 Full API response:', result);
        
//         if (result.status === 200 && result.data) {
//           const data = result.data;
          
//           const agentImage = data.agents?.image 
//             ? `https://localhost:7178/${data.agents.image}` 
//             : "https://randomuser.me/api/portraits/men/32.jpg";
          
//           const userId = data.agents?.userId || null;
//           const hasStory = data.agents?.hasStory || false;
          
//           console.log('👤 Agent UserId:', userId);
//           console.log('📱 HasStory:', hasStory);
          
//           setStoryUserId(hasStory ? userId : null);
          
//           setProperty({
//             id: data.id, 
//             title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
//             price: data.price?.toLocaleString("fa-IR") || "۰",
//             priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
//             rentPrice: data.rent?.toLocaleString("fa-IR") || null,
//             depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
//             mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
//             type: data.categoryType, 
//             area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
//             rooms: data.rooms || 0,
//             floor: data.floor || 1, 
//             regionName: data.regionName || "منطقه نامشخص", 
//             totalFloors: data.countFloor || 1,
//             year: data.constructionYear || "نامشخص", 
//             address: data.address || "آدرس درج نشده", 
//             showExactLocation: data.showExactLocation,
//             location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
//             description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
//             features: data.facilities || [],
//             warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
//             images: (data.images || []).map(img => `https://localhost:7178/${img}`),
//             agent: { 
//               name: data.agents?.name || "مشاور املاک", 
//               phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
//               whatsapp: data.agents?.connectSocialMedia || "", 
//               address: data.agents?.address || "آدرس دفتر درج نشده", 
//               rating: data.agents?.rating || 4.5, 
//               deals: data.agents?.deals || 120, 
//               image: agentImage,
//               hasStory: hasStory,
//               userId: userId
//             },
//             views: data.views || 0, 
//             saved: data.saved || 0, 
//             createdAt: data.createdAtPersianRelative || "امروز", 
//             certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
//             mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
//             nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
//           });
//         } else throw new Error(result.message || 'ملک یافت نشد');
//       } catch (error) { 
//         console.error('خطا:', error); 
//         setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
//       } finally { 
//         setLoading(false); 
//       }
//     };
//     fetchPropertyData();
//     window.scrollTo({ top: 0, behavior: 'smooth' });
//   }, [id]);

//   // ============================================================
//   // ===== توابع تماس با قفل لاگین =====
//   // ============================================================
//   const handlePhoneClick = useCallback(() => {
//     if (!isLoggedIn) {
//       setShowLoginModal(true);
//       return;
//     }
//     if (!property?.agent?.phone) {
//       alert('شماره تماس در دسترس نیست');
//       return;
//     }
//     navigator.clipboard.writeText(property.agent.phone);
//     setCopied(true);
//     setTimeout(() => setCopied(false), 2000);
//   }, [isLoggedIn, property]);

//   const handleWhatsAppClick = useCallback(() => {
//     if (!isLoggedIn) {
//       setShowLoginModal(true);
//       return;
//     }
//     if (!property?.agent?.whatsapp) {
//       alert('شماره واتساپ در دسترس نیست');
//       return;
//     }
//     window.open(`https://wa.me/${property.agent.whatsapp.replace(/\s/g, '')}`, '_blank');
//   }, [isLoggedIn, property]);

//   // ============================================================
//   // ===== سایر توابع =====
//   // ============================================================
//   const isForSale = useMemo(() => property?.type === 1, [property]);
//   const isForRent = useMemo(() => property?.type === 2, [property]);
//   const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
//   const shareUrl = useMemo(() => window.location.href, []);

//   const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
//   const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
//   const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
//   const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
//   const goToProfile = useCallback(() => {
//     if (property?.agent?.userId) {
//       console.log('👤 رفتن به پروفایل کاربر:', property.agent.userId);
//       navigate(`/profile/${property.agent.userId}`);
//     }
//   }, [property, navigate]);

//   const handleStoryClick = useCallback((e) => {
//     if (e) {
//       e.stopPropagation();
//     }
    
//     console.log('🖱️ کلیک روی استوری');
//     console.log('🆔 storyUserId:', storyUserId);
//     console.log('📱 hasStory:', property?.agent?.hasStory);
    
//     if (storyUserId) {
//       console.log('✅ باز کردن استوری برای userId:', storyUserId);
//       setShowStoryPopup(true);
//       document.body.style.overflow = 'hidden';
//     } else {
//       console.log('❌ این کاربر استوری ندارد');
//     }
//   }, [storyUserId, property]);

//   const handleStoryClose = useCallback(() => {
//     setShowStoryPopup(false);
//     document.body.style.overflow = '';
//   }, []);

//   const handleLoginModalClose = useCallback(() => {
//     setShowLoginModal(false);
//   }, []);

//   // ============================================================
//   // ===== رندر =====
//   // ============================================================
//   if (error) return ( 
//     <> 
//       <PageMetadata property={null} /> 
//       <div className="detail-container realestate-detail">
//         <div className="detail-header">
//           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
//           <h1 className="header-title">خطا</h1>
//           <div className="header-btn"></div>
//         </div>
//         <div className="error-message">
//           <h2>متاسفانه خطایی رخ داده است</h2>
//           <p>{error}</p>
//           <button onClick={() => window.location.reload()}>تلاش مجدد</button>
//           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
//         </div>
//       </div>
//     </> 
//   );
  
//   if (loading) return <DetailSkeleton />;
  
//   if (!property) return ( 
//     <> 
//       <PageMetadata property={null} /> 
//       <div className="detail-container realestate-detail">
//         <div className="detail-header">
//           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
//           <h1 className="header-title">ملک یافت نشد</h1>
//           <div className="header-btn"></div>
//         </div>
//         <div className="error-message">
//           <p>متاسفانه ملک مورد نظر یافت نشد</p>
//           <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
//         </div>
//       </div>
//     </> 
//   );

//   return ( 
//     <>
//       <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
//       <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
//       <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
//       {/* ===== پاپ‌آپ استوری ===== */}
//       {showStoryPopup && (
//         <StoryPopup 
//           agentName={property.agent.name}
//           agentImage={property.agent.image}
//           userId={storyUserId}
//           onClose={handleStoryClose}
//         />
//       )}

//       {/* ===== مودال لاگین ===== */}
//       {showLoginModal && (
//         <LoginModal 
//           onClose={handleLoginModalClose}
//         />
//       )}
      
//       <div className="detail-container realestate-detail">
//         <nav className="breadcrumb-nav">
//           <ol className="breadcrumb-list">
//             <li className="breadcrumb-item"><a href="/">خانه</a></li>
//             <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
//             <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
//             <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
//           </ol>
//         </nav>
        
//         <div className="detail-header">
//           <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
//           <h1 className="header-title">{property.title}</h1>
//           <button className="header-btn" onClick={handleShare}><FaShare /></button>
//         </div>
        
//         <div className="detail-gallery">
//           <Swiper 
//             modules={[Navigation, Pagination, Autoplay]} 
//             navigation 
//             pagination={{ clickable: true }} 
//             autoplay={{ delay: 4000, disableOnInteraction: false }} 
//             spaceBetween={0} 
//             slidesPerView={1} 
//             onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
//             className="gallery-swiper"
//           >
//             {property.images.length > 0 ? 
//               property.images.map((img, index) => (
//                 <SwiperSlide key={index}>
//                   <div className="gallery-slide">
//                     {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
//                     <img 
//                       src={img} 
//                       alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
//                       loading={index === 0 ? 'eager' : 'lazy'} 
//                       onLoad={() => handleImageLoad(index)} 
//                       style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
//                     />
//                   </div>
//                 </SwiperSlide>
//               )) : 
//               (<SwiperSlide>
//                 <div className="gallery-slide no-image">
//                   <FaHome />
//                   <span>تصویری موجود نیست</span>
//                 </div>
//               </SwiperSlide>)
//             }
//           </Swiper>
//           <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
//             {isFavorite ? <FaHeart /> : <FaRegHeart />}
//           </button>
//           <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
//         </div>
        
//         <div className="detail-main">
//           <div className="detail-title-section">
//             <div className="title-row">
//               <div className="property-stats">
//                 <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
//                 <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
//                 <span className="stat-badge"><FaClock /> {property.createdAt}</span>
//               </div>
//             </div>
//           </div>
          
//           <div className="price-section">
//             {isForSale && (
//               <div className="price-card sale-price">
//                 <div className="price-card-icon"><FaTag /></div>
//                 <div className="price-card-content">
//                   <span className="price-label">قیمت فروش</span>
//                   <div className="price-value-wrapper">
//                     <span className="price-number">{property.price}</span>
//                     <span className="price-unit">تومان</span>
//                   </div>
//                   {formattedPricePerMeter && 
//                     <div className="price-meta">
//                       <FaRuler />
//                       <span>متری {formattedPricePerMeter}</span>
//                     </div>
//                   }
//                 </div>
//               </div>
//             )}
            
//             {isForRent && (
//               <div className="rent-price-group">
//                 {property.mortgagePrice && property.mortgagePrice !== "۰" && (
//                   <div className="price-card mortgage-price">
//                     <div className="price-card-icon"><FaBuilding /></div>
//                     <div className="price-card-content">
//                       <span className="price-label">مبلغ رهن</span>
//                       <div className="price-value-wrapper">
//                         <span className="price-number">{property.mortgagePrice}</span>
//                         <span className="price-unit">تومان</span>
//                       </div>
//                     </div>
//                   </div>
//                 )}
//                 {property.rentPrice && property.rentPrice !== "۰" && (
//                   <div className="price-card rent-price">
//                     <div className="price-card-icon"><FaHome /></div>
//                     <div className="price-card-content">
//                       <span className="price-label">اجاره ماهانه</span>
//                       <div className="price-value-wrapper">
//                         <span className="price-number">{property.rentPrice}</span>
//                         <span className="price-unit">تومان</span>
//                       </div>
//                     </div>
//                   </div>
//                 )}
//               </div>
//             )}
//           </div>
          
//           <div className="quick-specs">
//             <div className="spec-item">
//               <FaRulerCombined />
//               <span className="spec-label">متراژ</span>
//               <span className="spec-value">{property.area} متر²</span>
//             </div>
//             <div className="spec-item">
//               <FaBath />
//               <span className="spec-label">اتاق‌خواب</span>
//               <span className="spec-value">{property.rooms} خواب</span>
//             </div>
//             <div className="spec-item">
//               <FaLayerGroup />
//               <span className="spec-label">طبقه</span>
//               <span className="spec-value">{property.floor} از {property.totalFloors}</span>
//             </div>
//             <div className="spec-item">
//               <FaCalendarAlt />
//               <span className="spec-label">سال ساخت</span>
//               <span className="spec-value">{property.year}</span>
//             </div>
//           </div>
          
//           <div className="info-chips">
//             <span className="info-chip">کد ملک: {property.id}</span>
//             <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
//             <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
//           </div>
          
//           <div className="detail-tabs">
//             <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
//             <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
//             <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
//             <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
//           </div>
          
//           <div className="tab-content">
//             {activeTab === 'details' && (
//               <div className="details-tab">
//                 <div className="address-card">
//                   <FaMapMarkerAlt />
//                   <div className="address-info">
//                     <h3>آدرس ملک</h3>
//                     <div>منطقه {property.regionName}</div>
//                     <p>{property.address}</p>
//                     <span className="post-date">تاریخ درج: {property.createdAt}</span>
//                   </div>
//                 </div>
//                 <div className="description-card">
//                   <h3>توضیحات کامل {property.title}</h3>
//                   <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
//                 </div>
//                 <div className="map-card">
//                   <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
//                   <div className="map-location-badge">
//                     {property.showExactLocation ? 
//                       <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
//                       <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
//                     }
//                   </div>
//                   <div className="map-container">
//                     <NeshanMap 
//                       mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
//                       center={{ latitude: property.location.lat, longitude: property.location.lng }} 
//                       zoom={property.showExactLocation ? 17 : 15.9} 
//                       defaultType="dreamy" 
//                       poi={true} 
//                       traffic={false} 
//                       style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
//                     />
//                     <div className="map-marker-overlay">
//                       {property.showExactLocation ? 
//                         <><div className="location-dot"></div><div className="location-ripple"></div></> : 
//                         <div className="location-circles"><div className="circle-3"></div></div>
//                       }
//                     </div>
//                   </div>
//                   <div className="map-privacy-note">
//                     <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
//                   </div>
//                 </div>
//               </div>
//             )}
            
//             {activeTab === 'features' && (
//               <div className="features-tab">
//                 <h3>امکانات و ویژگی‌ها</h3>
//                 <div className="features-grid">
//                   {property.features.length > 0 ? 
//                     property.features.map((feature, idx) => {
//                       let Icon = FaCheckCircle;
//                       if (feature.includes('پارکینگ')) Icon = FaParking;
//                       else if (feature.includes('انباری')) Icon = FaWarehouse;
//                       else if (feature.includes('آسانسور')) Icon = FaArrowUp;
//                       else if (feature.includes('استخر')) Icon = FaSwimmingPool;
//                       return (
//                         <div key={idx} className="feature-card">
//                           <Icon />
//                           <span>{feature}</span>
//                         </div>
//                       );
//                     }) : 
//                     <p className="no-data">امکاناتی ثبت نشده است</p>
//                   }
//                 </div>
//               </div>
//             )}
            
//             {activeTab === 'warnings' && (
//               <div className="warnings-tab">
//                 <h3>⚠️ هشدارهای مهم</h3>
//                 <ul className="warnings-list">
//                   {property.warnings.map((w, idx) => (
//                     <li key={idx} className="warning-item">
//                       <span className="warning-bullet"></span>
//                       <span>{w}</span>
//                     </li>
//                   ))}
//                 </ul>
//                 <div className="warning-footer">
//                   <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
//                 </div>
//               </div>
//             )}
            
//             {activeTab === 'nearby' && (
//               <div className="nearby-tab">
//                 <h3>امکانات اطراف</h3>
//                 <div className="nearby-list">
//                   {property.nearby.map((item, idx) => (
//                     <div key={idx} className="nearby-item">
//                       <span className="nearby-name">{item.name}</span>
//                       <span className="nearby-distance">{item.distance}</span>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             )}
//           </div>
          
//           {/* ============================================================ */}
//           {/* ========== کارت مشاور با دکمه‌های قفل شده ========== */}
//           {/* ============================================================ */}
//           <div className="agent-card">
//             <div className="agent-header">
//               {/* آواتار */}
//               <div 
//                 className={`agent-avatar-wrapper ${property.agent.hasStory ? 'has-story' : ''}`}
//                 style={{ 
//                   position: 'relative',
//                   display: 'inline-block',
//                   flexShrink: 0,
//                   cursor: property.agent.userId ? 'pointer' : 'default'
//                 }}
//                 onClick={property.agent.userId ? goToProfile : undefined}
//               >
//                 <SafeImage 
//                   src={property.agent.image} 
//                   alt={property.agent.name} 
//                   className={`agent-avatar ${property.agent.hasStory ? 'has-story' : ''}`}
//                   fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
//                 />
                
//                 {property.agent.hasStory && (
//                   <div 
//                     className="story-ring-indicator"
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleStoryClick(e);
//                     }}
//                   >
//                     <div className="story-ring-gradient"></div>
//                   </div>
//                 )}
//               </div>
              
//               <div className="agent-info">
//                 <div className="agent-name-wrapper">
//                   <h3 
//                     style={{ cursor: property.agent.userId ? 'pointer' : 'default' }}
//                     onClick={property.agent.userId ? goToProfile : undefined}
//                   >
//                     {property.agent.name}
//                   </h3>
                  
//                   {property.agent.hasStory && (
//                     <span 
//                       className="story-label" 
//                       onClick={(e) => {
//                         e.stopPropagation();
//                         handleStoryClick(e);
//                       }}
//                       style={{ cursor: 'pointer' }}
//                     >
//                       <span className="story-dot"></span>
//                       استوری
//                     </span>
//                   )}
//                 </div>
//                 <p>{property.agent.address}</p>
//                 <div className="agent-rating">
//                   <FaStar />
//                   <span>{property.agent.rating}</span>
//                   <span>({property.agent.deals} معامله)</span>
//                 </div>
//               </div>
//             </div>
            
//             {/* ============================================================ */}
//             {/* ===== دکمه‌های تماس با شرط لاگین ===== */}
//             {/* ============================================================ */}
//             <div className="agent-actions-wrapper">
              
//               {/* دکمه تماس تلفنی */}
//               <button 
//                 className={`agent-action-btn phone ${!isLoggedIn ? 'locked' : ''}`}
//                 onClick={handlePhoneClick}
//               >
//                 <FaPhone /> 
//                 <span className="btn-label">
//                   {isLoggedIn ? property.agent.phone : 'شماره تماس'}
//                 </span>
                
//                 {!isLoggedIn && (
//                   <>
//                     <span className="lock-badge">
//                       <FaLock className="lock-icon-small" />
//                     </span>
//                     <div className="lock-overlay">
//                       <FaLock className="lock-icon" />
//                       <span className="lock-text">برای مشاهده شماره</span>
//                       <span className="lock-subtext">وارد سامانه شوید</span>
//                     </div>
//                   </>
//                 )}
//               </button>

//               {/* دکمه واتساپ */}
//               <button 
//                 className={`agent-action-btn whatsapp ${!isLoggedIn ? 'locked' : ''}`}
//                 onClick={handleWhatsAppClick}
//               >
//                 <FaWhatsapp /> 
//                 <span className="btn-label">واتساپ</span>
                
//                 {!isLoggedIn && (
//                   <>
//                     <span className="lock-badge">
//                       <FaLock className="lock-icon-small" />
//                     </span>
//                     <div className="lock-overlay">
//                       <FaLock className="lock-icon" />
//                       <span className="lock-text">برای مشاهده شماره</span>
//                       <span className="lock-subtext">وارد سامانه شوید</span>
//                     </div>
//                   </>
//                 )}
//               </button>
//             </div>

//             {/* دکمه ورود - فقط برای کاربران غیرلاگین */}
//             {!isLoggedIn && (
//               <button 
//                 className="login-prompt-btn" 
//                 onClick={() => setShowLoginModal(true)}
//                 style={{ marginTop: '10px' }}
//               >
//                 <FaUser className="login-icon" />
//                 ورود / ثبت‌نام
//                 <FaArrowRight className="arrow-icon" />
//               </button>
//             )}
//             {/* ============================================================ */}
            
//           </div>
//         </div>
        
//         <DoubleSidebarBanners />
//         <RelatedPropertiesSlider 
//           currentPropertyId={property.id} 
//           regionName={property.regionName} 
//           propertyType={property.type} 
//         />
        
//         {copied && (
//           <div className="toast-notification">
//             <FaCheckCircle /> لینک کپی شد
//           </div>
//         )}
//       </div>
//     </> 
//   );
// });

// RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
// export default RealEstateDetailPageItem;


import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
import CryptoJS from 'crypto-js';
import DOMPurify from 'dompurify';
import { useNavigate, useLocation, useParams } from 'react-router-dom';
import RelatedPropertiesSlider from './RelatedPropertiesSlider';
import DoubleSidebarBanners from './SidebarBanner';
import { 
  FaMapMarkerAlt, FaPhone, FaWhatsapp, FaShare, FaArrowRight, FaHeart, FaRegHeart,
  FaStar, FaParking, FaWarehouse, FaSwimmingPool, FaBath, FaRulerCombined,
  FaCalendarAlt, FaLayerGroup, FaArrowUp, FaCheckCircle, FaTag, FaHome,
  FaBuilding, FaRuler, FaShieldAlt, FaClock, FaEye, FaBookmark, FaLink,
  FaLock, FaUser, FaSpinner
} from 'react-icons/fa';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import NeshanMap from "@neshan-maps-platform/react-openlayers";
import "@neshan-maps-platform/react-openlayers/dist/style.css";
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import './RealEstateDetailPageItem.css';

// ============================================================
// ========== کامپوننت پاپ‌آپ استوری ==========
// ============================================================
const StoryPopup = ({ agentName, agentImage, userId, onClose }) => {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStories = async () => {
      if (!userId) {
        setError('شناسه کاربر یافت نشد');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        console.log('📡 در حال دریافت استوری برای userId:', userId);
        
        const response = await fetch(`https://localhost:7178/api/Story/StoryForSiteForUser?userId=${userId}`);
        
        console.log('📡 Response status:', response.status);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const result = await response.json();
        console.log('📦 نتیجه استوری:', result);
        
        if (result.status === 200 && result.data && result.data.length > 0) {
          const userStories = result.data[0]?.storyUser || [];
          console.log('📸 تعداد استوری‌ها:', userStories.length);
          
          const formattedStories = userStories.map(story => ({
            ...story,
            url: `https://localhost:7178${story.url}`
          }));
          setStories(formattedStories);
        } else {
          console.log('⚠️ هیچ استوری پیدا نشد');
          setStories([]);
        }
      } catch (error) {
        console.error('❌ خطا در دریافت استوری:', error);
        setError('مشکل در دریافت استوری‌ها');
      } finally {
        setLoading(false);
      }
    };

    fetchStories();
  }, [userId]);

  useEffect(() => {
    if (isPaused || loading || stories.length === 0) return;

    const timer = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + 1;
        if (newProgress >= 100) {
          if (currentStoryIndex < stories.length - 1) {
            setCurrentStoryIndex(prev => prev + 1);
            return 0;
          } else {
            onClose();
            return 0;
          }
        }
        return newProgress;
      });
    }, 50);

    return () => clearInterval(timer);
  }, [currentStoryIndex, isPaused, loading, stories, onClose]);

  const handlePrevStory = useCallback((e) => {
    e.stopPropagation();
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(prev => prev - 1);
      setProgress(0);
    }
  }, [currentStoryIndex]);

  const handleNextStory = useCallback((e) => {
    e.stopPropagation();
    if (currentStoryIndex < stories.length - 1) {
      setCurrentStoryIndex(prev => prev + 1);
      setProgress(0);
    } else {
      onClose();
    }
  }, [currentStoryIndex, stories.length, onClose]);

  const handleStoryLink = useCallback((link) => {
    if (link) {
      window.location.href = link;
    }
  }, []);

  if (loading) {
    return (
      <div className="realestate-detail story-popup-overlay" onClick={onClose}>
        <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center', 
            height: '100%',
            color: 'white',
            fontSize: '18px',
            fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
          }}>
            در حال بارگذاری استوری‌ها...
          </div>
        </div>
      </div>
    );
  }

  if (error || stories.length === 0) {
    return (
      <div className="realestate-detail story-popup-overlay" onClick={onClose}>
        <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
          <div style={{ 
            display: 'flex', 
            flexDirection: 'column',
            alignItems: 'center', 
            justifyContent: 'center', 
            height: '100%',
            color: 'white',
            fontSize: '16px',
            padding: '20px',
            textAlign: 'center',
            fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
          }}>
            <p>{error || 'هیچ استوری برای این کاربر وجود ندارد'}</p>
            <button 
              onClick={onClose}
              style={{
                marginTop: '20px',
                padding: '10px 30px',
                background: '#ff0000',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '14px',
                fontFamily: 'IRANSans, Vazir, Tahoma, sans-serif'
              }}
            >
              بستن
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentStory = stories[currentStoryIndex];

  return (
    <div 
      className="realestate-detail story-popup-overlay"
      onClick={onClose}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="story-popup-content" onClick={(e) => e.stopPropagation()}>
        <div className="story-progress-container">
          {stories.map((_, index) => (
            <div 
              key={index} 
              className="story-progress-bar"
            >
              <div 
                className="story-progress-fill"
                style={{
                  width: index < currentStoryIndex ? '100%' : 
                         index === currentStoryIndex ? `${progress}%` : '0%'
                }}
              />
            </div>
          ))}
        </div>

        <div className="story-header">
          <div className="story-user-info">
            <img 
              src={agentImage} 
              alt={agentName} 
              className="story-user-avatar"
            />
            <span className="story-user-name">{agentName}</span>
            <span className="story-time">لحظاتی پیش</span>
          </div>
          <button className="story-close-btn" onClick={onClose}>✕</button>
        </div>

        <div className="story-content">
          <img 
            src={currentStory.url} 
            alt={currentStory.caption || 'استوری'} 
            className="story-image"
          />
          
          {currentStory.caption && (
            <div className="story-caption">
              {currentStory.caption}
            </div>
          )}

          {currentStory.link && (
            <div 
              className="story-link-button"
              onClick={() => handleStoryLink(currentStory.link)}
            >
              <FaLink />
              <span>{currentStory.linkText || 'مشاهده بیشتر'}</span>
            </div>
          )}
        </div>

        <div 
          className="story-nav-left"
          onClick={handlePrevStory}
        />
        <div 
          className="story-nav-right"
          onClick={handleNextStory}
        />
      </div>
    </div>
  );
};

// ============================================================
// ========== کامپوننت SafeImage ==========
// ============================================================
const SafeImage = ({ src, alt, className, fallbackSrc, ...props }) => {
  const [error, setError] = useState(false);

  if (!src || error) {
    return (
      <img 
        src={fallbackSrc || 'https://randomuser.me/api/portraits/men/32.jpg'} 
        alt={alt || 'تصویر'} 
        className={className}
        {...props}
      />
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      onError={() => {
        setError(true);
      }}
      {...props}
    />
  );
};

// ============================================================
// ========== توابع کمکی ==========
// ============================================================
const stripHtml = (html) => {
  if (!html) return '';
  const temp = document.createElement('div');
  temp.innerHTML = html;
  return temp.textContent || temp.innerText || '';
};

const truncateText = (text, maxLength) => {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength - 2) + '…';
};

// ============================================================
// ========== کامپوننت‌های متا ==========
// ============================================================
const PageMetadata = ({ property, isForSale, isForRent }) => {
  useEffect(() => {
    if (!property) return;
    let title = property.title 
      ? `${truncateText(property.title, 40)} | ${isForSale ? 'فروش' : 'رهن و اجاره'} ${property.area}م ${property.regionName}`
      : `ملک ${property.area} متری ${property.regionName}`;
    title = truncateText(title, 65);
    document.title = title;
    const plainDescription = stripHtml(property.description || '');
    const priceText = isForSale ? `قیمت: ${property.price} تومان` : `رهن: ${property.mortgagePrice || property.depositPrice || 'تماس بگیرید'} تومان`;
    let description = plainDescription ? truncateText(plainDescription, 120) + `... ${priceText}` : `ملک ${isForSale ? 'فروش' : 'رهن و اجاره'} در ${property.regionName}، ${property.area} متری، ${property.rooms} خوابه - ${priceText}`;
    description = truncateText(description, 155);
    const keywords = [property.title, `${property.regionName} ملک`, isForSale ? 'فروش آپارتمان' : 'رهن آپارتمان', `${property.area} متری`, `${property.rooms} خوابه`, `طبقه ${property.floor}`, property.year !== "نامشخص" ? `ساخت ${property.year}` : '', ...property.features.slice(0, 5)].filter(Boolean).join(',');
    const updateOrCreateMeta = (name, content, isProperty = false) => {
      const selector = isProperty ? `meta[property="${name}"]` : `meta[name="${name}"]`;
      let meta = document.querySelector(selector);
      if (!meta) {
        meta = document.createElement('meta');
        if (isProperty) meta.setAttribute('property', name);
        else meta.setAttribute('name', name);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    };
    updateOrCreateMeta('description', description);
    updateOrCreateMeta('keywords', keywords);
    updateOrCreateMeta('robots', 'index, follow, max-image-preview:large, max-snippet:-1');
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = window.location.href;
    updateOrCreateMeta('og:title', title, true);
    updateOrCreateMeta('og:description', truncateText(description, 200), true);
    updateOrCreateMeta('og:image', property.images?.[0] || '/default-property-image.jpg', true);
    updateOrCreateMeta('og:url', window.location.href, true);
    updateOrCreateMeta('og:type', 'product', true);
    updateOrCreateMeta('og:locale', 'fa_IR', true);
    updateOrCreateMeta('og:site_name', 'مشاور املاک', true);
    updateOrCreateMeta('twitter:card', 'summary_large_image');
    updateOrCreateMeta('twitter:title', title);
    updateOrCreateMeta('twitter:description', truncateText(description, 200));
    updateOrCreateMeta('twitter:image', property.images?.[0] || '/default-property-image.jpg');
    document.documentElement.lang = 'fa';
    document.documentElement.dir = 'rtl';
  }, [property, isForSale, isForRent]);
  return null;
};

const StructuredData = ({ property, isForSale, isForRent }) => {
  useEffect(() => {
    if (!property) return;
    const removeOldScript = () => { const oldScript = document.getElementById('json-ld-structured-data'); if (oldScript) oldScript.remove(); };
    removeOldScript();
    const parsePriceToNumber = (priceStr) => { if (!priceStr || priceStr === '۰') return '0'; return String(priceStr).replace(/[^0-9]/g, '') || '0'; };
    const structuredData = {
      "@context": "https://schema.org", "@type": isForSale ? "Product" : "RealEstateListing", "name": property.title,
      "description": stripHtml(property.description || '').substring(0, 500), "image": property.images.slice(0, 10), "url": window.location.href,
      "datePublished": new Date().toISOString(), "dateModified": new Date().toISOString(),
      ...(isForSale && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.price), "priceCurrency": "IRR", "availability": "https://schema.org/InStock", "priceValidUntil": new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] } }),
      ...(isForRent && { "offers": { "@type": "Offer", "price": parsePriceToNumber(property.mortgagePrice || property.rentPrice || '0'), "priceCurrency": "IRR", "description": "ملک رهن و اجاره" } }),
      "address": { "@type": "PostalAddress", "addressLocality": property.regionName, "streetAddress": property.address, "addressCountry": "IR", "addressRegion": "تهران" },
      "floorSize": { "@type": "QuantitativeValue", "value": property.area || 0, "unitCode": "MTK", "unitText": "متر مربع" },
      "numberOfRooms": property.rooms || 0,
      "additionalProperty": [{ "@type": "PropertyValue", "name": "طبقه", "value": `${property.floor || 1} از ${property.totalFloors || 1}` }, { "@type": "PropertyValue", "name": "سال ساخت", "value": property.year !== "نامشخص" ? property.year : "نامشخص" }, ...property.features.slice(0, 15).map(feature => ({ "@type": "PropertyValue", "name": "امکانات", "value": feature }))],
      "potentialAction": { "@type": "CommunicateAction", "name": "تماس با مشاور", "target": { "@type": "EntryPoint", "urlTemplate": `tel:${property.agent?.phone || ''}`, "inLanguage": "fa-IR", "actionPlatform": ["http://schema.org/DesktopWebPlatform", "http://schema.org/MobileWebPlatform"] } }
    };
    const script = document.createElement('script');
    script.id = 'json-ld-structured-data';
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(structuredData);
    document.head.appendChild(script);
    return () => removeOldScript();
  }, [property, isForSale, isForRent]);
  return null;
};

const BreadcrumbStructuredData = ({ property, isForSale }) => {
  useEffect(() => {
    if (!property) return;
    const removeOldScript = () => { const oldScript = document.getElementById('json-ld-breadcrumb'); if (oldScript) oldScript.remove(); };
    removeOldScript();
    const baseUrl = window.location.origin;
    const regionSlug = encodeURIComponent(property.regionName || 'منطقه');
    const breadcrumbData = {
      "@context": "https://schema.org", "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "صفحه اصلی", "item": `${baseUrl}/` },
        { "@type": "ListItem", "position": 2, "name": isForSale ? "آپارتمان‌های فروش" : "آپارتمان‌های رهن و اجاره", "item": `${baseUrl}/${isForSale ? 'RealEstatePageDetail' : 'rent'}` },
        { "@type": "ListItem", "position": 3, "name": `منطقه ${property.regionName}`, "item": `${baseUrl}/region/${regionSlug}` },
        { "@type": "ListItem", "position": 4, "name": truncateText(property.title || 'جزئیات ملک', 80), "item": window.location.href }
      ]
    };
    const script = document.createElement('script');
    script.id = 'json-ld-breadcrumb';
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(breadcrumbData);
    document.head.appendChild(script);
    return () => removeOldScript();
  }, [property, isForSale]);
  return null;
};

// ============================================================
// ========== Skeleton ==========
// ============================================================
const DetailSkeleton = () => (
  <div className="detail-skeleton">
    <div className="skeleton-header"><div className="skeleton-circle"></div><div className="skeleton-title"></div><div className="skeleton-circle"></div></div>
    <div className="skeleton-gallery"><div className="skeleton-image"></div></div>
    <div className="skeleton-content"><div className="skeleton-price"></div><div className="skeleton-info">{[]}</div><div className="skeleton-tabs">{[]}</div><div className="skeleton-text">{[]}</div></div>
  </div>
);

// ============================================================
// ========== کامپوننت مودال لاگین/ثبت‌نام پیشرفته ==========
// ============================================================
const LoginModal = ({ onClose }) => {
  const navigate = useNavigate();
  
  // ===== State‌ها =====
  const [step, setStep] = useState('phone'); // 'phone' | 'login' | 'register' | 'loading'
  const [phoneNumber, setPhoneNumber] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [userExists, setUserExists] = useState(null);

  // ===== تابع بررسی شماره موبایل =====
  const checkPhoneNumber = async () => {
    // اعتبارسنجی شماره
    if (!phoneNumber || phoneNumber.length < 10) {
      setError('لطفاً شماره موبایل معتبر وارد کنید');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      console.log('📡 بررسی شماره:', phoneNumber);
      
      // ===== درخواست به API برای بررسی وجود کاربر =====
      const response = await fetch(`https://localhost:7178/api/User/CheckUserByPhone?phone=${phoneNumber}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const result = await response.json();
      console.log('📦 نتیجه بررسی:', result);

      if (result.status === 200 && result.data === true) {
        // ✅ کاربر وجود دارد -> برو به مرحله لاگین
        setUserExists(true);
        setStep('login');
        setError('');
      } else {
        // ❌ کاربر وجود ندارد -> برو به مرحله ثبت‌نام
        setUserExists(false);
        setStep('register');
        setError('');
      }
    } catch (error) {
      console.error('❌ خطا در بررسی شماره:', error);
      setError('مشکل در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setLoading(false);
    }
  };

  // ===== تابع لاگین =====
  const handleLogin = async () => {
    if (!username || !password) {
      setError('لطفاً نام کاربری و رمز عبور را وارد کنید');
      return;
    }

    setLoading(true);
    setError('');

    try {
      console.log('📡 درخواست لاگین:', { username, phone: phoneNumber });

      const response = await fetch('https://localhost:7178/api/Auth/Login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          password: password,
          phone: phoneNumber
        }),
      });

      const result = await response.json();
      console.log('📦 نتیجه لاگین:', result);

      if (result.status === 200 && result.data) {
        // ✅ لاگین موفق
        localStorage.setItem('auth_token', result.data.token);
        localStorage.setItem('user', JSON.stringify(result.data.user));
        
        // ارسال رویداد برای به‌روزرسانی وضعیت
        window.dispatchEvent(new Event('authChange'));
        
        onClose();
        // رفرش صفحه برای اعمال تغییرات
        window.location.reload();
      } else {
        setError(result.message || 'نام کاربری یا رمز عبور اشتباه است');
      }
    } catch (error) {
      console.error('❌ خطا در لاگین:', error);
      setError('مشکل در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setLoading(false);
    }
  };

  // ===== تابع ثبت‌نام =====
  const handleRegister = async () => {
    // اعتبارسنجی
    if (!username || username.length < 3) {
      setError('نام کاربری باید حداقل ۳ کاراکتر باشد');
      return;
    }
    if (!password || password.length < 6) {
      setError('رمز عبور باید حداقل ۶ کاراکتر باشد');
      return;
    }
    if (password !== confirmPassword) {
      setError('رمز عبور و تکرار آن مطابقت ندارند');
      return;
    }

    setLoading(true);
    setError('');

    try {
      console.log('📡 درخواست ثبت‌نام:', { username, phone: phoneNumber });

      const response = await fetch('https://localhost:7178/api/Auth/Register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: username,
          password: password,
          phone: phoneNumber,
          name: username
        }),
      });

      const result = await response.json();
      console.log('📦 نتیجه ثبت‌نام:', result);

      if (result.status === 200 || result.status === 201) {
        // ✅ ثبت‌نام موفق
        // لاگین خودکار
        const loginResponse = await fetch('https://localhost:7178/api/Auth/Login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username: username,
            password: password,
            phone: phoneNumber
          }),
        });

        const loginResult = await loginResponse.json();

        if (loginResult.status === 200 && loginResult.data) {
          localStorage.setItem('auth_token', loginResult.data.token);
          localStorage.setItem('user', JSON.stringify(loginResult.data.user));
          
          window.dispatchEvent(new Event('authChange'));
          onClose();
          window.location.reload();
        } else {
          // ثبت‌نام موفق اما لاگین خودکار نشد
          setError('ثبت‌نام موفق بود. لطفاً وارد شوید.');
          setStep('login');
        }
      } else {
        setError(result.message || 'خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.');
      }
    } catch (error) {
      console.error('❌ خطا در ثبت‌نام:', error);
      setError('مشکل در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setLoading(false);
    }
  };

  // ===== بازگشت به مرحله قبل =====
  const handleBack = () => {
    setStep('phone');
    setError('');
    setUserExists(null);
  };

  // ===== رفتن به صفحه ثبت‌نام اصلی =====
  const goToRegisterPage = () => {
    onClose();
    navigate('/register', { 
      state: { 
        from: window.location.pathname,
        phone: phoneNumber
      } 
    });
  };

  // ============================================================
  // ===== رندر مرحله شماره موبایل =====
  // ============================================================
  const renderPhoneStep = () => (
    <>
      <div className="modal-icon">
        <FaPhone className="modal-phone-icon" />
      </div>
      
      <h2 className="modal-title">ورود / ثبت‌نام</h2>
      <p className="modal-description">
        برای مشاهده شماره تماس مشاور،
        <br />
        لطفاً شماره موبایل خود را وارد کنید
      </p>

      <div className="phone-input-wrapper">
        <div className="phone-prefix">+98</div>
        <input
          type="tel"
          className="phone-input"
          placeholder="۹۱۲۳۴۵۶۷۸۹"
          value={phoneNumber}
          onChange={(e) => {
            const value = e.target.value.replace(/\D/g, '');
            if (value.length <= 10) {
              setPhoneNumber(value);
            }
          }}
          maxLength="10"
          autoFocus
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              checkPhoneNumber();
            }
          }}
        />
      </div>

      {error && <div className="error-message-text">{error}</div>}

      <button 
        className="modal-submit-btn"
        onClick={checkPhoneNumber}
        disabled={loading || phoneNumber.length < 10}
      >
        {loading ? (
          <>
            <FaSpinner className="spinner" />
            در حال بررسی...
          </>
        ) : (
          <>
            ادامه
            <FaArrowRight />
          </>
        )}
      </button>

      <p className="modal-footer-text">
        با ادامه، شما با <a href="/terms">قوانین</a> موافقت می‌کنید
      </p>
    </>
  );

  // ============================================================
  // ===== رندر مرحله لاگین =====
  // ============================================================
  const renderLoginStep = () => (
    <>
      <button className="modal-back-btn" onClick={handleBack}>
        ← بازگشت
      </button>

      <div className="modal-icon">
        <FaUser className="modal-login-icon" />
      </div>
      
      <h2 className="modal-title">خوش آمدید</h2>
      <p className="modal-description">
        شماره <strong>{phoneNumber}</strong> در سامانه ثبت شده است
        <br />
        لطفاً وارد شوید
      </p>

      <div className="input-group">
        <div className="input-wrapper">
          <FaUser className="input-icon" />
          <input
            type="text"
            className="modal-input"
            placeholder="نام کاربری"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleLogin();
              }
            }}
          />
        </div>

        <div className="input-wrapper">
          <FaLock className="input-icon" />
          <input
            type="password"
            className="modal-input"
            placeholder="رمز عبور"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleLogin();
              }
            }}
          />
        </div>
      </div>

      {error && <div className="error-message-text">{error}</div>}

      <button 
        className="modal-submit-btn"
        onClick={handleLogin}
        disabled={loading || !username || !password}
      >
        {loading ? (
          <>
            <FaSpinner className="spinner" />
            در حال ورود...
          </>
        ) : (
          <>
            ورود
            <FaArrowRight />
          </>
        )}
      </button>

      <button className="modal-guest-btn" onClick={onClose}>
        ادامه به عنوان مهمان
      </button>
    </>
  );

  // ============================================================
  // ===== رندر مرحله ثبت‌نام =====
  // ============================================================
  const renderRegisterStep = () => (
    <>
      <button className="modal-back-btn" onClick={handleBack}>
        ← بازگشت
      </button>

      <div className="modal-icon">
        <FaUser className="modal-register-icon" />
      </div>
      
      <h2 className="modal-title">ثبت‌نام</h2>
      <p className="modal-description">
        شماره <strong>{phoneNumber}</strong> در سامانه ثبت نشده است
        <br />
        لطفاً ثبت‌نام کنید
      </p>

      <div className="input-group">
        <div className="input-wrapper">
          <FaUser className="input-icon" />
          <input
            type="text"
            className="modal-input"
            placeholder="نام کاربری (حداقل ۳ کاراکتر)"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleRegister();
              }
            }}
          />
        </div>

        <div className="input-wrapper">
          <FaLock className="input-icon" />
          <input
            type="password"
            className="modal-input"
            placeholder="رمز عبور (حداقل ۶ کاراکتر)"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleRegister();
              }
            }}
          />
        </div>

        <div className="input-wrapper">
          <FaCheckCircle className="input-icon" />
          <input
            type="password"
            className="modal-input"
            placeholder="تکرار رمز عبور"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleRegister();
              }
            }}
          />
        </div>
      </div>

      {error && <div className="error-message-text">{error}</div>}

      <button 
        className="modal-submit-btn"
        onClick={handleRegister}
        disabled={loading || !username || !password || !confirmPassword}
      >
        {loading ? (
          <>
            <FaSpinner className="spinner" />
            در حال ثبت‌نام...
          </>
        ) : (
          <>
            ثبت‌نام
            <FaArrowRight />
          </>
        )}
      </button>

      <button 
        className="modal-guest-btn" 
        onClick={goToRegisterPage}
      >
        ثبت‌نام کامل در صفحه جداگانه
      </button>
    </>
  );

  // ============================================================
  // ===== رندر اصلی =====
  // ============================================================
  return (
    <div className="login-modal-overlay" onClick={onClose}>
      <div className="login-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close-btn" onClick={onClose}>✕</button>
        
        {step === 'phone' && renderPhoneStep()}
        {step === 'login' && renderLoginStep()}
        {step === 'register' && renderRegisterStep()}
        
        <div className="modal-benefits-mini">
          <span>✅ ثبت‌نام رایگان</span>
          <span>🔒 امن و مطمئن</span>
          <span>⚡ کمتر از ۱ دقیقه</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================
// ========== کامپوننت اصلی ==========
// ============================================================
const RealEstateDetailPageItem = memo(() => {
  const location = useLocation();
  const navigate = useNavigate();
  const { id: paramId } = useParams();
  const queryParams = new URLSearchParams(location.search);
  const id = paramId || queryParams.get('id');
  
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  const [activeTab, setActiveTab] = useState('details');
  const [isFavorite, setIsFavorite] = useState(false);
  const [imagesLoaded, setImagesLoaded] = useState({});
  const [showStoryPopup, setShowStoryPopup] = useState(false);
  const [storyUserId, setStoryUserId] = useState(null);
  
  // ===== STATE برای لاگین و مودال =====
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);

  // ===== بررسی لاگین =====
  useEffect(() => {
    const checkLogin = () => {
      const token = localStorage.getItem('auth_token');
      if (token) {
        setIsLoggedIn(true);
      } else {
        setIsLoggedIn(false);
      }
    };
    
    checkLogin();
    
    // گوش دادن به تغییرات
    window.addEventListener('authChange', checkLogin);
    window.addEventListener('storage', checkLogin);
    
    return () => {
      window.removeEventListener('authChange', checkLogin);
      window.removeEventListener('storage', checkLogin);
    };
  }, []);

  // ============================================================
  // ===== دریافت اطلاعات ملک =====
  // ============================================================
  useEffect(() => {
    const fetchPropertyData = async () => {
      if (!id) { setError('شناسه ملک یافت نشد'); setLoading(false); return; }
      setLoading(true); setError(null);
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);
        const response = await fetch(`https://localhost:7178/api/RealEstatePage/GetRealEstateDetails?id=${id}`, { signal: controller.signal });
        clearTimeout(timeoutId);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();
        
        console.log('📦 Full API response:', result);
        
        if (result.status === 200 && result.data) {
          const data = result.data;
          
          const agentImage = data.agents?.image 
            ? `https://localhost:7178/${data.agents.image}` 
            : "https://randomuser.me/api/portraits/men/32.jpg";
          
          const userId = data.agents?.userId || null;
          const hasStory = data.agents?.hasStory || false;
          
          console.log('👤 Agent UserId:', userId);
          console.log('📱 HasStory:', hasStory);
          
          setStoryUserId(hasStory ? userId : null);
          
          setProperty({
            id: data.id, 
            title: data.title || `ملک در ${data.regionName || 'منطقه'} `, 
            price: data.price?.toLocaleString("fa-IR") || "۰",
            priceMeter: data.priceMeter?.toLocaleString("fa-IR") || "۰", 
            rentPrice: data.rent?.toLocaleString("fa-IR") || null,
            depositPrice: data.deposit?.toLocaleString("fa-IR") || null, 
            mortgagePrice: data.mortgagePrice?.toLocaleString("fa-IR") || null,
            type: data.categoryType, 
            area: parseInt(data.additionalInformation?.match(/\d+/)?.[0]) || 0, 
            rooms: data.rooms || 0,
            floor: data.floor || 1, 
            regionName: data.regionName || "منطقه نامشخص", 
            totalFloors: data.countFloor || 1,
            year: data.constructionYear || "نامشخص", 
            address: data.address || "آدرس درج نشده", 
            showExactLocation: data.showExactLocation,
            location: { lat: data.lat || 35.7199363, lng: data.lng || 51.4334842 },
            description: data.descriptionRows || "توضیحاتی برای این ملک ثبت نشده است.", 
            features: data.facilities || [],
            warnings: data.warnings || ["استعلام خلافی", "بررسی سند مالکیت", "استعلام پایان کار", "بررسی مفاصا حساب"],
            images: (data.images || []).map(img => `https://localhost:7178/${img}`),
            agent: { 
              name: data.agents?.name || "مشاور املاک", 
              phone: data.agents?.phone || "۰۲۱۹۱۰۰۰۰۰۰", 
              whatsapp: data.agents?.connectSocialMedia || "", 
              address: data.agents?.address || "آدرس دفتر درج نشده", 
              rating: data.agents?.rating || 4.5, 
              deals: data.agents?.deals || 120, 
              image: agentImage,
              hasStory: hasStory,
              userId: userId
            },
            views: data.views || 0, 
            saved: data.saved || 0, 
            createdAt: data.createdAtPersianRelative || "امروز", 
            certificate: data.isHasLoan ? "قابل وام" : "سند رسمی", 
            mortgage: data.isHasLoan ? "امکان وام" : "بدون وام",
            nearby: [{ name: "مترو", distance: "۵۰۰ متر" }, { name: "مرکز خرید", distance: "۳۰۰ متر" }, { name: "پارک", distance: "۲۰۰ متر" }, { name: "مدرسه", distance: "۴۰۰ متر" }]
          });
        } else throw new Error(result.message || 'ملک یافت نشد');
      } catch (error) { 
        console.error('خطا:', error); 
        setError(error.name === 'AbortError' ? 'مدت زمان درخواست به پایان رسید' : 'مشکل در ارتباط با سرور'); 
      } finally { 
        setLoading(false); 
      }
    };
    fetchPropertyData();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id]);

  // ============================================================
  // ===== توابع تماس با قفل لاگین =====
  // ============================================================
  const handlePhoneClick = useCallback(() => {
    if (!isLoggedIn) {
      setShowLoginModal(true);
      return;
    }
    if (!property?.agent?.phone) {
      alert('شماره تماس در دسترس نیست');
      return;
    }
    navigator.clipboard.writeText(property.agent.phone);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [isLoggedIn, property]);

  const handleWhatsAppClick = useCallback(() => {
    if (!isLoggedIn) {
      setShowLoginModal(true);
      return;
    }
    if (!property?.agent?.whatsapp) {
      alert('شماره واتساپ در دسترس نیست');
      return;
    }
    window.open(`https://wa.me/${property.agent.whatsapp.replace(/\s/g, '')}`, '_blank');
  }, [isLoggedIn, property]);

  // ============================================================
  // ===== سایر توابع =====
  // ============================================================
  const isForSale = useMemo(() => property?.type === 1, [property]);
  const isForRent = useMemo(() => property?.type === 2, [property]);
  const formattedPricePerMeter = useMemo(() => { if (!property?.priceMeter || property.priceMeter === "۰") return null; return `${property.priceMeter} تومان`; }, [property]);
  const shareUrl = useMemo(() => window.location.href, []);

  const handleCopyLink = useCallback(() => { navigator.clipboard.writeText(shareUrl); setCopied(true); setTimeout(() => setCopied(false), 2000); }, [shareUrl]);
  const handleShare = useCallback(async () => { if (!property) return; const shareData = { title: property.title, text: `${property.title} - ${property.area} متری - ${isForSale ? `قیمت ${property.price}` : `رهن ${property.mortgagePrice}`} تومان`, url: shareUrl }; if (navigator.share && /Mobile|Android|iPhone|iPad/i.test(navigator.userAgent)) { try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') handleCopyLink(); } } else handleCopyLink(); }, [property, isForSale, shareUrl, handleCopyLink]);
  const handleImageLoad = useCallback((index) => { setImagesLoaded(prev => ({ ...prev, [index]: true })); }, []);
  const handleFavoriteToggle = useCallback(() => { setIsFavorite(prev => !prev); }, []);
  
  const goToProfile = useCallback(() => {
    if (property?.agent?.userId) {
      console.log('👤 رفتن به پروفایل کاربر:', property.agent.userId);
      navigate(`/profile/${property.agent.userId}`);
    }
  }, [property, navigate]);

  const handleStoryClick = useCallback((e) => {
    if (e) {
      e.stopPropagation();
    }
    
    console.log('🖱️ کلیک روی استوری');
    console.log('🆔 storyUserId:', storyUserId);
    console.log('📱 hasStory:', property?.agent?.hasStory);
    
    if (storyUserId) {
      console.log('✅ باز کردن استوری برای userId:', storyUserId);
      setShowStoryPopup(true);
      document.body.style.overflow = 'hidden';
    } else {
      console.log('❌ این کاربر استوری ندارد');
    }
  }, [storyUserId, property]);

  const handleStoryClose = useCallback(() => {
    setShowStoryPopup(false);
    document.body.style.overflow = '';
  }, []);

  const handleLoginModalClose = useCallback(() => {
    setShowLoginModal(false);
    // بعد از بستن مودال، دوباره وضعیت لاگین رو بررسی کن
    const token = localStorage.getItem('auth_token');
    if (token) {
      setIsLoggedIn(true);
    }
  }, []);

  // ============================================================
  // ===== رندر =====
  // ============================================================
  if (error) return ( 
    <> 
      <PageMetadata property={null} /> 
      <div className="detail-container realestate-detail">
        <div className="detail-header">
          <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
          <h1 className="header-title">خطا</h1>
          <div className="header-btn"></div>
        </div>
        <div className="error-message">
          <h2>متاسفانه خطایی رخ داده است</h2>
          <p>{error}</p>
          <button onClick={() => window.location.reload()}>تلاش مجدد</button>
          <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
        </div>
      </div>
    </> 
  );
  
  if (loading) return <DetailSkeleton />;
  
  if (!property) return ( 
    <> 
      <PageMetadata property={null} /> 
      <div className="detail-container realestate-detail">
        <div className="detail-header">
          <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
          <h1 className="header-title">ملک یافت نشد</h1>
          <div className="header-btn"></div>
        </div>
        <div className="error-message">
          <p>متاسفانه ملک مورد نظر یافت نشد</p>
          <button onClick={() => navigate('/')}>بازگشت به صفحه اصلی</button>
        </div>
      </div>
    </> 
  );

  return ( 
    <>
      <PageMetadata property={property} isForSale={isForSale} isForRent={isForRent} />
      <StructuredData property={property} isForSale={isForSale} isForRent={isForRent} />
      <BreadcrumbStructuredData property={property} isForSale={isForSale} />
      
      {/* ===== پاپ‌آپ استوری ===== */}
      {showStoryPopup && (
        <StoryPopup 
          agentName={property.agent.name}
          agentImage={property.agent.image}
          userId={storyUserId}
          onClose={handleStoryClose}
        />
      )}

      {/* ===== مودال لاگین/ثبت‌نام ===== */}
      {showLoginModal && (
        <LoginModal 
          onClose={handleLoginModalClose}
        />
      )}
      
      <div className="detail-container realestate-detail">
        <nav className="breadcrumb-nav">
          <ol className="breadcrumb-list">
            <li className="breadcrumb-item"><a href="/">خانه</a></li>
            <li className="breadcrumb-item"><a href={isForSale ? '/sale' : '/rent'}>{isForSale ? 'فروش آپارتمان' : 'رهن و اجاره آپارتمان'}</a></li>
            <li className="breadcrumb-item"><a href={`/region/${encodeURIComponent(property.regionName)}`}>منطقه {property.regionName}</a></li>
            <li className="breadcrumb-item active">{truncateText(property.title, 50)}</li>
          </ol>
        </nav>
        
        <div className="detail-header">
          <button className="header-btn" onClick={() => navigate(-1)}><FaArrowRight /></button>
          <h1 className="header-title">{property.title}</h1>
          <button className="header-btn" onClick={handleShare}><FaShare /></button>
        </div>
        
        <div className="detail-gallery">
          <Swiper 
            modules={[Navigation, Pagination, Autoplay]} 
            navigation 
            pagination={{ clickable: true }} 
            autoplay={{ delay: 4000, disableOnInteraction: false }} 
            spaceBetween={0} 
            slidesPerView={1} 
            onSlideChange={(swiper) => setSelectedImage(swiper.activeIndex)} 
            className="gallery-swiper"
          >
            {property.images.length > 0 ? 
              property.images.map((img, index) => (
                <SwiperSlide key={index}>
                  <div className="gallery-slide">
                    {!imagesLoaded[index] && <div className="image-placeholder"><FaHome /></div>}
                    <img 
                      src={img} 
                      alt={`${property.title} - ${index === 0 ? 'نمای اصلی' : `تصویر ${index + 1}`}`} 
                      loading={index === 0 ? 'eager' : 'lazy'} 
                      onLoad={() => handleImageLoad(index)} 
                      style={{ display: imagesLoaded[index] ? 'block' : 'none' }} 
                    />
                  </div>
                </SwiperSlide>
              )) : 
              (<SwiperSlide>
                <div className="gallery-slide no-image">
                  <FaHome />
                  <span>تصویری موجود نیست</span>
                </div>
              </SwiperSlide>)
            }
          </Swiper>
          <button className={`favorite-btn ${isFavorite ? 'active' : ''}`} onClick={handleFavoriteToggle}>
            {isFavorite ? <FaHeart /> : <FaRegHeart />}
          </button>
          <div className="image-counter">{selectedImage + 1} / {property.images.length || 1}</div>
        </div>
        
        <div className="detail-main">
          <div className="detail-title-section">
            <div className="title-row">
              <div className="property-stats">
                <span className="stat-badge"><FaEye /> {property.views.toLocaleString('fa-IR')} بازدید</span>
                <span className="stat-badge"><FaBookmark /> {property.saved.toLocaleString('fa-IR')} ذخیره</span>
                <span className="stat-badge"><FaClock /> {property.createdAt}</span>
              </div>
            </div>
          </div>
          
          <div className="price-section">
            {isForSale && (
              <div className="price-card sale-price">
                <div className="price-card-icon"><FaTag /></div>
                <div className="price-card-content">
                  <span className="price-label">قیمت فروش</span>
                  <div className="price-value-wrapper">
                    <span className="price-number">{property.price}</span>
                    <span className="price-unit">تومان</span>
                  </div>
                  {formattedPricePerMeter && 
                    <div className="price-meta">
                      <FaRuler />
                      <span>متری {formattedPricePerMeter}</span>
                    </div>
                  }
                </div>
              </div>
            )}
            
            {isForRent && (
              <div className="rent-price-group">
                {property.mortgagePrice && property.mortgagePrice !== "۰" && (
                  <div className="price-card mortgage-price">
                    <div className="price-card-icon"><FaBuilding /></div>
                    <div className="price-card-content">
                      <span className="price-label">مبلغ رهن</span>
                      <div className="price-value-wrapper">
                        <span className="price-number">{property.mortgagePrice}</span>
                        <span className="price-unit">تومان</span>
                      </div>
                    </div>
                  </div>
                )}
                {property.rentPrice && property.rentPrice !== "۰" && (
                  <div className="price-card rent-price">
                    <div className="price-card-icon"><FaHome /></div>
                    <div className="price-card-content">
                      <span className="price-label">اجاره ماهانه</span>
                      <div className="price-value-wrapper">
                        <span className="price-number">{property.rentPrice}</span>
                        <span className="price-unit">تومان</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="quick-specs">
            <div className="spec-item">
              <FaRulerCombined />
              <span className="spec-label">متراژ</span>
              <span className="spec-value">{property.area} متر²</span>
            </div>
            <div className="spec-item">
              <FaBath />
              <span className="spec-label">اتاق‌خواب</span>
              <span className="spec-value">{property.rooms} خواب</span>
            </div>
            <div className="spec-item">
              <FaLayerGroup />
              <span className="spec-label">طبقه</span>
              <span className="spec-value">{property.floor} از {property.totalFloors}</span>
            </div>
            <div className="spec-item">
              <FaCalendarAlt />
              <span className="spec-label">سال ساخت</span>
              <span className="spec-value">{property.year}</span>
            </div>
          </div>
          
          <div className="info-chips">
            <span className="info-chip">کد ملک: {property.id}</span>
            <span className="info-chip"><FaShieldAlt /> {property.certificate}</span>
            <span className="info-chip type-chip">{isForSale ? 'فروش' : 'رهن و اجاره'}</span>
          </div>
          
          <div className="detail-tabs">
            <button className={`tab-btn ${activeTab === 'details' ? 'active' : ''}`} onClick={() => setActiveTab('details')}>جزئیات ملک</button>
            <button className={`tab-btn ${activeTab === 'features' ? 'active' : ''}`} onClick={() => setActiveTab('features')}>امکانات ({property.features.length})</button>
            <button className={`tab-btn ${activeTab === 'warnings' ? 'active' : ''}`} onClick={() => setActiveTab('warnings')}>هشدارهای معامله</button>
            <button className={`tab-btn ${activeTab === 'nearby' ? 'active' : ''}`} onClick={() => setActiveTab('nearby')}>امکانات اطراف</button>
          </div>
          
          <div className="tab-content">
            {activeTab === 'details' && (
              <div className="details-tab">
                <div className="address-card">
                  <FaMapMarkerAlt />
                  <div className="address-info">
                    <h3>آدرس ملک</h3>
                    <div>منطقه {property.regionName}</div>
                    <p>{property.address}</p>
                    <span className="post-date">تاریخ درج: {property.createdAt}</span>
                  </div>
                </div>
                <div className="description-card">
                  <h3>توضیحات کامل {property.title}</h3>
                  <div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(property.description, { ALLOWED_TAGS: ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'a', 'blockquote'], ALLOWED_ATTR: ['href', 'target'] }) }} />
                </div>
                <div className="map-card">
                  <h3><FaMapMarkerAlt /> موقعیت مکانی ملک در منطقه {property.regionName}</h3>
                  <div className="map-location-badge">
                    {property.showExactLocation ? 
                      <span className="badge exact">📍 نمایش موقعیت دقیق ملک</span> : 
                      <span className="badge approximate">🔵 نمایش محدوده تقریبی</span>
                    }
                  </div>
                  <div className="map-container">
                    <NeshanMap 
                      mapKey="web.31c5ea6c425e40cc9b30620a84a8be90" 
                      center={{ latitude: property.location.lat, longitude: property.location.lng }} 
                      zoom={property.showExactLocation ? 17 : 15.9} 
                      defaultType="dreamy" 
                      poi={true} 
                      traffic={false} 
                      style={{ height: '100%', width: '100%', pointerEvents: 'none' }} 
                    />
                    <div className="map-marker-overlay">
                      {property.showExactLocation ? 
                        <><div className="location-dot"></div><div className="location-ripple"></div></> : 
                        <div className="location-circles"><div className="circle-3"></div></div>
                      }
                    </div>
                  </div>
                  <div className="map-privacy-note">
                    <small>{property.showExactLocation ? '📍 موقعیت دقیق ملک' : '📍 محدوده تقریبی ملک'}</small>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'features' && (
              <div className="features-tab">
                <h3>امکانات و ویژگی‌ها</h3>
                <div className="features-grid">
                  {property.features.length > 0 ? 
                    property.features.map((feature, idx) => {
                      let Icon = FaCheckCircle;
                      if (feature.includes('پارکینگ')) Icon = FaParking;
                      else if (feature.includes('انباری')) Icon = FaWarehouse;
                      else if (feature.includes('آسانسور')) Icon = FaArrowUp;
                      else if (feature.includes('استخر')) Icon = FaSwimmingPool;
                      return (
                        <div key={idx} className="feature-card">
                          <Icon />
                          <span>{feature}</span>
                        </div>
                      );
                    }) : 
                    <p className="no-data">امکاناتی ثبت نشده است</p>
                  }
                </div>
              </div>
            )}
            
            {activeTab === 'warnings' && (
              <div className="warnings-tab">
                <h3>⚠️ هشدارهای مهم</h3>
                <ul className="warnings-list">
                  {property.warnings.map((w, idx) => (
                    <li key={idx} className="warning-item">
                      <span className="warning-bullet"></span>
                      <span>{w}</span>
                    </li>
                  ))}
                </ul>
                <div className="warning-footer">
                  <p>⚠️ قبل از معامله مدارک را بررسی کنید</p>
                </div>
              </div>
            )}
            
            {activeTab === 'nearby' && (
              <div className="nearby-tab">
                <h3>امکانات اطراف</h3>
                <div className="nearby-list">
                  {property.nearby.map((item, idx) => (
                    <div key={idx} className="nearby-item">
                      <span className="nearby-name">{item.name}</span>
                      <span className="nearby-distance">{item.distance}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* ============================================================ */}
          {/* ========== کارت مشاور با دکمه‌های قفل شده ========== */}
          {/* ============================================================ */}
          <div className="agent-card">
            <div className="agent-header">
              {/* آواتار */}
              <div 
                className={`agent-avatar-wrapper ${property.agent.hasStory ? 'has-story' : ''}`}
                style={{ 
                  position: 'relative',
                  display: 'inline-block',
                  flexShrink: 0,
                  cursor: property.agent.userId ? 'pointer' : 'default'
                }}
                onClick={property.agent.userId ? goToProfile : undefined}
              >
                <SafeImage 
                  src={property.agent.image} 
                  alt={property.agent.name} 
                  className={`agent-avatar ${property.agent.hasStory ? 'has-story' : ''}`}
                  fallbackSrc="https://randomuser.me/api/portraits/men/32.jpg"
                />
                
                {property.agent.hasStory && (
                  <div 
                    className="story-ring-indicator"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleStoryClick(e);
                    }}
                  >
                    <div className="story-ring-gradient"></div>
                  </div>
                )}
              </div>
              
              <div className="agent-info">
                <div className="agent-name-wrapper">
                  <h3 
                    style={{ cursor: property.agent.userId ? 'pointer' : 'default' }}
                    onClick={property.agent.userId ? goToProfile : undefined}
                  >
                    {property.agent.name}
                  </h3>
                  
                  {property.agent.hasStory && (
                    <span 
                      className="story-label" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleStoryClick(e);
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <span className="story-dot"></span>
                      استوری
                    </span>
                  )}
                </div>
                <p>{property.agent.address}</p>
                <div className="agent-rating">
                  <FaStar />
                  <span>{property.agent.rating}</span>
                  <span>({property.agent.deals} معامله)</span>
                </div>
              </div>
            </div>
            
            {/* ============================================================ */}
            {/* ===== دکمه‌های تماس با شرط لاگین ===== */}
            {/* ============================================================ */}
            <div className="agent-actions-wrapper">
              
              {/* دکمه تماس تلفنی */}
              <button 
                className={`agent-action-btn phone ${!isLoggedIn ? 'locked' : ''}`}
                onClick={handlePhoneClick}
              >
                <FaPhone /> 
                <span className="btn-label">
                  {isLoggedIn ? property.agent.phone : 'شماره تماس'}
                </span>
                
                {!isLoggedIn && (
                  <>
                    <span className="lock-badge">
                      <FaLock className="lock-icon-small" />
                    </span>
                    <div className="lock-overlay">
                      <FaLock className="lock-icon" />
                      <span className="lock-text">برای مشاهده شماره</span>
                      <span className="lock-subtext">وارد سامانه شوید</span>
                    </div>
                  </>
                )}
              </button>

              {/* دکمه واتساپ */}
              <button 
                className={`agent-action-btn whatsapp ${!isLoggedIn ? 'locked' : ''}`}
                onClick={handleWhatsAppClick}
              >
                <FaWhatsapp /> 
                <span className="btn-label">واتساپ</span>
                
                {!isLoggedIn && (
                  <>
                    <span className="lock-badge">
                      <FaLock className="lock-icon-small" />
                    </span>
                    <div className="lock-overlay">
                      <FaLock className="lock-icon" />
                      <span className="lock-text">برای مشاهده شماره</span>
                      <span className="lock-subtext">وارد سامانه شوید</span>
                    </div>
                  </>
                )}
              </button>
            </div>

            {/* دکمه ورود - فقط برای کاربران غیرلاگین */}
            {!isLoggedIn && (
              <button 
                className="login-prompt-btn" 
                onClick={() => setShowLoginModal(true)}
                style={{ marginTop: '10px' }}
              >
                <FaUser className="login-icon" />
                ورود / ثبت‌نام
                <FaArrowRight className="arrow-icon" />
              </button>
            )}
            {/* ============================================================ */}
            
          </div>
        </div>
        
        <DoubleSidebarBanners />
        <RelatedPropertiesSlider 
          currentPropertyId={property.id} 
          regionName={property.regionName} 
          propertyType={property.type} 
        />
        
        {copied && (
          <div className="toast-notification">
            <FaCheckCircle /> لینک کپی شد
          </div>
        )}
      </div>
    </> 
  );
});

RealEstateDetailPageItem.displayName = 'RealEstateDetailPageItem';
export default RealEstateDetailPageItem;